#!/bin/bash

echo "find or prompt msms is running"
#if [ -n $MSMS_EXECUTABLE_PATH ]
#then
#   echo "you appear to have already set your msms path, good job team!"
#   exit 0;
#fi

declare -a binpath_tokens

binpath_tokens=(`echo $PATH | awk 'BEGIN{FS = ":"} {for (i = 1; i <= NF; i++) print $i}'`)
counter=${#binpath_tokens[@]}

echo "searching PATH for msms program"
echo "==============================="
while ((counter > 0))
do
        ((counter = counter - 1))

        declare -a msms_matches
        msms_matches=(`ls ${binpath_tokens[counter]} | grep "msms"`)
        num_msms_found=${#msms_matches[@]}
        while ((num_msms_found > 0))
        do
                ((num_msms_found = num_msms_found - 1))
                echo "Configure found something resembling msms at:"
                echo "${binpath_tokens[counter]}/${msms_matches[num_msms_found]}"
                echo "Is this the MSMS that you wish to use with the gem program?[Y/n]"
                read is_correct

                if [ "$is_correct" != "n" -a "$is_correct" != "N" ]
                then
                        echo "I'll take that as a yes!"
                        MSMS_EXECUTABLE_PATH="${binpath_tokens[counter]}/${msms_matches[num_msms_found]}"
                        num_msms_found=0
                        counter=0
                fi
        done
done

echo $MSMS_EXECUTABLE_PATH

if [ -z $MSMS_EXECUTABLE_PATH ]
then
     echo "No MSMS executable path set, GEM will not be able to define its own surfaces by running msms."
     echo "You will receive plenty of reminders of this by the gem program."
else
     echo "MSMS appears to have been found."
     echo "Would you like to add the path to your profile to allow gem to use it?[Y/n]"
     read is_correct

     if [ "$is_correct" != "n" -a "$is_correct" != "N" ]
     then
        echo "I'll take that as a yes!"
        echo "export MSMS_EXECUTABLE_PATH=$MSMS_EXECUTABLE_PATH" >> ~/.profile
     else
        echo "No MSMS executable path set, GEM will not be able to define its own surfaces by running msms."
        echo "You will receive plenty of reminders of this by the gem program."
     fi
fi
