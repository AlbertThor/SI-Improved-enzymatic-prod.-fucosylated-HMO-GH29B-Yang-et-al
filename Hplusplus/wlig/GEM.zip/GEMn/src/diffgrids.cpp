#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "file_io.h"
#include <math.h>

void read_generic_grid (char *name, float **grid, int *xdim, int *ydim, int *zdim, float *minx, float *maxx, float *miny, float *maxy, float *minz, float *maxz, float *xscale, float *yscale, float *zscale)
{

int length = strlen(name);

   if (strcmp(&name[length-4], ".fld") == 0)
   {
      printf("%s is a mead phimap...\n", name);

      read_avs
        (
           name,
           grid,
           xdim, ydim, zdim,
           minx, miny, minz,
           maxx, maxy, maxz  
        );

      *xscale = (*maxx - *minx)/(float)(*xdim-1);
      *yscale = (*maxy - *miny)/(float)(*ydim-1);
      *zscale = (*maxz - *minz)/(float)(*zdim-1);

   }
   else if (strcmp( &name[length-4], ".phi") == 0)
   {
      printf("%s is a delphi phimap...\n", name);

      *xdim = read_phi_grid
              (
                 name,
                 grid,
                 minx, miny, minz,
                 maxx, maxy, maxz
              );

      *ydim = *zdim = *xdim;

      *xscale = (*maxx - *minx)/(float)(*xdim-1);
      *yscale = (*maxy - *miny)/(float)(*ydim-1);
      *zscale = (*maxz - *minz)/(float)(*zdim-1);
   }
   else
   {
      printf("%s is an unrecognized file type\n", name);
      exit(1);
   }

}

int main (int argc, char **argv)
{
   int xdim1, ydim1, zdim1,
       xdim2, ydim2, zdim2,
       i, j, k;

   float *grid1, *grid2,
         *gptr1, *gptr2,
         xscale1, yscale1, zscale1,
         xscale2, yscale2, zscale2,
         minx1, miny1, minz1, maxx1, maxy1, maxz1,
         minx2, miny2, minz2, maxx2, maxy2, maxz2;

   float rmsd = 0, maxdiff = 0, diff, avgsum = 0;

   if (argc != 3)
   {
      printf("command syntax is printgrid <grid 1> <grid 2>\n");
      return 1;
   }

   if ((strlen(argv[1]) < 5) || (strlen(argv[2]) < 5))
   {
      printf("command syntax is printgrid <grid 1> <grid 2>\n");
      return 1;
   }

   read_generic_grid 
      (
          argv[1],
          &grid1,
          &xdim1, &ydim1, &zdim1,
          &minx1, &maxx1,
          &miny1, &maxy1,
          &minz1, &maxz1,
          &xscale1, &yscale1, &zscale1
      );

   read_generic_grid 
      (
          argv[2],
          &grid2,
          &xdim2, &ydim2, &zdim2,
          &minx2, &maxx2,
          &miny2, &maxy2,
          &minz2, &maxz2,
          &xscale2, &yscale2, &zscale2
      );

   if ((xdim1 == xdim2) && (ydim1 == ydim2) && (zdim1 == zdim2)
       && (grid1 && grid2))
   {
      gptr1 = grid1;
      gptr2 = grid2;

      for (i = 0; i < zdim1; i++)
      {
          for (j = 0; j < ydim1; j++)
          {
              for (k = 0; k < xdim1; k++)
              {

                 diff = fabsf(*gptr1 - *gptr2);
                 avgsum += diff;

                 if (diff != diff)
                 {
                    printf("found a NaN %f %f\n", *gptr1, *gptr2);
                 }

                 if (diff > maxdiff)
                    maxdiff = diff;

                 rmsd += diff*diff;
   
                 gptr1++;
                 gptr2++;
              }
          }
      }

      rmsd = sqrt(rmsd/(float)(xdim1*ydim1*zdim1));
      avgsum /= (float)(xdim1*ydim1*zdim1);

      printf("RMSD = %f, avg absolute error = %f, maxerr = %f\n", rmsd, avgsum, maxdiff);

      free(grid1);
      free(grid2);
   }
   else
   {
      printf("Grids do not have the same dimensionality\n");
   }

   return 0;
}
