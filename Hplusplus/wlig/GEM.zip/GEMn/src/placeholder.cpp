/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

/****************************************************************************
 * This file contains a sort of dummy shell to write terminal programs using*
 * the GEM library.  If you copy this file to another location, be sure to  *
 * add it to the Makefile.am file and run autoreconf from the base directory*
 * (e.g. copy the "placeholder" lines to your own executable lines and      *
 * run autoreconf)                                                --jcg     *
 ****************************************************************************/
#include <string>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <math.h>
#include "file_io.h"
#include "visualize.h"
#include "defines.h"
#include "calculations.h"
#include "partitioned_open.h"
#include "gem.h"

using namespace std;

/* Generally starts up the program, parses command line, and does what is
 * requested. --jcg
 * Inputs: argc -- number of arguments passed
 *         argv -- arguments (array of character strings)
 * Outputs: return status of the program
 *                      --jcg
 */
int main (int argc, char **argv)
{
   /* local variables */
   /*******************/
   partitioned_open_struct open_dat;
   int ret_stat, i, j;

   if (argc < 2)
   {
      cerr<<"error, program requires a file to execute"<<endl;
      exit(1);
   }
   /*else*/

   open_dat.molname = argv[1];
   open_dat.triDens = 3.;
   open_dat.probeRadius = 1.5;

   ret_stat = open_pqr_run_msms(&open_dat);

   if (ret_stat == 0)
   {
      cerr<<"ERROR opening the named file."<<endl;
      exit(1);
   }

   /* now we have the surface and the molecule structure
    * we can do whatever we want from here... for instance to
    * traverse all the atoms and print them we would do this: */
    for (i = 0; i < open_dat.nresidues; i++)
    {
       cout<<"RESIDUE "<<open_dat.residues[i].name<<" "
           <<open_dat.residues[i].res_num<<" at ("
           <<open_dat.residues[i].x<<", "
           <<open_dat.residues[i].y<<", "
           <<open_dat.residues[i].z<<") has a radius of "
           <<open_dat.residues[i].rad<<" and a total charge of "
           <<open_dat.residues[i].total_charge<<endl
           <<"THE COMPONENT ATOMS FOLLOW:"<<endl;
           
       for (j = 0; j < open_dat.residues[i].natoms; j++)
       {
           cout<<"ATOM  "<<open_dat.residues[i].atoms[j].index<<" "
               <<open_dat.residues[i].atoms[j].name<<" "
               <<open_dat.residues[i].name<<" "
               <<open_dat.residues[i].res_num<<" "
               <<open_dat.residues[i].atoms[j].x<<" "
               <<open_dat.residues[i].atoms[j].y<<" "
               <<open_dat.residues[i].atoms[j].z<<" "
               <<open_dat.residues[i].atoms[j].charge<<" "
               <<open_dat.residues[i].atoms[j].radius<<endl;
       }
    }

    /* to traverse all the triangles and print their vertex coordinates
       we would do this: 
    for (i = 0; i < open_dat.ntri; i++)
    {
        cout<<"TRIANGLE "<<i<<" VERTEX 1 ("
            <<open_dat.vert[open_dat.tri[i].v[0]].x<<", "
            <<open_dat.vert[open_dat.tri[i].v[0]].y<<", "
            <<open_dat.vert[open_dat.tri[i].v[0]].z<<")"<<endl;
            
        cout<<"TRIANGLE "<<i<<" VERTEX 2 ("
            <<open_dat.vert[open_dat.tri[i].v[1]].x<<", "
            <<open_dat.vert[open_dat.tri[i].v[1]].y<<", "
            <<open_dat.vert[open_dat.tri[i].v[1]].z<<")"<<endl;

        cout<<"TRIANGLE "<<i<<" VERTEX 3 ("
            <<open_dat.vert[open_dat.tri[i].v[2]].x<<", "
            <<open_dat.vert[open_dat.tri[i].v[2]].y<<", "
            <<open_dat.vert[open_dat.tri[i].v[2]].z<<")"<<endl;
    }
    */

   return 0;
}/* end function main */
