/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include "defines.h"
#include "visualize.h"
#include "structures.h"
#include "calculations.h"
#ifdef __APPLE__
#include <OpenGL/glu.h>
#else
#include <GL/glu.h>
#endif
#include <stdio.h>

/***************************************************************************
 * FUNCTION: drawSelectedLine  -- draws a green line at the potential of   *
 *                                the currently selected atom              *
 *                                                                         *
 * INPUTS:   vis -- everything                                             *
 *                                                                         *
 * OUTPUTS:  none                                                          *
 *                                                                         *
 ***************************************************************************/
void drawSelectedLine(vis_data_struct *vis)
{
   /* local variables */
   double xpos, chg;

   /* may want to bail out */
   if ((vis->params.selected_res < 0)||(vis->params.selected_res >= vis->mol_data.nresidues))
      return;

   if (vis->params.colorType == 0 || vis->params.colorType == 2)
      xpos = 2.*(vis->mol_data.residues[vis->params.selected_res].atoms[0].pot_est - vis->params.vp[MIN])/vis->params.vp[EXTENT] - 1.;
   else
   {
      chg = vis->mol_data.residues[vis->params.selected_res].total_charge/ELECTROSTATIC_CONVERSION_FACTOR;

      printf("chg is %f\n", chg);
      printf("vc extent is %f\n", vis->params.vc[EXTENT]);

      xpos = 2.*(chg - vis->params.vc[MIN])/vis->params.vc[EXTENT] - 1.;
   }

   glColor3f(0, 1, 0);
   glBegin(GL_LINES);
      glVertex3f(xpos, .25, 0);
      glVertex3f(xpos, -1, 0);
   glEnd();
}


/***************************************************************************
 * FUNCTION: drawColrMap  -- draws the color map area as a reference to    *
 *                                what each color on the surface means     *
 *                                into the color map widget on the screen  *
 *                                                                         *
 * INPUTS:   vis -- everything                                             *
 *                                                                         *
 * OUTPUTS:  none                                                          *
 *                                                                         *
 ***************************************************************************/
void drawColrMap (vis_data_struct *vis)
{
   glXMakeCurrent
     (
        XtDisplay(vis->params.colrW),
        XtWindow(vis->params.colrW),
        vis->params.context_S
     );

   /* just draws the color map to whatever is current */
   just_draw_color_map(vis, vis->params.draw_wid, vis->params.draw_hit);

   glXSwapBuffers(XtDisplay(vis->params.colrW), XtWindow(vis->params.colrW));
} /* end drawColrMap function */

/***************************************************************************
 * FUNCTION: just_draw_color_map  -- draws the color map                   *
 *                                into whatever context is current         *
 *                                                                         *
 * INPUTS:   vis -- everything                                             *
 *                                                                         *
 * OUTPUTS:  none                                                          *
 *                                                                         *
 ***************************************************************************/
void just_draw_color_map (vis_data_struct *vis, int width, int height)
{
   /* local variables */
   /*******************/
   float r, g, b, /* red, green, and blue components */
         x_left_pos;
   char temp[40];
   int pixel_width_of_string;

   glMatrixMode(GL_MODELVIEW);

   glClear(GL_COLOR_BUFFER_BIT);

   glBegin(GL_QUADS);

   if (vis->params.custBonds)
      getColor(&r, &g, &b, vis->params.cust_bond_c[MIN], vis->params.cust_bond_c);
   else if (vis->params.colorType == 0)
      getColor(&r, &g, &b, vis->params.vp[MIN], vis->params.vp);
   else if (vis->params.colorType == 1)
      getColor(&r, &g, &b, vis->params.vc[MIN], vis->params.vc);
   else 
   {
      r = 1.0;
      g = 1.0;
      b = 1.0;
   }

   glColor3f(r, g, b);
   glVertex3f(-1, -1, 0);
   glVertex3f(-1, 0, 0);

   if (vis->params.custBonds)
      getColor(&r, &g, &b, vis->params.cust_bond_c[CENTER], vis->params.cust_bond_c);
   else if (vis->params.colorType == 0)
      getColor(&r, &g, &b, vis->params.vp[CENTER], vis->params.vp);
   else if (vis->params.colorType == 1)
      getColor(&r, &g, &b, vis->params.vc[CENTER], vis->params.vc);
   else 
   {
      r = 1.0;
      g = 1.0;
      b = 1.0;
   }

   glColor3f(r, g, b);
   glVertex3f(0, 0, 0);
   glVertex3f(0, -1, 0);

   glColor3f(r, g, b);
   glVertex3f(0, -1, 0);
   glVertex3f(0, 0, 0);

   if (vis->params.custBonds)
      getColor(&r, &g, &b, vis->params.cust_bond_c[MAX], vis->params.cust_bond_c);
   else if (vis->params.colorType == 0)
      getColor(&r, &g, &b, vis->params.vp[MAX], vis->params.vp);
   else if (vis->params.colorType == 1)
      getColor(&r, &g, &b, vis->params.vc[MAX], vis->params.vc);
   else 
   {
      r = 1.0;
      g = 1.0;
      b = 1.0;
   }

   glColor3f(r, g, b);
   glVertex3f(1, 0, 0);
   glVertex3f(1, -1, 0);

   glEnd();

   /* draw selected lines */
   drawSelectedLine(vis);

   /* draw units and label in black */
   glColor3f(0.,0.,0.);

   if (vis->params.custBonds)
   {
      sprintf(temp, "Interaction Value");
   } 
   else if (vis->params.colorType == 0)
   {
      sprintf(temp, "Electrostatic Potential (kcal/mol/|e|)");
   }
   else if (vis->params.colorType == 1)
   {
      sprintf(temp, "Surface Charge (|e|/A)");
   } 
   else 
   {
      sprintf(temp, "");
   }

   pixel_width_of_string = XTextWidth(vis->params.font, temp, strlen(temp));

   /* now we want to center the above text on the screen regardless of screen
    * size */
   x_left_pos = -1 + (width - pixel_width_of_string)
                / (float) width;

   glRasterPos2f(x_left_pos, -.6);
   glCallLists(strlen(temp), GL_BYTE, temp);

   /* draw values text in white */
   glColor3f(1.,1.,1.);

   /* draw left (min) bounding value with 10 pixel buffer from edge */
   if (vis->params.custBonds)
      sprintf(temp, "%2.2f", vis->params.cust_bond_c[MIN]);
   else if (vis->params.colorType == 0)
      sprintf(temp, "%2.2f", vis->params.vp[MIN]);
   else if (vis->params.colorType == 1)
      sprintf(temp, "%2.2f", vis->params.vc[MIN]);

   pixel_width_of_string = XTextWidth(vis->params.font, temp, strlen(temp));

   x_left_pos = -1. + (20. / (float) width);

   glRasterPos2f(x_left_pos, -.6);
   glCallLists(strlen(temp), GL_BYTE, temp);

   /* draw right (max) bounding value */
   if (vis->params.custBonds)
      sprintf(temp, "%2.2f", vis->params.cust_bond_c[MAX]);
   else if (vis->params.colorType == 0)
      sprintf(temp, "%2.2f", vis->params.vp[MAX]);
   else if (vis->params.colorType == 1)
      sprintf(temp, "%2.2f", vis->params.vc[MAX]);

   x_left_pos = -1. + 2 * ((width - (10. + pixel_width_of_string))
                 / (float) width);

   glRasterPos2f(x_left_pos, -.6);
   glCallLists(strlen(temp), GL_BYTE, temp);

} /* end just_draw_color_map function */
