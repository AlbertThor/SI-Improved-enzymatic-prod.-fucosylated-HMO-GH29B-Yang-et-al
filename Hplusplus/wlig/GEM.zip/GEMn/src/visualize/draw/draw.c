/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

#include "visualize.h"  /* for structure defs  */
#include "structures.h" /* for structure defs  */
#include <stdio.h>      /* for printf, fprintf */
#include <string.h>
#include <stdlib.h>     /* for exit            */
#ifdef __APPLE__
#include <OpenGL/glu.h>     /* for gluSphere       */
#else
#include <GL/glu.h>     /* for gluSphere       */
#endif

/****************************************************************************
 * FUNCTION:  draw  -- redraws all openGL drawing areas                     *
 *                                                                          *
 * INPUTS:    vis   -- everything (the vis_data_struct)                     *
 *                                                                          *
 * OUTPUTS:   none                                                          *
 *                                                                          *
 * RETURNS:   nothing                                                       *
 *                                                                          *
 ****************************************************************************/
void draw (vis_data_struct *vis, int haveWidgets)
{
   if (haveWidgets)
      glXMakeCurrent(XtDisplay(vis->params.drawW), XtWindow(vis->params.drawW), vis->params.context_D);

   glMatrixMode(GL_MODELVIEW);
   glInitNames();

   /* clear it out first */
   glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

   if ((vis->mol_data.nvert < 3) && (vis->decor_mol.nvert < 3))
   {
      if (haveWidgets)
         glXSwapBuffers(XtDisplay(vis->params.drawW), XtWindow(vis->params.drawW));
      return;
   }

   if (!vis->params.surfaceList)
   {
      /* draw the real molecule's atoms and surface */
      drawAtoms
        (
           vis->mol_data.residues, vis->mol_data.nresidues,
           vis->mol_data.bonds, vis->mol_data.nbonds,
           vis->params.selected_res, vis->params.atomDrawMode
        );
      drawSurface
        (
          vis->mol_data.vert, vis->mol_data.nvert,
          vis->mol_data.tri, vis->mol_data.ntri,
          vis->mol_data.residues, vis->mol_data.nresidues,
          vis->params.selected_res, vis->params.surfDrawMode,
          vis->params.trans
        );

      /* draw the decoration molecule's atoms and surface */
      drawAtoms
        (
           vis->decor_mol.residues, vis->decor_mol.nresidues,
           vis->decor_mol.bonds, vis->decor_mol.nbonds,
           -1, vis->decor_mol.atomDrawType
        );
      drawSurface
        (
          vis->decor_mol.vert, vis->decor_mol.nvert,
          vis->decor_mol.tri, vis->decor_mol.ntri,
          vis->decor_mol.residues, vis->decor_mol.nresidues,
          -1, vis->decor_mol.surfaceDrawType,
          .25
        );

   }
   else
   {
      if (vis->params.atomDrawMode != DRAW_NONE)
         glCallList(vis->params.atomList);

      if (vis->params.surfDrawMode != DRAW_NONE)
         glCallList(vis->params.surfaceList);

      glCallList(vis->params.decorList);

   }

   if (haveWidgets)
      glXSwapBuffers(XtDisplay(vis->params.drawW), XtWindow(vis->params.drawW));

} /* end draw function */
