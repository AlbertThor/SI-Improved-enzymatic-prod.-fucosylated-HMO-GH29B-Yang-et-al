/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

#include "visualize.h"
#include <limits.h>
#include "calculations.h"
#ifdef __APPLE__
#include <OpenGL/glu.h>
#else
#include <GL/glu.h>
#endif

void update_zdepths (vertx *vert, int nvert, triangle *tri, int ntri)
{
/* local variables */
double projMatrix[16];   /* we are going to get these from GL even though */
double modelMatrix[16];  /* model matrix is stored away just to avoid depending
                          * on the vis_param_struct
                          */

GLint  viewport[4];        /* viewport coordinates (also available in some form in
                          * the vis_param_struct...
                          */

triangle temp;

GLdouble winx, winy, winz; /* window positions after projection */

ulong i;

   if ((vert == NULL) || (nvert < 3) || (tri == NULL)) return;

   /* else */

   /* initialization of openGL related values needed by gluProject */
   glGetDoublev(GL_MODELVIEW_MATRIX, modelMatrix);
   glGetDoublev(GL_PROJECTION_MATRIX, projMatrix);
   glGetIntegerv(GL_VIEWPORT, viewport);

   /* first populate per vertex depth information */
   for (i = 0; i < nvert; i++)
   {
      gluProject
        (
           (GLdouble)vert[i].x, (GLdouble)vert[i].y, (GLdouble)vert[i].z,
           modelMatrix,
           projMatrix,
           viewport,
           &winx,
           &winy,
           &winz
        );

      vert[i].zdepth = USHRT_MAX * winz;
   }

   /* then populate triangles by averaging vertexes */
   for (i = 0; i < ntri; i++)
   {
      tri[i].zdepth = (vert[tri[i].v[0]].zdepth +
                       vert[tri[i].v[1]].zdepth +
                       vert[tri[i].v[2]].zdepth) / 3;
   }

   /* resort the triangles by their zdepth and then invert the list */
   radix_sort (sizeof(ushort), 0, sizeof(triangle), ntri, tri);

   for (i = 0; i < ntri/2; i++)
   {
       memcpy(&temp, &tri[i], sizeof(triangle));
       memcpy(&tri[i], &tri[ntri-(i+1)], sizeof(triangle));
       memcpy(&tri[ntri-(i+1)], &temp, sizeof(triangle));
   }

}
