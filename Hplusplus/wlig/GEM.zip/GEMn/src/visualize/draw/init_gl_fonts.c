/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include "visualize.h"
#include "tellUser.h"
#include <stdlib.h> /* for exit */
#include <stdio.h>


/****************************************************************************
 * FUNCTION:  initialize_gl_fonts -- sets up fonts for rendering text       *
 *                                                                          *
 * INPUTS:    disp  -- the X display pointer                                *
 *                                                                          *
 * OUTPUTS:   none                                                          *
 *                                                                          *
 ****************************************************************************/
XFontStruct *initialize_gl_fonts(Display *disp)
{
   /* local variables */
   XFontStruct *fontInfo;
   Font id;
   unsigned int first, last;
   GLuint base;

   /* try to grab a reasonably small font here */
   fontInfo = XLoadQueryFont(disp, "-adobe-helvetica-*-r-*-*-20-*-*-*-*-*-*-*");

   if (fontInfo == NULL)
   {
      tellUser("Error", "Could not allocate a font to display values\n");
      exit(1);
   }

   id = fontInfo->fid;
   first = fontInfo->min_char_or_byte2;
   last = fontInfo->max_char_or_byte2;

   base = glGenLists(last+1);
   if (base == 0)
   {
      tellUser("Error", "Could not allocate a font to display values\n");
      exit(1);
   }

   glXUseXFont(id, first, last-first+1, base+first);
   glListBase(base);

   return fontInfo;
} /* end initialize_gl_fonts function */

