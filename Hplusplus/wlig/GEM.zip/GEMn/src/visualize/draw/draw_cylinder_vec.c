/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

#include "visualize.h"
#include "calculations.h"
#ifdef __APPLE__
#include <OpenGL/glu.h>
#else
#include <GL/glu.h>
#endif
#include <math.h>

/****************************************************************************
 * FUNCTION: draw_cylinder_vec -- draws a cylinder along a vector           *
 *                                                                          *
 * INPUTS: sx, sy, sz - the start position of the vector                    *
 *         ex, ey, ez - the end position of the vector                      *
 *         width - the width of the cylinder                                *
 *                                                                          *
 * OUTPUTS: none                                                            *
 *                                                                          *
 ****************************************************************************/
void drawCylinderVec (GLUquadricObj *obj, float sx, float sy, float sz, float ex, float ey, float ez, float radius)
{
/* local variables */
double vec[3],  /* vector from start to end */
      angle,    /* angle between vector and 0, 1, 0 */
      dotProd,
      mag,
      norm[3];  /* cross between (0,0,1) and our vector */

const double conv = 180.0/M_PI;

   if (obj == 0) return;

   gluQuadricOrientation(obj, GLU_OUTSIDE);
   gluQuadricDrawStyle(obj, GLU_FILL);

   /* get the vector from start to end */
   vec[0] = ex - sx;
   vec[1] = ey - sy;
   vec[2] = ez - sz;

   /* cross product */
   norm[0] = -vec[1];
   norm[1] = vec[0];
   norm[2] = 0.;

   dotProd = vec[2];
   mag = magnitude(vec);

   angle = conv * acos(dotProd / mag);

   glPushMatrix();

      glTranslated(sx, sy, sz);
      glRotated(angle, norm[0], norm[1], norm[2]);

      gluCylinder(obj, radius, radius, mag, 16, 1);

   glPopMatrix();

} /* end function */
