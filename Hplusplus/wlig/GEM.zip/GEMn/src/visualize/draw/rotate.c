/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

#include "visualize.h"
#include "calculations.h"
#include <math.h>

/*
 * This file contains a function which takes a mouse position and the
 * vis struct and updates the rotation matrix with a rotation reflecting
 * the last rotation matrix rotated by this new rotation.   --jcg
 */

/***************************************************************************
 * FUNCTION:  convert_to_3d  -- takes 2-D screen coordinates and transforms*
 *                                 to 3-D world coordinates on the surface *
 *                                 of an imaginary (unit) sphere.          *
 *                                                                         *
 * INPUTS:    two_d          -- 2-D coordinates provided                   *
 *            vis            -- everything                                 *
 *                                                                         *
 * OUTPUTS:   three_d        -- 3-D unit sphere coordinates returned       *
 *                                                                         *
 ***************************************************************************/
void convert_to_3d (double two_d[2], double three_d[3], vis_data_struct *vis)
{
   /* local variables */
   /*******************/
   double lengthSq,      /* square of the length of the vector */
          length;        /* length of the vector               */

   three_d[0] = (two_d[0]-vis->params.draw_wid/2) / ((vis->params.draw_wid - 1.0)*.5);
   three_d[1] = (two_d[1]-vis->params.draw_hit/2) / ((vis->params.draw_hit - 1.0)*.5);

   lengthSq = three_d[0]*three_d[0] + three_d[1]*three_d[1];

   if (lengthSq > 1.0) /* 1.0 * 1.0 == 1.0 */
   {
      length = sqrt(lengthSq);
      
      three_d[0] /= length;
      three_d[1] /= length;
      three_d[2]  = 0.;
   }
   else
   {
      three_d[2] = sqrt (1. - lengthSq);
   }
   
}

/* calculates the rotation between two vectors
 * and tacks that rotation matrix onto the current
 * matrix. */

/***************************************************************************
 * FUNCTION:  rotate  -- finds the rotation matrix between the last rotate *
 *                       position and current and constructs and appends   *
 *                       a rotation matrix that would rotate the current   *
 *                       mouse position to the last one.                   *
 *                                                                         *
 *                                                                         *
 * INPUTS:    mousex, mousey -- mouse x and y positions                    *
 *            vis            -- everything                                 *
 *                                                                         *
 * OUTPUTS:   nothing  -- but the rotation matrix in vis is updated        *
 *                                                                         *
 ***************************************************************************/
void rotate (int mousex, int mousey, vis_data_struct *vis)
{
   /* local variables */
   /*******************/
   const int x = 0,
             y = 1,
             z = 2;

   const double conv = 180.0/M_PI; /* from radians to degrees */
        
   double start[2],       /* start mouse position     (2d) */
          end[2],         /* end mouse position       (2d) */
          startSphere[3], /* start (sphere) position  (3d) */
          endSphere[3],   /* end   (sphere) position  (3d) */
          normal[3],      /* normal to start and end  (3d) */
          center[3],      /* center about which to rotate  */
          dotProd,        /* dot product of start&end      */
          theta;          /* angle between two vectors     */

   /* method */
   /**********/
   start[x] = vis->params.click_x;
   start[y] = vis->params.click_y;
   
   end[x]   = mousex;
   end[y]   = mousey;

   center[x] = vis->params.x[CENTER];
   center[y] = vis->params.y[CENTER];
   center[z] = vis->params.z[CENTER];

   convert_to_3d (start, startSphere, vis);
   convert_to_3d (end,   endSphere,   vis);

   /* calculate the cross product */
   cross_prod (startSphere, endSphere, normal);
   
   /* calculate the dot product   */
   dotProd = dot_prod (startSphere, endSphere);

   theta = conv * acos(dotProd / (magnitude(startSphere)*magnitude(endSphere)));

   /* now use openGL built in functions to get the rotated rotations */
   glPushMatrix();
   glLoadIdentity();

   glTranslated(center[x], center[y], center[z]);

   glRotated(theta, normal[x], normal[y], normal[z]);

   glTranslated(-center[x], -center[y], -center[z]);

   glMultMatrixd(vis->params.rot_store_mat);

   glGetDoublev(GL_MODELVIEW_MATRIX, vis->params.rot_mat);

   glPopMatrix();

   vis->params.rotation_dirty = 1;
}

/****************************************************************************
 * FUNCTION:  rotate_to_vector -- rotates the "eye" or "camera" to align    *
 *                                with a given vector in world coordinates  *
 *                                                                          *
 * INPUT:     vis  -- everything                                            *
 *            x, y, z   -- the vector with which to align the eye           *
 *                                                                          *
 * OUTPUT:    none                                                          *
 *                                                                          *
 * POSTCONDITIONS/SIDE EFFECTS:  vis->params.rot_mat is updated for the     *
 *                                    desired rotation  (overwritten)       *
 *                                                                          *
 ****************************************************************************/
void rotate_to_vector (vis_data_struct *vis, float x, float y, float z)
{
/* local variables */
double rot_angle,
         dotProd,
        cross[3],
         dest[3],
       center[3];

const  double conv = 180.0/M_PI; /* from radians to degrees */

   center[0] = vis->params.x[CENTER];
   center[1] = vis->params.y[CENTER];
   center[2] = vis->params.z[CENTER];

   dest[0] = x;
   dest[1] = y;
   dest[2] = z;

   /* since the eye is constant we can do a simplified cross */
   cross[0] =  dest[1];
   cross[1] = -dest[0];
   cross[2] = 0;

   /* since the eye is constant, save dot time as well */
   dotProd = dest[2];

   rot_angle = conv * acos(dotProd / (magnitude(dest)));

   /* now use openGL built in functions to get the rotated rotations */
   glPushMatrix();
   glLoadIdentity();

   glTranslated(center[0], center[1], center[2]);

   glRotated(rot_angle, cross[0], cross[1], cross[2]);

   glTranslated(-center[0], -center[1], -center[2]);

   glGetDoublev(GL_MODELVIEW_MATRIX, vis->params.rot_mat);
   glGetDoublev(GL_MODELVIEW_MATRIX, vis->params.rot_store_mat);

   glPopMatrix();

   vis->params.rotation_dirty = 1;

}
