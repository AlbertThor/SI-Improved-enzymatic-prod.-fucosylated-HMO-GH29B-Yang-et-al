/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

#include "visualize.h"  /* for structure defs  */
#include "structures.h" /* for structure defs  */
#include <stdio.h>      /* for printf, fprintf */
#include <string.h>
#include <stdlib.h>     /* for exit            */
#ifdef __APPLE__
#include <OpenGL/glu.h>     /* for gluSphere       */
#else
#include <GL/glu.h>     /* for gluSphere       */
#endif

/****************************************************************************
 * FUNCTION:  drawSelection  -- draws the selection model separately to     *
 *                                    speed up selection and drawing        *
 *                                                                          *
 * INPUTS:    residues      --residues making up the molecule               *
 *            nresidues     --number of residues in the molecule            *
 *                                                                          *
 * OUTPUTS:   none                                                          *
 *                                                                          *
 ****************************************************************************/
void drawSelection (residue *residues, int nresidues)
{
   /* local variables */
   /*******************/

   int i,j;    /* loop counters */

   int natoms;

   GLUquadricObj *obj;

   obj = gluNewQuadric();

   gluQuadricOrientation(obj, GLU_OUTSIDE);
   gluQuadricDrawStyle(obj, GLU_FILL);

   for (i = 0; i < nresidues; i++)
   {
      natoms = residues[i].natoms;
      for (j = 0; j < natoms; j++)
      {
         glPushName((GLuint)i);

         glPushMatrix();

         /* translate the sphere */
         glTranslatef
            (
               residues[i].atoms[j].x,
               residues[i].atoms[j].y,
               residues[i].atoms[j].z
            );

         /* draw the sphere (really, really coarse model) */
         gluSphere(obj, residues[i].atoms[j].radius*2., 4, 4);

         glPopMatrix();
         glPopName();
      }
   } /* end for (i < nresidues) */

   gluDeleteQuadric(obj);

} /* end draw function */
