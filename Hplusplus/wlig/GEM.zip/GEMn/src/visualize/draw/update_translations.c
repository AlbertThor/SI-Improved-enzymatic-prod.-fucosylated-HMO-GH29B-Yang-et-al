/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

#include "visualize.h"
#include "structures.h"
#include <math.h>
#ifdef __APPLE__
#include <OpenGL/glu.h>
#else
#include <GL/glu.h>
#endif

/****************************************************************************
 * FUNCTION: updateTranslations   -- updates translations and redraws       *
 *                                    everything.                           *
 *                                                                          *
 * INPUTS:   vis    -- vis_data_struct (everything)                         *
 *                                                                          *
 * OUTPUTS:  nothing                                                        *
 *                                                                          *
 ****************************************************************************/
void updateTranslations(vis_data_struct *vis, int resort_depths, int setCurrent)
{

  if (setCurrent)
     glXMakeCurrent(XtDisplay(vis->params.drawW), XtWindow(vis->params.drawW), vis->params.context_D);

  glLoadIdentity();

  /* scale */
  glScalef(vis->params.scale, vis->params.scale, vis->params.scale);

  /* shift */
  glTranslatef
     (
        -vis->params.x[CENTER] + vis->params.xshift,
        -vis->params.y[CENTER] + vis->params.yshift,
        -vis->params.z[CENTER]
     );

  /* rotate */
  glMultMatrixd(vis->params.rot_mat);

  if (resort_depths)
  {
     /* update depth values */
     if ((vis->params.trans > 0) || (vis->params.selected_res >= 0))
     {
        update_zdepths
           (vis->mol_data.vert, vis->mol_data.nvert, vis->mol_data.tri, vis->mol_data.ntri);
        gen_main_mol_lists(vis, 1, (vis->params.selected_res >= 0), -1.);
        vis->params.rotation_dirty = 0;
     }

     update_zdepths
        (vis->decor_mol.vert, vis->decor_mol.nvert, vis->decor_mol.tri, vis->decor_mol.ntri);
     gen_decor_mol_list(vis);

  }
  /* redraw */
  draw(vis, setCurrent);


} /* end updateTranslations functions */
