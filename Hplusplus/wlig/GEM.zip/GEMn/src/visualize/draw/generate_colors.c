/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include "visualize.h"
#include "calculations.h"
#include "structures.h"

/****************************************************************************
 * FUNCTION: generate_colors   --sets the colors for all the surface        *
 *                               vertices as well as all the atoms          *
 *                                                                          *
 * INPUTS:   vis   -- everything                                            *
 *                                                                          *
 * OUTPUTS:  nothing                                                        *
 *                                                                          *
 ****************************************************************************/
void generate_colors(vis_data_struct *vis)
{
   /* local variables */
   int i,j;

  /* color the vertices of the surface */
  for (i = 0; i < vis->mol_data.nvert; i++)
  {

    if (vis->params.colorType == 0)
     getColor
        (
           &vis->mol_data.vert[i].r,
           &vis->mol_data.vert[i].g,
           &vis->mol_data.vert[i].b,
            vis->mol_data.vert[i].potential,
            vis->params.vp
        );
    else if (vis->params.colorType == 2) 
    {
       vis->mol_data.vert[i].r = 1.0;
       vis->mol_data.vert[i].g = 1.0;
       vis->mol_data.vert[i].b = 1.0;
    }
    else
     getColor
        (
           &vis->mol_data.vert[i].r,
           &vis->mol_data.vert[i].g,
           &vis->mol_data.vert[i].b,
            vis->mol_data.vert[i].surface_charge,
            vis->params.vc
        );

  }

  /* color the atoms */
  for (i = 0; i < vis->mol_data.nresidues; i++)
  {
     for (j = 0; j < vis->mol_data.residues[i].natoms; j++)
     {
        getAtomTypeColor
           (
              &vis->mol_data.residues[i].atoms[j].r, 
              &vis->mol_data.residues[i].atoms[j].g, 
              &vis->mol_data.residues[i].atoms[j].b, 
              vis->mol_data.residues[i].atoms[j].name
           );
     }
  }
}
