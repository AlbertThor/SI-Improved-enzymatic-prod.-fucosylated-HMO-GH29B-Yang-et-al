/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

#include "visualize.h"  /* for structure defs  */
#include "structures.h" /* for structure defs  */
#include <stdio.h>      /* for printf, fprintf */
#include <string.h>
#include <stdlib.h>     /* for exit            */
#ifdef __APPLE__
#include <OpenGL/glu.h>     /* for gluSphere       */
#else
#include <GL/glu.h>     /* for gluSphere       */
#endif

/***************************************************************************
 * FUNCTION:  drawSurface -- draws the molecular surface into whatever     *
 *                                  gl_context is current                  *
 *                                                                         *
 * INPUTS:    vert          --surface vertices                             *
 *            nvert         --number of surface vertices                   *
 *            tri           --triangles                                    *
 *            ntri          --number of triangles                          *
 *            selected_res  --index of the selected residue                *
 *            drawMode      --how to draw the surface (mesh/solid/etc)     *
 *            residues      --the residues making up the molecule          *
 *            nres          --number of residues in the molecule           *
 *            trans         --transparency                                 *
 *                                                                         *
 * OUTPUTS:   none                                                         *
 *                                                                         *
 ***************************************************************************/
void drawSurface(vertx *vert, int nvert, triangle *tri, int ntri, residue *residues, int nres, int selected_res, int drawMode, double trans)
{
   /* local variables */
   int i, j, /* loop counters */
       k;    /* temp to avoid too much dereferencing */

   int res,
       atm,
       swapped = 0;

   float color[4];
   GLenum mode,
          othermode;

   glMatrixMode(GL_MODELVIEW);
   color[3] = 1 - trans;

   if (drawMode != DRAW_NONE)
   {
      if (drawMode == S_DRAW_WIREFRAME)
      {
         mode = GL_LINE;
         othermode = GL_FILL;
      }
      else
      {
         mode = GL_FILL;
         othermode = GL_LINE;
      }

      glPolygonMode(GL_FRONT_AND_BACK, mode);

      glBegin(GL_TRIANGLES);

      for (i = 0; i < ntri; i++)
      {
         if ((i == 0) || (tri[i].nearest_atom != tri[i-1].nearest_atom))
         {
           find_res_atm_pair(residues, nres, tri[i].nearest_atom, &res, &atm);

           if (!swapped)
           {
             if (res == selected_res)
             {
                glEnd();
                glPolygonMode(GL_FRONT_AND_BACK, othermode);
                glBegin(GL_TRIANGLES);
                swapped = 1;
             }
           }
           else if (res != selected_res)
           {
              glEnd();
              glPolygonMode(GL_FRONT_AND_BACK, mode);
              glBegin(GL_TRIANGLES);
              swapped = 0;
           }
         }

         for (j = 0; j < 3; j++) /* loop for looks */
         {
            k = tri[i].v[j];

            color[0] = vert[k].r;
            color[1] = vert[k].g;
            color[2] = vert[k].b;

            glColor4fv(color);

            glNormal3d(vert[k].xNorm, vert[k].yNorm, vert[k].zNorm);
            glVertex3d(vert[k].x, vert[k].y, vert[k].z);

        }/* end for (j < 3) */
         
      } /* end for (i < nvert) */

      glEnd();

      if (drawMode == S_DRAW_WIREFRAME)
      {
         glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
      }

   } /* end if (we want to see the solid surface) */

} /* end draw function */
