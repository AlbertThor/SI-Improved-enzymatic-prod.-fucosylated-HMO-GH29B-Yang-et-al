/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

 #include "visualize.h"
 #include <GL/gl.h>


/****************************************************************************
 * FUNCTION:  gen_main_mol_lists  -- regenerates display lists for main mol *
 *                                                                          *
 * INPUTS:  vis  -- everything                                              *
 *          do_surface -- do we generate surface lists?                     *
 *          do_atoms   -- do we generate atom lists?                        *
 *                                                                          *
 * OUTPUTS: none                                                            *
 *                                                                          *
 * INTENT: slim down code a whole lot                                       *
 *                                                                          *
 ****************************************************************************/
void gen_main_mol_lists (vis_data_struct *vis, char do_surface, char do_atoms, double override_trans)
{
     if (override_trans < 0)
     {
        override_trans = vis->params.trans;
     }
     if (do_surface)
     {
        glNewList(vis->params.surfaceList, GL_COMPILE);
        drawSurface
          (
             vis->mol_data.vert, vis->mol_data.nvert,
             vis->mol_data.tri, vis->mol_data.ntri,
             vis->mol_data.residues, vis->mol_data.nresidues,
             vis->params.selected_res, vis->params.surfDrawMode,
             override_trans
          );
        glEndList();
     }


     if (vis->params.custBonds) 
     {
        glNewList(vis->params.atomList, GL_COMPILE);
        if ((vis->mol_data.nbonds == 0)||(vis->mol_data.bonds==NULL)) {
            vis->mol_data.nbonds = extrapolate_bonds(vis->mol_data.residues, vis->mol_data.nresidues, (bond **)&vis->mol_data.bonds);
        }
        drawAtomsWithBonds 
           (
              vis->mol_data.residues, vis->mol_data.nresidues,
              vis->mol_data.bonds, vis->mol_data.nbonds,
              vis->mol_data.cust_bonds, vis->mol_data.ncust_bonds,
              vis->params.selected_res, vis->params.atomDrawMode,
              vis->params.cust_bond_c,
              vis->params.custBondsOnly
           );

        glEndList();
     } else {
        if (do_atoms)
        {
           glNewList(vis->params.atomList, GL_COMPILE);
           drawAtoms
              (
                 vis->mol_data.residues, vis->mol_data.nresidues,
                 vis->mol_data.bonds, vis->mol_data.nbonds,
                 vis->params.selected_res, vis->params.atomDrawMode
              );
           glEndList();
        }
     }
}

/****************************************************************************
 * FUNCTION:  gen_decor_mol_list  -- regenerates display lists for decor    *
 *                                                                          *
 * INPUTS:  vis  -- everything                                              *
 *                                                                          *
 * OUTPUTS: none                                                            *
 *                                                                          *
 * INTENT: slim down code a whole lot                                       *
 *                                                                          *
 ****************************************************************************/
void gen_decor_mol_list (vis_data_struct *vis)
{
    glNewList(vis->params.decorList, GL_COMPILE);

        drawAtoms
         (
            vis->decor_mol.residues, vis->decor_mol.nresidues,
            vis->decor_mol.bonds, vis->decor_mol.nbonds,
            -1, vis->decor_mol.atomDrawType
         );

        drawSurface
         (
            vis->decor_mol.vert, vis->decor_mol.nvert,
            vis->decor_mol.tri, vis->decor_mol.ntri,
            vis->decor_mol.residues, vis->decor_mol.nresidues,
            -1, vis->decor_mol.surfaceDrawType,
            .25
         );

    glEndList();
}
