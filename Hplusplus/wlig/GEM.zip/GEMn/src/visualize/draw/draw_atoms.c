/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

#include "visualize.h"  /* for structure defs  */
#include "structures.h" /* for structure defs  */
#include "calculations.h" /* for magnitude */
#include <stdio.h>      /* for printf, fprintf */
#include <stdlib.h>     /* for exit            */
#ifdef __APPLE__
#include <OpenGL/glu.h>     /* for gluSphere       */
#else
#include <GL/glu.h>     /* for gluSphere       */
#endif

#define STICK_RADIUS 0.1f
#define SMALL_STICK_RADIUS 0.05f

void drawBackbone (GLUquadricObj *obj, residue *residues, int nresidues)
{
/* local variables */
int i, j, k, natoms, lasti, lastj;
static char bbone[3][3]  = {"N\0\0", "CA\0", "C\0\0"};
float  color[3]; /* smaller function profiles than doing glColor3f */
float midX, midY, midZ;

   k = 0;
   lasti = lastj = -1;

   for (i = 0; i < nresidues; i++)
   {
      natoms = residues[i].natoms;
      for (j = 0; j < natoms; j++)
      {
         if (strcmp(residues[i].atoms[j].name, bbone[k]) == 0)
         {
            if ((lasti >= 0) && (lastj >= 0))
            {
               /* calculate the vector from atom 1 to atom 2 */
               midX =  residues[i].atoms[j].x - residues[lasti].atoms[lastj].x;
               midY =  residues[i].atoms[j].y - residues[lasti].atoms[lastj].y;
               midZ =  residues[i].atoms[j].z - residues[lasti].atoms[lastj].z;

               midX /= 2.;
               midY /= 2.;
               midZ /= 2.;

               /* compute the midpoint */
               midX = residues[lasti].atoms[lastj].x + midX;
               midY = residues[lasti].atoms[lastj].y + midY;
               midZ = residues[lasti].atoms[lastj].z + midZ;

               color[0] = residues[lasti].atoms[lastj].r;
               color[1] = residues[lasti].atoms[lastj].g;
               color[2] = residues[lasti].atoms[lastj].b;
               glColor3fv(color);

               drawCylinderVec
                  (
                     obj,
                     residues[lasti].atoms[lastj].x,
                     residues[lasti].atoms[lastj].y,
                     residues[lasti].atoms[lastj].z,
                     midX, midY, midZ, STICK_RADIUS
                  );

               color[0] = residues[i].atoms[j].r;
               color[1] = residues[i].atoms[j].g;
               color[2] = residues[i].atoms[j].b;

               glColor3fv(color);

               drawCylinderVec
                 (
                    obj,
                    midX, midY, midZ,
                    residues[i].atoms[j].x,
                    residues[i].atoms[j].y,
                    residues[i].atoms[j].z,
                    STICK_RADIUS
                 );
            }

            lasti = i;
            lastj = j;

            k = (k+1)%3;
         }
      }
   }
}

/*
 * Draws spheres with specified color
 */
void drawColoredSpheres(GLUquadricObj *obj, residue *residues, int nresidues, float scale, float fixedrad, float *sphereColor[3])
{
   /* local variables */
   int i, j, natoms;
   float  color[3]; /* smaller function profiles than doing glColor3f */

   for (i = 0; i < nresidues; i++)
   {
      natoms = residues[i].natoms;
      for (j = 0; j < natoms; j++)
      {
         glPushMatrix();

         /* translate the sphere */
         glTranslatef
            (
               residues[i].atoms[j].x,
               residues[i].atoms[j].y,
               residues[i].atoms[j].z
            );

         if (sphereColor != NULL)
         {
            glColor3fv(sphereColor);
         } 
         else 
         {
            color[0] = residues[i].atoms[j].r;
            color[1] = residues[i].atoms[j].g;
            color[2] = residues[i].atoms[j].b;

            glColor3fv(color);
         }

         /* draw the sphere */
         if (fixedrad > 0)
            gluSphere(obj, fixedrad, 16, 16);
         else
            gluSphere(obj, residues[i].atoms[j].radius/scale, 16, 16);

         glPopMatrix();
      } /* end for (j < natoms) */

   } /* end for (i < nresidues) */ 
}

/* 
 * Draws sticks with specified color
 */
void drawColoredSticks (GLUquadricObj *obj, residue *residues, int nresidues, bond *bonds, int nbonds, float *sticksColor, float radius)
{
   /* local variables */
   int i;
   float midX, midY, midZ;
   float color[3];

   for (i = 0; ((bonds)&&(i < nbonds)); i++)
   {

      /* we will draw 2 lines, one from start to mid and one from mid to end   */

      /* calculate the vector from atom 1 to atom 2 */
      midX =  residues[bonds[i].r2].atoms[bonds[i].a2].x
                        - residues[bonds[i].r1].atoms[bonds[i].a1].x;
      midY =  residues[bonds[i].r2].atoms[bonds[i].a2].y
                        - residues[bonds[i].r1].atoms[bonds[i].a1].y;
      midZ =  residues[bonds[i].r2].atoms[bonds[i].a2].z
                        - residues[bonds[i].r1].atoms[bonds[i].a1].z;

      midX /= 2.;
      midY /= 2.;
      midZ /= 2.;

      /* compute the midpoint */
      midX = residues[bonds[i].r1].atoms[bonds[i].a1].x
                    + midX;
      midY = residues[bonds[i].r1].atoms[bonds[i].a1].y
                    + midY;
      midZ = residues[bonds[i].r1].atoms[bonds[i].a1].z
                    + midZ;

      /* first half of the line */
      /**************************/

      if (sticksColor != NULL) 
      {
         glColor3fv(sticksColor);
      } 
      else 
      {
         color[0] = residues[bonds[i].r1].atoms[bonds[i].a1].r;
         color[1] = residues[bonds[i].r1].atoms[bonds[i].a1].g;
         color[2] = residues[bonds[i].r1].atoms[bonds[i].a1].b;
         glColor3fv(color);
      }

      drawCylinderVec
         (
            obj,
            residues[bonds[i].r1].atoms[bonds[i].a1].x,
            residues[bonds[i].r1].atoms[bonds[i].a1].y,
            residues[bonds[i].r1].atoms[bonds[i].a1].z,
            midX, midY, midZ, radius
         );

      /* second half of the line */
      /***************************/
      if (sticksColor != NULL) 
      {
         glColor3fv(sticksColor);
      } 
      else 
      {
         color[0] = residues[bonds[i].r2].atoms[bonds[i].a2].r;
         color[1] = residues[bonds[i].r2].atoms[bonds[i].a2].g;
         color[2] = residues[bonds[i].r2].atoms[bonds[i].a2].b;
         glColor3fv(color);
      }

      drawCylinderVec
         (
            obj, midX, midY, midZ,
            residues[bonds[i].r2].atoms[bonds[i].a2].x,
            residues[bonds[i].r2].atoms[bonds[i].a2].y,
            residues[bonds[i].r2].atoms[bonds[i].a2].z,
            radius
         );

   } /* end for (i < natoms) */
}

void drawSpheres(GLUquadricObj *obj, residue *residues, int nresidues, float scale, float fixedrad)
{
   drawColoredSpheres(obj, residues, nresidues, scale, fixedrad, NULL);
} /* end function drawSpheres */

void drawSticks (GLUquadricObj *obj, residue *residues, int nresidues, bond *bonds, int nbonds)
{
   drawColoredSticks(obj, residues, nresidues, bonds, nbonds, NULL, STICK_RADIUS);
}

void drawCustomBonds(GLUquadricObj *obj, residue *residues, int nresidues, bond *bonds, int nbonds, float range[4], float scale)
{
   /* local variables */
   /*******************/
   float color[3];
   int i;

   for (i = 0; ((bonds)&&(i < nbonds)); i++)
   {
      getColor
        (
           &color[0],
           &color[1],
           &color[2],
            bonds[i].length,
            range
        );

      if (bonds[i].a1 != bonds[i].a2 || bonds[i].r1 != bonds[i].r2)
      {
         glColor3fv(color);
         drawCylinderVec
            (
               obj,
               residues[bonds[i].r1].atoms[bonds[i].a1].x,
               residues[bonds[i].r1].atoms[bonds[i].a1].y,
               residues[bonds[i].r1].atoms[bonds[i].a1].z,
               residues[bonds[i].r2].atoms[bonds[i].a2].x, 
               residues[bonds[i].r2].atoms[bonds[i].a2].y, 
               residues[bonds[i].r2].atoms[bonds[i].a2].z,
               STICK_RADIUS
            );
      }
      else 
      {
         glPushMatrix(); 

         glTranslatef
            (
               residues[bonds[i].r1].atoms[bonds[i].a1].x,
               residues[bonds[i].r1].atoms[bonds[i].a1].y,
               residues[bonds[i].r1].atoms[bonds[i].a1].z
            );
         glColor3fv(color);
         gluSphere(obj, residues[bonds[i].r1].atoms[bonds[i].a1].radius/scale + 0.01, 16, 16);

         glPopMatrix();
      }

   } /* end for (i < natoms) */

}

/****************************************************************************
 * FUNCTION:  drawAtoms  -- draws the atoms that make up the molecule       *
 *                                                                          *
 * INPUTS:    residues      --residues making up the molecule               *
 *            nresidues     --number of residues in the molecule            *
 *            bonds         --predicted bonds                               *
 *            nbonds        --number of predicted bonds                     *
 *            selected_res  --the currently selected residue                *
 *            DrawMode      --method of displaying the molecule             *
 *                                                                          *
 * OUTPUTS:   none                                                          *
 *                                                                          *
 ****************************************************************************/
void drawAtoms (residue *residues, int nresidues, bond *bonds, int nbonds, int selected_res, int DrawMode)
{
   /* local variables */
   /*******************/

   GLUquadricObj *obj;

   obj = gluNewQuadric();

   if (obj == 0)
   {
      fprintf(stderr, "Error allocating memory to draw a sphere, no memory.  Exiting.");
      exit(1);
   }

   gluQuadricOrientation(obj, GLU_OUTSIDE);
   gluQuadricDrawStyle(obj, GLU_FILL);
   if (DrawMode == A_DRAW_SPACEFILL)
   {
      drawSpheres (obj, residues, nresidues, 1.0, -1.);
   } 
   else if (DrawMode == A_DRAW_STICKS)
   {
      drawSpheres (obj, residues, nresidues, 1., .1);
      drawSticks (obj, residues, nresidues, bonds, nbonds);
   } 
   else if (DrawMode == A_DRAW_BALL_STICK)
   {
      drawSpheres (obj, residues, nresidues, 7.0, -1.);
      drawSticks (obj, residues, nresidues, bonds, nbonds);
   }
   else if (DrawMode == A_DRAW_BACKBONE)
   {
      drawBackbone(obj, residues, nresidues);
   }

   gluDeleteQuadric(obj);

} /* end draw function */


void drawAtomsWithBonds(residue *residues, int nresidues, bond *bonds, int nbonds, bond *cust_bonds, int ncust_bonds, int selected_res, int DrawMode, float range[4], int customBondsOnly) 
{
   /* local variables */
   /*******************/

   GLUquadricObj *obj;

   obj = gluNewQuadric();

   if (obj == 0)
   {
      fprintf(stderr, "Error allocating memory to draw a sphere, no memory.  Exiting.");
      exit(1);
   }

   gluQuadricOrientation(obj, GLU_OUTSIDE);
   gluQuadricDrawStyle(obj, GLU_FILL);
   if (DrawMode == A_DRAW_CUSTOM_BONDS) 
   { 
      if (!customBondsOnly) {
         float sphereColor[3] = {1.0, 1.0, 0};
         drawColoredSpheres (obj, residues, nresidues, 7.0, -1., sphereColor);
         float sticksColor[3] = {1.0, 1.0, 0};
         drawColoredSticks (obj, residues, nresidues, bonds, nbonds, sticksColor, SMALL_STICK_RADIUS);
      }
      drawCustomBonds (obj, residues, nresidues, cust_bonds, ncust_bonds, range, 7.0);
   }

   gluDeleteQuadric(obj);
}
