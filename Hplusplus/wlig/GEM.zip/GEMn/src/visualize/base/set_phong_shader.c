/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

#include "GLee.h"         /* for dynamic extension loading     */
#include "vis_defines.h"  /* for constants used for widget creation */
#include "structures.h"   /* vertx data type and such    */
#include "visualize.h"    /* for vis_data_struct         */
#include "calculations.h" /* for cosine_v, etc           */
#include "tellUser.h"     /* for tellUser, to simplify error reporting */
#include <math.h>         /* for sqrt                    */
#include <stdio.h>        /* for printf, fprintf         */
#include <stdlib.h>       /* for calloc, exit            */
#include "vertex_shader.h"
#include "fragment_shader.h"

void set_phong_shader (GL_shader_def_struct *shader)
{
   char *vcode, *fcode;

   vcode = VERTEX_SHADER_CODE;
   fcode = FRAGMENT_SHADER_CODE;

   if (GLEE_VERSION_2_0)
   {
      shader->type = 2;

      glEnable(GL_VERTEX_SHADER);
      shader->in.gl2.vertex_shader  = glCreateShader(GL_VERTEX_SHADER);
      shader->in.gl2.fragment_shader = glCreateShader(GL_FRAGMENT_SHADER);

      glShaderSource(shader->in.gl2.vertex_shader, 1, &vcode, NULL);
      glShaderSource(shader->in.gl2.fragment_shader, 1, &fcode, NULL);

      /* no need to free static data of course */
      glCompileShader(shader->in.gl2.vertex_shader);
      glCompileShader(shader->in.gl2.fragment_shader);

      shader->in.gl2.program = glCreateProgram();
      glAttachShader(shader->in.gl2.program, shader->in.gl2.vertex_shader);
      glAttachShader(shader->in.gl2.program, shader->in.gl2.fragment_shader);

      if (shader->in.gl2.program == 0)
      {
         shader->type = 0;

         /* clean up some stuff */
         glDetachShader(shader->in.gl2.program, shader->in.gl2.vertex_shader);
         glDeleteShader(shader->in.gl2.vertex_shader);
         glDetachShader(shader->in.gl2.program, shader->in.gl2.fragment_shader);
         glDeleteShader(shader->in.gl2.fragment_shader);
         glDeleteProgram(shader->in.gl2.program);
      }
      else
      {
         glLinkProgram(shader->in.gl2.program);
         glUseProgram(shader->in.gl2.program);
      }

   }
   else if ((GLEE_ARB_vertex_shader)&&(GLEE_ARB_fragment_shader))
   {
      shader->type = 1;
      shader->in.arb.vertex_shader=glCreateShaderObjectARB(GL_VERTEX_SHADER_ARB);
      shader->in.arb.fragment_shader=glCreateShaderObjectARB(GL_FRAGMENT_SHADER_ARB);

      glShaderSourceARB(shader->in.arb.vertex_shader,   1, &vcode, NULL);
      glShaderSourceARB(shader->in.arb.fragment_shader, 1, &fcode, NULL);

      /* no need to free static data of course */
      glCompileShaderARB(shader->in.arb.vertex_shader);
      glCompileShaderARB(shader->in.arb.fragment_shader);

      shader->in.arb.program = glCreateProgramObjectARB();
      glAttachObjectARB(shader->in.arb.program, shader->in.arb.vertex_shader);
      glAttachObjectARB(shader->in.arb.program, shader->in.arb.fragment_shader);
  
      if (shader->in.arb.program == 0)
      {
         shader->type = 0;

         /* clean up stuff we allocated */
         glDetachObjectARB(shader->in.arb.program, shader->in.arb.vertex_shader);
         glDeleteObjectARB(shader->in.arb.vertex_shader);
         glDetachObjectARB(shader->in.arb.program, shader->in.arb.fragment_shader);
         glDeleteObjectARB(shader->in.arb.fragment_shader);
         glDeleteObjectARB(shader->in.arb.program);
      }
      else
      {
         glLinkProgramARB(shader->in.arb.program);
         glUseProgramObjectARB(shader->in.arb.program);
      }
   }

   if (shader->type == 0) 
   {
      printf("GEM has not detected a graphics card suitable for supporting hardware light acceleration, redrawing may be slow.\n");
   }

}
