/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

#include <string.h>
#include <stdlib.h>
#include "structures.h"
#include "defines.h"
#include "visualize.h"

/****************************************************************************
 * FUNCTION: get_vis_struct   -- allocates, initializes, and returns a      *
 *                               vis_data_struct                            *
 *                                                                          *
 * INPUTS:  residues  -- residues in a molecule to represent                *
 *          vert      -- vertices on the surface of the molecule            *
 *          tri       -- triangles (triples of vertices on the surface)     *
 *          nres      -- number of residues in the molecule                 *
 *          nvert     -- number of vertices on the surface of the molecule  *
 *          ntri      -- number of triangles on the surface of the molecule *
 *                                                                          *
 * RETURNS: a vis_data_struct populated with defaults and the data passed in*
 *               CALLER IS RESPONSIBLE FOR THE MEMORY ALLOCATED HERE        *
 *                                                                          *
 ****************************************************************************/
vis_data_struct *get_vis_struct(residue *residues, vertx *vert, triangle *tri, int
nres, int nvert, int ntri)
{
   /* local variables */
   vis_data_struct *vis;

   vis = (vis_data_struct *)calloc(sizeof(vis_data_struct), 1);
   vis->mol_data.residues     = residues;
   vis->mol_data.nresidues    = nres;
   vis->mol_data.vert         = vert;
   vis->mol_data.nvert        = nvert;
   vis->mol_data.tri          = tri;
   vis->mol_data.ntri         = ntri;
   vis->mol_data.ion_exc_rad  = 2.0;
   vis->mol_data.phiType      = TOTAL_POTENTIAL;

   vis->params.scale        = 1.;
   vis->params.selected_res = -1;
   vis->params.surfDrawMode = S_DRAW;
   vis->params.bg_color[0]  = .8;
   vis->params.bg_color[1]  = .8;
   vis->params.bg_color[2]  = .8;

   /* default values before population of statistics */
   vis->params.x[EXTENT] = 1;
   vis->params.y[EXTENT] = 1;
   vis->params.z[EXTENT] = 1;

   populate_statistics(vis);

   return vis;
}

/****************************************************************************
 * FUNCTION: free_vis_struct  -- deallocates a vis_data_struct and the      *
 *                                    dynamic memory within it              *
 *                                                                          *
 * INPUTS:  vis  -- a vis data struct to be freed                           *
 *                                                                          *
 * RETURNS: nothing                                                         *
 *                                                                          *
 ****************************************************************************/
void free_vis_struct (vis_data_struct *vis)
{

   clear_moldata (&vis->mol_data);
   clear_decor_mol (&vis->decor_mol);

   free(vis);
}

/****************************************************************************
 * FUNCTION: clear_moldata  -- clears all molecule specific data from a mol *
 *                                    data struct                           *
 *                                                                          *
 * INPUTS:  moldata -- a mol data struct to be cleared                      *
 *                                                                          *
 * RETURNS: nothing                                                         *
 *                                                                          *
 ****************************************************************************/
void clear_moldata (mol_data_struct *moldata)
{
   int i;

   if (moldata->residues != NULL)
   {
      for (i = 0; i < moldata->nresidues; i++)
      {
          free(moldata->residues[i].atoms);
      }

      free(moldata->residues);
      moldata->residues = NULL;
   }
   moldata->nresidues = 0;

   if (moldata->vert != NULL)
   {
      free(moldata->vert);
      moldata->vert = NULL;
   }
   moldata->nvert = 0;

   if (moldata->tri != NULL)
   {
      free(moldata->tri);
      moldata->tri=NULL;
   }
   moldata->ntri = 0;

   if (moldata->bonds != NULL)
   {
      free(moldata->bonds);
      moldata->bonds = NULL;
   }
   moldata->nbonds = 0;

   if (moldata->grid != NULL)
   {
      free(moldata->grid);
      moldata->grid = NULL;
   }
   moldata->grid_x_dim = moldata->grid_y_dim = moldata->grid_z_dim = 0;

   if (moldata->molname != NULL)
   {
      free(moldata->molname);
      moldata->molname = NULL;
   }

   if (moldata->cust_bonds != NULL)
   {
      free(moldata->cust_bonds);
      moldata->cust_bonds = NULL;
   }
   moldata->ncust_bonds = 0;

}

/****************************************************************************
 * FUNCTION: clear_decor_mol  -- clears all molecule specific data from a   *
 *                                    decor mol data struct                 *
 *                                                                          *
 * INPUTS:  decormol  -- decor mol data struct to be cleared                *
 *                                                                          *
 * RETURNS: nothing                                                         *
 *                                                                          *
 ****************************************************************************/
void clear_decor_mol (decor_mol_data_struct *decormol)
{
   int i;

   if (decormol->residues != NULL)
   {
      for (i = 0; i < decormol->nresidues; i++)
      {
          free(decormol->residues[i].atoms);
      }

      free(decormol->residues);
      decormol->residues = NULL;
   }
   decormol->nresidues = 0;

   if (decormol->vert != NULL)
   {
      free(decormol->vert);
      decormol->vert = NULL;
   }
   decormol->nvert = 0;

   if (decormol->tri != NULL)
   {
      free(decormol->tri);
      decormol->tri=NULL;
   }
   decormol->ntri = 0;

   if (decormol->bonds != NULL)
   {
      free(decormol->bonds);
      decormol->bonds = NULL;
   }
   decormol->nbonds = 0;

}
