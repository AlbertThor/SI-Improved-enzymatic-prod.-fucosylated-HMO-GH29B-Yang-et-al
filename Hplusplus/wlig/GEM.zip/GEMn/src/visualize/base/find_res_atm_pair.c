/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include "visualize.h"

/* Since atoms are indexed sequentially, we have a single index available through
 * glPushName, and msms attaches a single linear index for the nearest_atom value.
 * What we need is the residue/atom pair based on the linear index of the atom.
 * if we do selection better this file may get snipped out in the long run.
 */

/****************************************************************************
 * FUNCTION: find_res_atm_pair  -- finds the <res, atm> index corresponding *
 *                                 to a linear atom index                   *
 *                                                                          *
 * INPUTS:    residues  -- the residues making up the molecule              *
 *            nres  -- the number of residues making up the molecule        *
 *            lin  -- the linear index of the atom                          *
 *                                                                          *
 * OUTPUTS:   res  -- the residue index value                               *
 *            atm  -- the atom index into the given residue                 *
 *                                                                          *
 * RETURNS:   nothing                                                       *
 *                                                                          *
 ****************************************************************************/
void find_res_atm_pair(residue *residues, int nres, int lin, int *res, int *atm)
{
   /* local variables */
   int i;
   int count;

   *res = -1;
   *atm = -1;

   /* skip the for loop for worst case -> best case */
   if (lin < 0) return;

   for (i = count = 0; i < nres; i++)
   {
       if ((lin >= count) && (lin < count + residues[i].natoms))
       {
          *res = i;
          *atm = lin - count;
          return;
       }

       count += residues[i].natoms;
   }

   count = find_linear_index(residues, *res, *atm);
}

/****************************************************************************
 * FUNCTION: find_linear_index  -- finds the linear index corresponding     *
 *                                 to a <res, atm> pair index               *
 *                                                                          *
 * INPUTS:    residues -- the residues making up the molecule               *
 *            res  -- the residue index value                               *
 *            atm  -- the atom index into the given residue                 *
 *                                                                          *
 * RETURNS:   linear index corresponding to the <res, atm> pair             *
 *                                                                          *
 * ASSERTS:   res < number of residues in residues array                    *
 *                                                                          *
 ****************************************************************************/
int find_linear_index (residue *residues, int res, int atm)
{
   /* local variables */
   int i,      /* residue index */
       count;  /* atom indexes used up */

   for (count = atm, i = res-1; i >= 0; i--)
   {
       count += residues[i].natoms;
   }

   return count;
}
