/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

/************************************************************************
 * Terminal screenshot serves the purpose of providing a drawing of the *
 * molecule from the terminal, preventing redraw events and other nasty *
 * things from occurring on large scale molecules that might end up     *
 * making it nigh impossible to view without babysitting the process.   *
 * as an added bonus it may enable us to take pictures at higher than   *
 * screen resolution. STILL NEEDS CONNECTION TO THE X SERVER THOUGH     *
 ***********************************************************************/

#include <stdlib.h>
#include "GLee.h"
#include "visualize.h"
#include "vis_defines.h"
#include "tellUser.h"
#include "file_io.h"

/************************************************************************
 * FUNCTION: screenshot_pbuff  -- renders into a pbuffer then writes to *
 *                          uncompressed TGA image --not working on OSX *
 *                          (need APPLE_pbuffer stuff here to do that)  *
 *                                                           <><>       *
 *                                                                      *
 * INPUTS: vis  -- the vis data struct (everything)                     *
 *         width --  the width of the image to write                    *
 *         height -- the height of the image to write                   *
 *         fname  -- the name of the file to write to                   *
 *                                                                      *
 * RETURNS: 1 on success, 0 on failure                                  *
 *
 * CAVEATS: this is really dirty code, need to seriously refactor
            this drawing code around screenshots and the default visual
            this also leaks like a seive if any errors occur            *
 ************************************************************************/
int screenshot_pbuff (vis_data_struct *vis, int width, int height, char *fname)
{
/* local variables */
/*******************/
FILE          *fp;
unsigned char *pixels;
Display       *dpy;
XVisualInfo   *visinfo;
GLXFBConfig   *fbconfig;
GLXContext    GLcontext_draw,
              GLcontext_color;
GLXPbuffer    pbuffer_draw,  /* main drawing area */
              pbuffer_color; /* color area        */

int           errors, events;

XFontStruct  *font = NULL;


/* attributes to get the visual info */
int nitems;
static int attrib[] = 
                       {
                        GLX_DOUBLEBUFFER,  False,
                        GLX_RED_SIZE,      8,
                        GLX_GREEN_SIZE,    8,
                        GLX_BLUE_SIZE,     8,
                        GLX_DEPTH_SIZE,    24,
                        GLX_RENDER_TYPE,   GLX_RGBA_BIT,
                        GLX_DRAWABLE_TYPE, GLX_PBUFFER_BIT,
                        None
                       };

int pbuff_attrib_draw[7] = 
                       {
                        GLX_PBUFFER_WIDTH,   width,
                        GLX_PBUFFER_HEIGHT,  height,
                        GLX_LARGEST_PBUFFER, False,
                        None
                       };
int pbuff_attrib_colr[7] = 
                       {
                        GLX_PBUFFER_WIDTH,   width,
                        GLX_PBUFFER_HEIGHT,  VIS_COLORBAR_HEIGHT,
                        GLX_LARGEST_PBUFFER, False,
                        None
                       };
/* material and environment settings */

   dpy = XOpenDisplay(NULL); /* defaults to DISPLAY environment variable */

   if (dpy == NULL)
   {
      tellUser("Error", "Could not locate a usable display to write image.\n");
      return 0;
   }

   /* need glx to do this */
   if (!glXQueryExtension(dpy, &errors, &events))
   {
      tellUser("Error", "Writing images requires the glX extension.\n");
      return 0;
   }

   fbconfig = glXChooseFBConfig(dpy, DefaultScreen(dpy), attrib, &nitems);

   if (fbconfig == NULL)
   {
      tellUser("Error", "Could not locate a usable frame buffer to write image.\n");
      return 0;
   }

   pbuffer_draw = glXCreatePbuffer(dpy, fbconfig[0], pbuff_attrib_draw);
   if (!pbuffer_draw)
   {
      tellUser("Error", "Could not allocate a pixel buffer for offscreen rendering");
      return 0;
   }


   pbuffer_color = glXCreatePbuffer(dpy, fbconfig[0], pbuff_attrib_colr);
   if (!pbuffer_color)
   {
      tellUser("Error", "Could not allocate a pixel buffer for offscreen rendering");
      return 0;
   }

   visinfo = glXGetVisualFromFBConfig(dpy, fbconfig[0]);
   if (!visinfo)
   {
      tellUser("Error", "Invalid frame buffer configuration returned by GL.");
      return 0;
   }

   GLcontext_draw = glXCreateContext(dpy, visinfo, NULL, GL_TRUE);
   if (!GLcontext_draw)
   {
      tellUser("Error", "Unable to create a drawable context in OpenGL.");
      return 0;
   }
   GLcontext_color = glXCreateContext(dpy, visinfo, NULL, GL_TRUE);
   if (!GLcontext_color)
   {
      tellUser("Error", "Unable to create a drawable context in OpenGL.");
      return 0;
   }

   /* none of this is worth anything if we can't open the output file */
   if ((fp=fopen(fname, "wb"))==NULL)
   {
      tellUser("Error", "Could not open the tga file to write\n");
      return 0;
   }

   /* write the header for the tga file */
   /*************************************/
   TGA_header(fp, width, height+VIS_COLORBAR_HEIGHT);


   if (!glXMakeCurrent(dpy, pbuffer_color, GLcontext_color))
   {
      tellUser("Error", "Unable to write the image due to internal error.\n");
      return 0;
   }

   /* initialize color map needs */
   font = vis->params.font;
   vis->params.font = initialize_gl_fonts(dpy);
   glClearColor(vis->params.bg_color[0],vis->params.bg_color[1],vis->params.bg_color[2],1.); /* background */
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(-1,1,-1,0,-1,1);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();

   /* draw colormap only */
   glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
   just_draw_color_map(vis, width, VIS_COLORBAR_HEIGHT);
   glFlush();

   /* capture images from pixmap */
   /******************************/
   pixels = (unsigned char *)calloc(width*height*4, sizeof(char));
   if (!pixels)
   {
      tellUser("Error", "Not enough memory to store the image to write.\n");
      return 0;
   }

   glReadPixels(0,0,width,VIS_COLORBAR_HEIGHT,GL_RGBA,GL_UNSIGNED_BYTE,pixels);

   TGA_bytes(fp, width, VIS_COLORBAR_HEIGHT, pixels);

   free(pixels);

   /* move on to the main drawing area */
   if (!glXMakeCurrent(dpy, pbuffer_draw, GLcontext_draw))
   {
      tellUser("Error", "Unable to write the image due to internal error.\n");
      return 0;
   }

   init_current_context_draw(vis);

   updateTranslations(vis, 1, 0);

    /* dump images to the pixmap */
    /*****************************/
      drawAtoms
         (
            vis->mol_data.residues, vis->mol_data.nresidues,
            vis->mol_data.bonds, vis->mol_data.nbonds,
            vis->params.selected_res, vis->params.atomDrawMode
         );
      drawSurface
         (
            vis->mol_data.vert, vis->mol_data.nvert,
            vis->mol_data.tri, vis->mol_data.ntri,
            vis->mol_data.residues, vis->mol_data.nresidues,
            vis->params.selected_res, vis->params.surfDrawMode,
            vis->params.trans
         );

      /* draw the decoration molecule's atoms and surface */
      drawAtoms
         (
            vis->decor_mol.residues, vis->decor_mol.nresidues,
            vis->decor_mol.bonds, vis->decor_mol.nbonds,
            -1, vis->decor_mol.atomDrawType
          );

       drawSurface
          (
             vis->decor_mol.vert, vis->decor_mol.nvert,
             vis->decor_mol.tri, vis->decor_mol.ntri,
             vis->decor_mol.residues, vis->decor_mol.nresidues,
             -1, vis->decor_mol.surfaceDrawType,
             .25
          );

    glFlush();

    /* capture images from pixmap */
    /******************************/
    pixels = (unsigned char *)calloc(width*height*4, sizeof(char));
    if (!pixels)
    {
       tellUser("Error", "Not enough memory to store the image to write.\n");
       return 0;
    }

    glReadPixels(0,0,width,height,GL_RGBA,GL_UNSIGNED_BYTE,pixels);

    TGA_bytes(fp, width, height, pixels);
    free(pixels);

    fclose(fp);

    /* clean up GL stuff*/
    /********************/
    glXMakeCurrent(dpy, None, NULL);
    glXDestroyContext(dpy, GLcontext_draw);
    glXDestroyContext(dpy, GLcontext_color);
    glXDestroyPbuffer(dpy, pbuffer_draw);
    glXDestroyPbuffer(dpy, pbuffer_color);
    if (vis->params.font != NULL) XFreeFont(dpy, vis->params.font);
    vis->params.font = font;
    XCloseDisplay(dpy);

    XFree (fbconfig);
    XFree (visinfo);

    return 1;
}

/************************************************************************
 * FUNCTION: screenshot_framebuff  -- renders into an OpenGL framebuffer*
 *                                    object, neutral to OS as long as  *
 *                                    the driver and OpenGL support it. *
 *                                                                      *
 * INPUTS: vis  -- the vis data struct (everything)                     *
 *         width --  the width of the image to write                    *
 *         height -- the height of the image to write                   *
 *         fname  -- the name of the file to write to                   *
 *                                                                      *
 * RETURNS: 1 on success, 0 on failure                                  *
 *
 * CAVEATS: this is really dirty code, need to seriously refactor
            this drawing code around screenshots and the default visual
            this also leaks like a seive if any errors occur            *
 ************************************************************************/
int screenshot_framebuff (vis_data_struct *vis, int width, int height, char *fname)
{
/* local variables */
/*******************/
FILE          *fp;
unsigned char *pixels = NULL;
GLuint        framebuffer, 
              renderbuffers[2];
int           to_return = 0;

   if (!GLEE_EXT_framebuffer_object) return 0;

   glPushAttrib(GL_ALL_ATTRIB_BITS);

   /* build the renderbuffers */
   glGenFramebuffersEXT(1, &framebuffer);
   glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, framebuffer);
   glGenRenderbuffersEXT(2, renderbuffers);

   glBindRenderbufferEXT(GL_RENDERBUFFER_EXT, renderbuffers[0]);
   glRenderbufferStorageEXT(GL_RENDERBUFFER_EXT, GL_DEPTH_COMPONENT24, width, height);
   glFramebufferRenderbufferEXT(GL_FRAMEBUFFER_EXT, GL_DEPTH_ATTACHMENT_EXT,
                                 GL_RENDERBUFFER_EXT, renderbuffers[0]);

   glBindRenderbufferEXT(GL_RENDERBUFFER_EXT, renderbuffers[1]);
   glRenderbufferStorageEXT(GL_RENDERBUFFER_EXT, GL_RGBA8, width, height);
   glFramebufferRenderbufferEXT(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT, 
                                 GL_RENDERBUFFER_EXT, renderbuffers[1]);

   if (GL_FRAMEBUFFER_COMPLETE_EXT != glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT))
   {
      goto cleanup;
   }

   pixels = (unsigned char *)calloc(width*height*4, sizeof(char));
   if (!pixels)
   {
      tellUser("Error", "Not enough memory to store the image to write.\n");
      goto cleanup;
   }

   // else

   /* none of this is worth anything if we can't open the output file */
   if ((fp=fopen(fname, "wb"))==NULL)
   {
      tellUser("Error", "Could not open the tga file to write\n");
      goto cleanup;
   }

   /* write the header for the tga file */
   /*************************************/
   TGA_header(fp, width, height+VIS_COLORBAR_HEIGHT);

   //<><>
   //vis->params.font = initialize_gl_fonts(dpy);
   glClearColor(vis->params.bg_color[0],vis->params.bg_color[1],vis->params.bg_color[2],1.); /* background */
   glDisable(GL_LIGHTING);
   glDisable(GL_DEPTH_TEST);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(-1,1,-1,0,-1,1);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();

   glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

   /* draw colormap only */
   just_draw_color_map(vis, width, VIS_COLORBAR_HEIGHT);
   glFlush();

   /* capture images from pixmap */
   /******************************/

   glReadPixels(0,0,width,VIS_COLORBAR_HEIGHT,GL_RGBA,GL_UNSIGNED_BYTE, pixels);

   TGA_bytes(fp, width, VIS_COLORBAR_HEIGHT, pixels);

   init_current_context_draw(vis);
   updateTranslations(vis, 1, 0);

   glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);


    /* dump images to the pixmap */
    /*****************************/
      drawAtoms
         (
            vis->mol_data.residues, vis->mol_data.nresidues,
            vis->mol_data.bonds, vis->mol_data.nbonds,
            vis->params.selected_res, vis->params.atomDrawMode
         );
      drawSurface
         (
            vis->mol_data.vert, vis->mol_data.nvert,
            vis->mol_data.tri, vis->mol_data.ntri,
            vis->mol_data.residues, vis->mol_data.nresidues,
            vis->params.selected_res, vis->params.surfDrawMode,
            vis->params.trans
         );

      /* draw the decoration molecule's atoms and surface */
      drawAtoms
         (
            vis->decor_mol.residues, vis->decor_mol.nresidues,
            vis->decor_mol.bonds, vis->decor_mol.nbonds,
            -1, vis->decor_mol.atomDrawType
          );

       drawSurface
          (
             vis->decor_mol.vert, vis->decor_mol.nvert,
             vis->decor_mol.tri, vis->decor_mol.ntri,
             vis->decor_mol.residues, vis->decor_mol.nresidues,
             -1, vis->decor_mol.surfaceDrawType,
             .25
          );

    glFlush();

    glReadPixels(0,0,width,height,GL_RGBA,GL_UNSIGNED_BYTE, pixels);

    TGA_bytes(fp, width, height, pixels);

    fclose(fp);
    
    to_return = 1;

    /* clean up GL stuff*/
    /********************/
cleanup:
    if (pixels) free(pixels);
    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
    glDeleteRenderbuffersEXT(2, renderbuffers);
    glDeleteFramebuffersEXT(1, &framebuffer);
    glPopAttrib();

    return to_return;
}
