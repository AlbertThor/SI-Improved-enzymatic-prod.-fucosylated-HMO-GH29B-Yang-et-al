/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include "visualize.h"
#include "calculations.h"
#include "structures.h"
#include <math.h>

/****************************************************************************
 * FUNCTION: extract_statistics  -- one loop to extract statistics for all  *
 *                                     data contained within vertices/atoms *
 *                                                                          *
 * INPUTS:  res  -- the residues making up the molecule in question         *
 *          nres -- number of residues in the molecule                      *
 *          vert -- vertices composing the surface of the molecule          *
 *          nvert -- number of vertices on the surface of the molecule      *
 *                                                                          *
 * OUTPUTS: x, y, z -- spacial min/max/extents of the molecule min bounding *
 *                     box                                                  *
 *          vp      -- vertex potential min/max/extents for the molecule    *
 *          vc      -- vertex charge min/max/extents for the molecule       *
 *                                                                          *
 ****************************************************************************/
int extract_statistics(residue *res, int nres, vertx *vert, int nvert, 
                        float x[3], float y[3], float z[3], float vp[3], float vc[3])
{
  /* local variables */
  int i; 
  double potential_sum;

  if ((res == NULL) || (vert == NULL) || (nvert < 3))
  {
     /* have to initialize xyz bounds for scales to not be 0 */
     x[MIN] = y[MIN] = z[MIN] = -1;
     x[MAX] = y[MAX] = z[MAX] =  1;
     return 0;
  }

  /* else */

  /* reinitialize to the zeroth element */
  vp[MIN] = vp[MAX] = vert[0].potential;
  vc[MIN] = vc[MAX] = vert[0].surface_charge;
  x[MIN]  = x[MAX]  = vert[0].x;
  y[MIN]  = y[MAX]  = vert[0].y;
  z[MIN]  = z[MAX]  = vert[0].z;

  potential_sum = vert[0].potential*vert[0].potential;
 
  /* seek through and grab our values */
  for (i = 1; i < nvert; i++)
  {
     potential_sum += vert[i].potential*vert[i].potential;

     /* total potential bounds */
     if (vp[MIN] > vert[i].potential)
        vp[MIN] = vert[i].potential;
     else if (vp[MAX] < vert[i].potential)
        vp[MAX] = vert[i].potential;

     /* total charge bounds */
     if (vc[MIN] > vert[i].surface_charge)
        vc[MIN] = vert[i].surface_charge;
     else if (vc[MAX] < vert[i].surface_charge)
        vc[MAX] = vert[i].surface_charge;
   
     /* check x bounds */
     if (x[MIN] > vert[i].x)
        x[MIN] = vert[i].x;
     else if (x[MAX] < vert[i].x)
        x[MAX] = vert[i].x;
   
     /* check y bounds */
     if (y[MIN] > vert[i].y)
        y[MIN] = vert[i].y;
     else if (y[MAX] < vert[i].y)
        y[MAX] = vert[i].y;
   
     /* check z bounds */
     if (z[MIN] > vert[i].z)
        z[MIN] = vert[i].z;
     else if (z[MAX] < vert[i].z)
        z[MAX] = vert[i].z;
   
   } /* end for (i < nvert) */

   potential_sum /= nvert;

   printf("RMSD of total phi values is %f\n", sqrt(potential_sum));
   
   return 1;
} /* end extract statistics function */


void extract_custom_bonds_statistics(bond *bonds, int nbonds, float x[3]) 
{
   /* local variables */
   int i;
   if (bonds == NULL || nbonds == 0) {
      x[MIN] = -1;
      x[MAX] = 1;
      return;
   }

   x[MAX] = 0;
   for (i = 0; i < nbonds; ++i)
   {
      if (fabs(bonds[i].length) > x[MAX]) 
         x[MAX] = fabs(bonds[i].length);
   }
   x[MIN] = -x[MAX];
}


/****************************************************************************
 * FUNCTION: populate_statistics  -- sets vis data values extracted from    *
 *                                   molecular data                         *
 *                                                                          *
 * INPUTS:  vis  -- the visualization data struct                           *
 *                                                                          *
 * OUTPUTS: none                                                            *
 *                                                                          *
 * RETURNS: nothing                                                         *
 *                                                                          *
 ****************************************************************************/
void populate_statistics(vis_data_struct *vis)
{
  /* local variables */
  float dx[4], dy[4], dz[4], 
        rx[4], ry[4], rz[4];
  float midX, midY, midZ, maxExtent, maxRad;
  int res, atm, i;
  int decor_ok, mol_ok;
  
  if (vis == NULL)
     return;

  mol_ok = extract_statistics
      (
         vis->mol_data.residues, vis->mol_data.nresidues,
         vis->mol_data.vert, vis->mol_data.nvert,
         rx, ry, rz, vis->params.vp, vis->params.vc
      );

  decor_ok = get_dimensions
      (
         vis->decor_mol.vert, vis->decor_mol.nvert,
         dx, dy, dz
      );

   if ((!decor_ok)&&(!mol_ok)) return;

   if (!decor_ok)
   {
      memcpy(dx, rx, 4 * sizeof(float));
      memcpy(dy, ry, 4 * sizeof(float));
      memcpy(dz, rz, 4 * sizeof(float));
   }
   else if (!mol_ok)
   {
      memcpy(rx, dx, 4 * sizeof(float));
      memcpy(ry, dy, 4 * sizeof(float));
      memcpy(rz, dz, 4 * sizeof(float));
   }

   //gets statistics for custom bonds
   extract_custom_bonds_statistics
                 (
                    vis->mol_data.cust_bonds,
                    vis->mol_data.ncust_bonds,
                    vis->params.cust_bond_c
                 );

  /* we can estimate the atom potential from vertex potential,
   * right now we are going to ghetto rig it to be pseudo-
   * arbitrary, the value of the last vertex nearest to the
   * atom --jcg  */

   /* note that this is a many to 1 mapping from the many perspective,
      it would be faster to  handle this on a per atom basis if possible */
   for (i = 0; i < vis->mol_data.nvert; i++)
   {
      find_res_atm_pair(vis->mol_data.residues, vis->mol_data.nresidues,
                        vis->mol_data.vert[i].nearest_atom, &res, &atm);
   
      if ( (res >= 0) && (atm >= 0) )
         vis->mol_data.residues[res].atoms[atm].pot_est = vis->mol_data.vert[i].potential;
   }

  /* make sure our physical bounds can contain both molecules */
  vis->params.x[MIN] = min(dx[MIN], rx[MIN]);
  vis->params.x[MAX] = max(dx[MAX], rx[MAX]);
  vis->params.y[MIN] = min(dy[MIN], ry[MIN]);
  vis->params.y[MAX] = max(dy[MAX], ry[MAX]);
  vis->params.z[MIN] = min(dz[MIN], rz[MIN]);
  vis->params.z[MAX] = max(dz[MAX], rz[MAX]);

  /* calculate extents */
  vis->params.x[EXTENT] = vis->params.x[MAX] - vis->params.x[MIN];
  vis->params.y[EXTENT] = vis->params.y[MAX] - vis->params.y[MIN];
  vis->params.z[EXTENT] = vis->params.z[MAX] - vis->params.z[MIN];

  vis->params.x[CENTER] = (vis->params.x[MAX] + vis->params.x[MIN])/2.;
  vis->params.y[CENTER] = (vis->params.y[MAX] + vis->params.y[MIN])/2.;
  vis->params.z[CENTER] = (vis->params.z[MAX] + vis->params.z[MIN])/2.;

  midX = vis->params.x[CENTER];
  midY = vis->params.y[CENTER];
  midZ = vis->params.z[CENTER];

  /* we want our viewing area to be a cube, so we should recalculate
   * the extents so that the mid is still in the middle, but x, y, and z
   * each have the same extents */
   maxExtent = max(max(vis->params.x[EXTENT], vis->params.y[EXTENT]), vis->params.z[EXTENT]);
   maxExtent *= 1.3; /* need a bit of elbow room */
   maxRad = maxExtent/2.;

   vis->params.x[MAX] = (midX + maxRad);
   vis->params.x[MIN] = (midX - maxRad);
   vis->params.x[EXTENT] = maxExtent;

   vis->params.y[MAX] = (midY + maxRad);
   vis->params.y[MIN] = (midY - maxRad);
   vis->params.y[EXTENT] = maxExtent;

   vis->params.z[MAX] = (midZ + maxRad);
   vis->params.z[MIN] = (midZ - maxRad);
   vis->params.z[EXTENT] = maxExtent;

  /* output the potential mins and maxes */
  printf("Potential minimum is %f, maximum is %f\n", vis->params.vp[MIN], vis->params.vp[MAX]);

  normalize(&vis->params.vp[MIN],  &vis->params.vp[MAX]);
  vis->params.vp[EXTENT] = vis->params.vp[MAX] - vis->params.vp[MIN];
  vis->params.vp[CENTER] = (vis->params.vp[MAX] + vis->params.vp[MIN])/2.;

  normalize(&vis->params.vc[MIN],  &vis->params.vc[MAX]);
  vis->params.vc[EXTENT] = vis->params.vc[MAX] - vis->params.vc[MIN];
  vis->params.vc[CENTER] = (vis->params.vc[MAX] + vis->params.vc[MIN])/2.;

  vis->params.cust_bond_c[EXTENT] = vis->params.cust_bond_c[MAX] - vis->params.cust_bond_c[MIN];
  vis->params.cust_bond_c[CENTER] = (vis->params.cust_bond_c[MAX] + vis->params.cust_bond_c[MIN])/2.;

  /* set up the colors for the vertices and atoms */
  generate_colors(vis);
   
} /* end populate_statistics function */
