/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

#include <Xm/Xm.h>
#include <Xm/RowColumn.h>
#include <Xm/PushB.h>
#include <Xm/ScrolledW.h>
#include <stdlib.h>
#include "defines.h"
#include "visualize.h"
#include "residue_select_form.h"

static void select_button_pushCB(Widget w, XtPointer clientD, XtPointer callD);

/*******************************************************************************
 * FUNCTION: convert_color_name_to_pixel -- converts a color string to a Pixel *
 *                                                                     color   *
 *                                                                             *
 * INPUTS:   context     - the widget for which we are converting              *
 *                           (used for grapic context)                         *
 *           color_name  - a text string version of the name (e.g. green)      *
 *                           (may be looked up in the RGB table)               *
 *                                                                             *
 * OUTPUTS:  a Pixel that represents the color being sought.                   *
 *                                                                             *
 * CAVEATS:  not every string will always be in the RGB.txt table for every    *
 *            system.                                                          *
 *******************************************************************************/
Pixel convert_color_name_to_pixel (Widget context, char *color_name)
{
/* local variables */
XrmValue from_value,
         to_value;

Pixel to_return = XmUNSPECIFIED_PIXEL;

   from_value.addr = color_name;
   from_value.size = strlen(color_name) + 1;
   to_value.addr = (XtPointer) 0;

   XtConvertAndStore (context, XmRString, &from_value, XmRPixel, &to_value);

   if (to_value.addr != (XtPointer) 0)
   {
      to_return = (*(Pixel *) to_value.addr);
   }

   return to_return;
}

/****************************************************************************
 * FUNCTION: create_residue_select_form  -- creates a form for selecting    *
 *                                            and manipulating residues     *
 *                                                                          *
 * INPUTS:   parent    the parent widget                                    *
 *           vis       everything (vis_data_struct) for redrawing etc       *
 *                                                                          *
 * OUTPUTS:  residue_selection_struct --structure to contain the selected   *
 *                                       residue information                *
 *                                      CALLER RESPONSIBLE FOR MEMORY       *
 *                                                                          *
 ****************************************************************************/
residue_selection_struct *create_residue_select_form(Widget parent, void *vis)
{
/* local variables */
Widget   scrolled_win; /* the scrolled window to build this thing in */
residue_selection_struct *to_return;
Arg args[7];
Cardinal argcount = 0;

   to_return = (residue_selection_struct *)malloc(sizeof(residue_selection_struct));
   to_return->vis_ptr = vis;
   to_return->selected_residue = -1;

   XtSetArg(args[argcount], XmNtopAttachment, XmATTACH_FORM);
   argcount++;
   XtSetArg(args[argcount], XmNleftAttachment, XmATTACH_FORM);
   argcount++;
   XtSetArg(args[argcount], XmNrightAttachment, XmATTACH_FORM);
   argcount++;
   XtSetArg(args[argcount], XmNbottomAttachment, XmATTACH_FORM);
   argcount++;
   XtSetArg(args[argcount], XmNscrollingPolicy, XmAUTOMATIC);
   argcount++;
   XtSetArg(args[argcount], XmNscrollBarDisplayPolicy, XmAS_NEEDED);
   argcount++;
   XtSetArg(args[argcount], XmNvisualPolicy, XmSTATIC);
   argcount++;

   scrolled_win = XmCreateScrolledWindow
                    (
                       parent,
                       "scrolledWin",
                       args,
                       argcount
                    );
   XtManageChild(scrolled_win);

   to_return->rowCol = XtVaCreateManagedWidget
                         (
                            "rowCol",
                            xmRowColumnWidgetClass,
                            scrolled_win,
                            XmNleftAttachment,   XmATTACH_FORM,
                            XmNrightAttachment,  XmATTACH_FORM,
                            XmNtopAttachment,    XmATTACH_FORM,
                            XmNorientation,      XmVERTICAL,
                            XmNmarginHeight,     0,
                            XmNmarginWidth,      0,
                            XmNentryAlignment,   XmALIGNMENT_CENTER,
                            XmNspacing,          0,
                            XmNnumColumns,       1,
                            XmNpacking,          XmPACK_COLUMN,
                            NULL
                         );

   argcount = 0;
   XtSetArg(args[argcount], XmNworkWindow, to_return->rowCol);
   argcount++;
   XtSetValues(scrolled_win, args, argcount);

   /* now we have the toplevel sections set up */
   /* populate color data for selected and non-selected widgets */
   /* for now let's just set the bg color and see what Motif does
    * for the FG colors */
   XtVaGetValues(to_return->rowCol, XmNbackground,&to_return->normal_bg_color, NULL);
   to_return->select_bg_color =convert_color_name_to_pixel
                                 (to_return->rowCol, (char *)"light blue");

   return to_return;
}

/****************************************************************************
 * FUNCTION: fill_residue_select_form  -- fills the residue select form     *
 *                                                                          *
 * INPUTS:   res   -the residue select form data structure                  *
 *                                                                          *
 * OUTPUTS:  nothing                                                        *
 *                                                                          *
 ****************************************************************************/
void fill_residue_select_form (residue_selection_struct *res)
{
/* local variables */
int i;
XmString label;
Widget this_wid;
char buffer[256];
int selected;
Pixel nbg, sbg;
vis_data_struct *vis;
Arg args[3];

   if ((res == NULL) || (res->vis_ptr == NULL)) return;

   vis = (vis_data_struct *) res->vis_ptr;

   if (vis->mol_data.nresidues < 1) return;

   selected = vis->params.selected_res;
   nbg = res->normal_bg_color;
   sbg = res->select_bg_color;

   label = XmStringCreateLocalized("None");

   XtSetArg(args[0], XmNlabelString, label);
   XtSetArg(args[1], XmNuserData, -1);
   XtSetArg(args[2], XmNbackground, nbg);

   /*
    * just using XtCreate because this is a repetitive statement and
    * XtCreate is faster than XtVaCreate due to the intrinsic parsing
    * in VaArgLists --jcg
    */
   this_wid = XtCreateManagedWidget
                (
                    "residue push button",
                    xmPushButtonWidgetClass,
                    res->rowCol,
                    args, 3
                );
   XmStringFree(label);
   XtAddCallback(this_wid, XmNactivateCallback, select_button_pushCB, res);

   for (i = 0; i < vis->mol_data.nresidues; i++)
   {
       sprintf
         (
           buffer,
           "%s %i (charge = %2.2f)",
           vis->mol_data.residues[i].name, 
           vis->mol_data.residues[i].res_num,
           vis->mol_data.residues[i].total_charge/ELECTROSTATIC_CONVERSION_FACTOR
         );

       label = XmStringCreateLocalized(buffer);

       XtSetArg(args[0], XmNlabelString, label);
       XtSetArg(args[1], XmNuserData, i);
       XtSetArg(args[2], XmNbackground, ((i == selected)? sbg:nbg));

       /*
        * just using XtCreate because this is a repetitive statement and
        * XtCreate is faster than XtVaCreate due to the intrinsic parsing
        * in VaArgLists --jcg
        */
       this_wid = XtCreateManagedWidget
                    (
                        "residue push button",
                        xmPushButtonWidgetClass,
                        res->rowCol,
                        args, 3
                    );
       XmStringFree(label);

       XtAddCallback(this_wid, XmNactivateCallback, select_button_pushCB, res);
   }
}

/****************************************************************************
 * FUNCTION: clear_residue_select_form  -- clears out the residue form      *
 *                                                                          *
 * INPUTS:   res     - the residue selection structure                      *
 *                                                                          *
 * OUTPUTS:  nothing                                                        *
 *                                                                          *
 ****************************************************************************/
void clear_residue_select_form (residue_selection_struct *res)
{
/* local variables */
Widget parent;

   if ((res == NULL)||(res->vis_ptr == NULL)) return;

   parent = XtParent(XtParent(res->rowCol));
   XtUnmanageChild(res->rowCol);
   XtDestroyWidget(res->rowCol);

   res->rowCol = XtVaCreateManagedWidget
                         (
                            "rowCol",
                            xmRowColumnWidgetClass,
                            parent,
                            XmNleftAttachment,   XmATTACH_FORM,
                            XmNrightAttachment,  XmATTACH_FORM,
                            XmNtopAttachment,    XmATTACH_FORM,
                            XmNbottomAttachment, XmATTACH_FORM,
                            XmNorientation,      XmVERTICAL,
                            XmNmarginHeight,     0,
                            XmNmarginWidth,      0,
                            XmNentryAlignment,   XmALIGNMENT_CENTER,
                            XmNspacing,          0,
                            XmNnumColumns,       1,
                            XmNpacking,          XmPACK_COLUMN,
                            NULL
                         );

   XtVaSetValues(parent, XmNworkWindow, res->rowCol, NULL);

}

/****************************************************************************
 * FUNCTION: residue_select_form_set_selected --sets the selected residue   *
 *                                              in the residue select form  *
 *                                                                          *
 * INPUTS:   res   -- the residue select form data structure                *
 *           old   -- the last selected residue index                       *
 *           new   -- the new selected residue index                        *
 *                                                                          *
 * OUTPUTS:  nothing                                                        *
 *                                                                          *
 ****************************************************************************/
void residue_select_form_set_selected(residue_selection_struct *res, int old, int new)
{
/* local variables */
WidgetList children;
Cardinal num_children;
Arg selectcolor_arg,
    normalcolor_arg;

   XtSetArg(selectcolor_arg, XmNbackground, res->select_bg_color);
   XtSetArg(normalcolor_arg, XmNbackground, res->normal_bg_color);

   if ((res == NULL)||(res->vis_ptr == NULL)||(old == new)) return;

   old++;new++;

   XtVaGetValues
     (
        res->rowCol,
        XmNchildren, &children,
        XmNnumChildren, &num_children,
        NULL
     );

   if ((new < num_children) && (new >= 0))
   {
      XtSetValues(children[new], &selectcolor_arg, 1);
   }

   if ((old < num_children) && (old >= 0))
   {
      XtSetValues(children[old], &normalcolor_arg, 1);
   }

}

/* callback for when one of the buttons is pressed */
static void select_button_pushCB(Widget w, XtPointer clientD, XtPointer callD)
{
/* local variables */
int i;
float x, y, z;
residue_selection_struct *res = (residue_selection_struct *)clientD;
vis_data_struct *vis = (vis_data_struct *)res->vis_ptr;

    XtVaGetValues(w, XmNuserData, &i, NULL);

    /* set the selected residue button's color */
    residue_select_form_set_selected(res, vis->params.selected_res, i);

    /* assume first atom in residue is selected */
    vis->params.selected_res = i;

    update_atom_info_dialog(vis->params.atom_info);

    if (i >= 0)
    {
       popup_atom_info_dialog(vis->params.atom_info);

       /* we really don't want to try to rotate to a vector with 0 length */
       if (vis->mol_data.nresidues > 1)
       {
          x = vis->mol_data.residues[i].x - vis->params.x[CENTER];
          y = vis->mol_data.residues[i].y - vis->params.y[CENTER];
          z = vis->mol_data.residues[i].z - vis->params.z[CENTER];

          /* really, really don't want to do that */
          if ((x != 0)&&(y!=0)&&(z!=0))
             rotate_to_vector(vis, x, y, z);
       }
    }
    else
    {
       popdown_atom_info_dialog(vis->params.atom_info);
    }

    gen_main_mol_lists(vis, (char)1, (char)1, -1.0);
    
    updateTranslations(vis, 1, 1);
}
