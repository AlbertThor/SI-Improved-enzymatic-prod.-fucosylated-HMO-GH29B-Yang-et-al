/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/


/****************************************************************
 * This file contains the code to directly visualize a molecule *
 * at our resolution, with our color interpolation methods, and *
 * with our knowledge of where the msms verticies lie --jcg     *
 ****************************************************************/

#include <X11/keysym.h>   /* for XLookupKeysym                 */
#include <X11/Shell.h>    /* for sessionShellWidgetClass       */
#include <Xm/Form.h>      /* for the XmFormWidgetClass         */
#include <Xm/Frame.h>     /* for the XmFrameWidgetClass        */
#include <Xm/Label.h>     /* for the XmLabelWidgetClass        */
#include <Xm/Scale.h>     /* for the XmScaleWidgetClass        */
#include <Xm/ToggleB.h>   /* for the XmToggleButtonWidgetClass */
#include <Xm/PushB.h>     /* for the XmPushButtonWidgetClass   */
#include <Xm/MwmUtil.h>   /* for mwm parameters for the shells */
#include "GLee.h"         /* for dynamic extension loading     */
#include <GL/GLwDrawA.h>  /* Xt OpenGL drawing area widget */
#include "vis_defines.h"  /* for constants used for widget creation */
#include "structures.h"   /* vertx data type and such    */
#include "visualize.h"    /* for vis_data_struct         */
#include "calculations.h" /* for cosine_v, etc           */
#include "tellUser.h"     /* for tellUser, to simplify error reporting */
#include <math.h>         /* for sqrt                    */
#include <stdio.h>        /* for printf, fprintf         */
#include <stdlib.h>       /* for calloc, exit            */
#include "vertex_shader.h"
#include "fragment_shader.h"

Widget mainForm=NULL;     /* don't nix this, it is used by tellUser */

/* callbacks used by visualize */
static void exposeCB          (Widget w, XtPointer clientD, XtPointer callD);
static void resizeCB          (Widget w, XtPointer clientD, XtPointer callD);
static void initCB            (Widget w, XtPointer clientD, XtPointer callD);
static void transSlideCB      (Widget w, XtPointer clientD, XtPointer callD);
static void init_sCB          (Widget w, XtPointer clientD, XtPointer callD);
static void expose_sCB        (Widget w, XtPointer clientD, XtPointer callD);
static void resize_sCB        (Widget w, XtPointer clientD, XtPointer callD);
static void inputCB           (Widget w, XtPointer clientD, XtPointer callD);
static void set_colorScaleCB  (Widget w, XtPointer clientD, XtPointer callD);

/* sets up the shaders */
void set_phong_shader (GL_shader_def_struct *shader);
/* creates the drawing area window */
void create_draw_window(vis_data_struct *vis);

/***************************************************************************
 * FUNCTION: visualize    --brings up the interface and displays the thing *
 *                                                                         *
 * INPUTS:  vis  -- a vis_data_struct with data to be viewed               *
 *          argc -- argc from the main function (passed at cmd line)       *
 *          argv -- argv from the main function (passed at cmd line)       *
 *                                                                         *
 * OUTPUTS: none                                                           *
 *                                                                         *
 * RETURNS: nothing                                                        *
 *                                                                         *
 * SIDE EFFECTS: during visualization user may change pretty much anything *
 *                                                                         *
 ***************************************************************************/
void visualize (vis_data_struct *vis, int argc, char **argv)
{
  /* local variables */
  /*******************/

  /* widgets and such */
  Widget       superForm,
               child,
               menu,
               paramFrame, /* the frame to contain the parameters */
               paramForm,  /* the form within the parameter frame */
               frameW,     /* a temporary frame widget */
               formW;      /* a temporary form widget  */

  XmString     label;      /* for labels to things */

  /* straight out of the old 6A book for startup */
  XtSetLanguageProc(NULL, NULL, NULL);

  vis->params.toplevel = XtVaOpenApplication
               (
                  &vis->params.app,
                  "GEM", NULL, 0,
                  &argc, argv,
                  NULL, sessionShellWidgetClass,
                  XmNwidth, VIS_MAIN_WINDOW_STARTUP_WIDTH,
                  XmNheight, VIS_MAIN_WINDOW_STARTUP_HEIGHT,
                  XmNtitle, "GEM",
                  XmNx, 100,
                  XmNy, 20,
                  XmNdeleteResponse, XmDO_NOTHING,
                  NULL
               );

  superForm = XtVaCreateManagedWidget
                (
                  "super form",
                  xmFormWidgetClass,
                  vis->params.toplevel,
                  NULL
                );

  menu = createMenubar(superForm, vis);

  /* shells cannot contain more than one direct child, so we use a form... */
  mainForm = XtVaCreateManagedWidget
               (
                  "mainForm",
                  xmFormWidgetClass,
                  superForm,
                  XmNleftAttachment,   XmATTACH_FORM,
                  XmNrightAttachment,  XmATTACH_FORM,
                  XmNtopAttachment,    XmATTACH_WIDGET,
                  XmNtopWidget, menu,
                  XmNbottomAttachment, XmATTACH_FORM,
                  NULL
               );

  /* the frame for all the parameters */
  paramFrame = XtVaCreateManagedWidget
                 (
                    "paramFrame",
                    xmFrameWidgetClass,
                    mainForm,
                    XmNrightAttachment,  XmATTACH_FORM,
                    XmNleftAttachment,  XmATTACH_FORM,
                    XmNtopAttachment,    XmATTACH_FORM,
                    XmNbottomAttachment, XmATTACH_FORM,
                    NULL
                 );

  label = XmStringCreate("View Controls", XmFONTLIST_DEFAULT_TAG);
  XtVaCreateManagedWidget
             (
                "label",
                xmLabelWidgetClass,
                paramFrame,
                XmNchildType, XmFRAME_TITLE_CHILD,
                XmNlabelString, label,
                NULL
             );
  XmStringFree(label);

  /* frames can't have more than one child either */
  paramForm = XtVaCreateManagedWidget
                (
                   "paramForm",
                   xmFormWidgetClass,
                   paramFrame,
                   XmNleftAttachment,   XmATTACH_FORM,
                   XmNrightAttachment,  XmATTACH_FORM,
                   XmNtopAttachment,    XmATTACH_FORM,
                   XmNbottomAttachment, XmATTACH_FORM,
                   NULL
                );

  frameW = XtVaCreateManagedWidget
             (
                 "Zoom frame",
                 xmFrameWidgetClass,
                 paramForm,
                 XmNtopAttachment,   XmATTACH_FORM,
                 XmNleftAttachment,  XmATTACH_FORM,
                 XmNrightAttachment, XmATTACH_FORM,
                 NULL
             );

  label = XmStringCreate("Transparency", XmFONTLIST_DEFAULT_TAG);
  XtVaCreateManagedWidget
             (
                "label",
                xmLabelWidgetClass,
                frameW,
                XmNlabelString, label,
                XmNchildType, XmFRAME_TITLE_CHILD,
                NULL
             );
  XmStringFree(label);


  child = XtVaCreateManagedWidget
                  (
                    "trans scale",
                    xmScaleWidgetClass,
                    frameW,
                    XmNorientation, XmHORIZONTAL,
                    XmNprocessingDirection, XmMAX_ON_RIGHT,
                    XmNmaximum, 100,
                    XmNminimum, 0,
                    XmNshowValue, True,
                    XmNvalue, (int)(vis->params.trans*100),
                    XmNuserData, &vis->params.trans,
                    NULL
                  );
  XtAddCallback(child, XmNdragCallback, transSlideCB, vis);
  XtAddCallback(child, XmNvalueChangedCallback, transSlideCB, vis);
 
  frameW = XtVaCreateManagedWidget
             (
                 "Residue Frame",
                 xmFrameWidgetClass,
                 paramForm,
                 XmNtopAttachment,   XmATTACH_WIDGET,
                 XmNtopWidget,       frameW,
                 XmNleftAttachment,  XmATTACH_FORM,
                 XmNrightAttachment, XmATTACH_FORM,
                 XmNbottomAttachment, XmATTACH_FORM,
                 NULL
             );

  label = XmStringCreate("Residues", XmFONTLIST_DEFAULT_TAG);
  XtVaCreateManagedWidget
             (
                "label",
                xmLabelWidgetClass,
                frameW,
                XmNlabelString, label,
                XmNchildType, XmFRAME_TITLE_CHILD,
                NULL
             );
  XmStringFree(label);

  formW = XtVaCreateManagedWidget
            (
              "form",
              xmFormWidgetClass,
              frameW,
              XmNchildType, XmFRAME_WORKAREA_CHILD,
              XmNtopAttachment, XmATTACH_FORM,
              XmNleftAttachment, XmATTACH_FORM,
              XmNrightAttachment, XmATTACH_FORM,
              XmNbottomAttachment, XmATTACH_FORM,
              NULL
            );

  /* create and populate the residue selection struct for the motif selection method */
  vis->params.res_sel = create_residue_select_form (formW, vis);
  fill_residue_select_form(vis->params.res_sel);

  create_draw_window(vis);

  /* create the atom info dialog, it is always there anyway */
  vis->params.atom_info = create_atom_info_dialog(superForm, vis);

  XtRealizeWidget(vis->params.toplevel);
  XtManageChild(vis->params.drawTop);
  XtRealizeWidget(vis->params.drawTop);

  vis->params.up = 'T';

  /* loop until we say we are done */
  XtAppMainLoop(vis->params.app);

} /* end visualize function definition */

/***************************************************************************
 * FUNCTION: create_draw_window    --creates the openGL mol view window    *
 *                                                                         *
 * INPUTS:  vis  -- a vis_data_struct with data to be viewed               *
 *                                                                         *
 * OUTPUTS: none                                                           *
 *                                                                         *
 * RETURNS: nothing                                                        *
 *                                                                         *
 ***************************************************************************/
void create_draw_window(vis_data_struct *vis)
{
  /* all this is for the gl widget display configuration */
  Display      *disp;      /* display info */
  /* non-display related variables */
  static int  garbage[] = {GLX_DOUBLEBUFFER,GLX_RGBA,GLX_DEPTH_SIZE, 16, None};
  Widget form;

  vis->params.drawTop = XtVaCreatePopupShell
                        (
                          "Molecule View Window",
                          topLevelShellWidgetClass,
                          vis->params.toplevel,
                          XmNwidth,  VIS_DISPLAY_WINDOW_START_WIDTH,
                          XmNheight, VIS_DISPLAY_WINDOW_START_HEIGHT,
                          XmNmwmDecorations, MWM_DECOR_RESIZEH|MWM_DECOR_BORDER|MWM_DECOR_MINIMIZE|MWM_DECOR_TITLE,
                          XmNmwmFunctions, MWM_FUNC_ALL|MWM_FUNC_CLOSE,
                          XmNx, 300,
                          XmNy, 20,
                          XmNdeleteResponse, XmDO_NOTHING,
                          NULL
                        );

  form = XtVaCreateManagedWidget
           (
             "form",
             xmFormWidgetClass,
             vis->params.drawTop,
             XmNleftAttachment, XmATTACH_FORM,
             XmNrightAttachment, XmATTACH_FORM,
             XmNtopAttachment, XmATTACH_FORM,
             XmNbottomAttachment, XmATTACH_FORM,
             NULL
           );

  disp = XtDisplay(form);

  vis->params.vi = glXChooseVisual(disp, DefaultScreen(disp), garbage);

  if (vis->params.vi == NULL)
  {
     tellUser("Error", "Could not locate a usable display\n");
     exit(1);
  }

  vis->params.colrW = XtVaCreateManagedWidget
                 (
                   "Colormap Drawing Area",
                   glwDrawingAreaWidgetClass,
                   form,
                   GLwNvisualInfo, vis->params.vi,
                   XmNbottomAttachment, XmATTACH_FORM,
                   XmNleftAttachment, XmATTACH_FORM,
                   XmNrightAttachment, XmATTACH_FORM,
                   XmNheight, VIS_COLORBAR_HEIGHT,
                   NULL
                 );
  XtAddCallback(vis->params.colrW, GLwNginitCallback, init_sCB,         vis);
  XtAddCallback(vis->params.colrW, GLwNinputCallback, set_colorScaleCB, vis);
  XtAddCallback(vis->params.colrW, GLwNresizeCallback, resize_sCB,      vis);
  XtAddCallback(vis->params.colrW, GLwNexposeCallback,expose_sCB,       vis);

  vis->params.drawW = XtVaCreateManagedWidget
                 (
                    "Drawing Area",
                    glwDrawingAreaWidgetClass,
                    form,
                    GLwNvisualInfo, vis->params.vi,
                    XmNleftAttachment,   XmATTACH_FORM,
                    XmNrightAttachment,  XmATTACH_FORM,
                    XmNtopAttachment,    XmATTACH_FORM,
                    XmNbottomAttachment, XmATTACH_WIDGET,
                    XmNbottomWidget, vis->params.colrW,
                    NULL
                 );

  /* callbacks */
  XtAddCallback(vis->params.drawW, GLwNginitCallback,  initCB,   vis);
  XtAddCallback(vis->params.drawW, GLwNinputCallback,  inputCB,  vis);
  XtAddCallback(vis->params.drawW, GLwNresizeCallback, resizeCB, vis);
  XtAddCallback(vis->params.drawW, GLwNexposeCallback, exposeCB, vis);
}

void init_current_context_draw (vis_data_struct *vis)
{
   static float ambient[] = {.1, .1, .1, 1.};
   static float diffuse[] = {1., 1., 1., 1.};
   static float m_diffuse[] = {.4, .4, .4, 1.};
   static float m_specular[] = {.3, .3, .3, 1.};
   static float m_shininess[] = {60.};
   static float position[4];

   /* set the light position */
   position[0] = vis->params.x[MAX];
   position[1] = vis->params.y[MAX];
   position[2] = vis->params.z[MAX];
   position[3] = 1.;

   glEnable(GL_DEPTH_TEST);
   glEnable(GL_LIGHTING);
   glEnable(GL_LIGHT0);
   glEnable(GL_NORMALIZE);
   glLightfv(GL_LIGHT0, GL_POSITION, position);
   glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
   glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);

   glMatrixMode(GL_PROJECTION);

   glEnable(GL_BLEND);

   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

   glClearColor(vis->params.bg_color[0],vis->params.bg_color[1],vis->params.bg_color[2],1.); /* background */
   glClearDepth(1.0);         /* default depth */
   glLoadIdentity();

   glOrtho
      (
         -vis->params.x[EXTENT]/2.,vis->params.x[EXTENT]/2.,
         -vis->params.y[EXTENT]/2.,vis->params.y[EXTENT]/2.,
         -vis->params.z[EXTENT]/2.,vis->params.z[EXTENT]/2. 
      );

   glMatrixMode(GL_MODELVIEW);

   glLoadIdentity();

   glEnable(GL_COLOR_MATERIAL);
   glEnable(GL_DEPTH_TEST);

   glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE); /* sets material colors to the color value */

   glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, m_shininess);
   glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR,  m_specular);
   glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,   m_diffuse);
}

/****************************/
/* Callback functions       */
/****************************/
/* initializes the drawing area when its created */
void initCB (Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   vis_data_struct *vis = (vis_data_struct *)clientD;
   (void) callD;

   if ((!w)||(!vis)) return;

   vis->params.draw_wid = VIS_DISPLAY_WINDOW_START_WIDTH;
   vis->params.draw_hit = VIS_DISPLAY_WINDOW_START_HEIGHT;

   vis->params.context_D = glXCreateContext(XtDisplay(w), vis->params.vi, None, GL_TRUE);

   glXMakeCurrent(XtDisplay(w), XtWindow(w), vis->params.context_D);

   init_current_context_draw(vis);

   /* initialize rotation matrix to the identity */
   glGetDoublev(GL_MODELVIEW_MATRIX, vis->params.rot_mat);
   glGetDoublev(GL_MODELVIEW_MATRIX, vis->params.rot_store_mat);

   if (
        (vis->decor_mol.vert != NULL) && 
        (vis->decor_mol.nvert > 1) && 
        (vis->decor_mol.surfaceDrawType == S_DRAW)
      )
   {
           updateTranslations(vis, 1, 1);
   }


   vis->params.atomList = glGenLists(3);

   if (vis->params.atomList != 0)
   {
      vis->params.surfaceList = vis->params.atomList+1;
      vis->params.decorList = vis->params.surfaceList+1;

      if ((vis->mol_data.nresidues > 0) || (vis->decor_mol.nresidues > 0))
      {
         gen_main_mol_lists(vis, (char)1, (char)1, -1.0);
         gen_decor_mol_list(vis);
      }
   }
   else
   {
      printf("DisplayLists not enabled on this client\n");
   }


   set_phong_shader(&(vis->params.phong_shader));

   draw(vis, 1);
}

 /* end init callback function */

/* called when the drawing area window is resized */
void resizeCB(Widget w, XtPointer clientD, XtPointer callD)
{
  /* local variables */
  GLwDrawingAreaCallbackStruct *cd = (GLwDrawingAreaCallbackStruct *)callD;
  vis_data_struct *vis = (vis_data_struct *)clientD;

  glXMakeCurrent(XtDisplay(w), XtWindow(w), vis->params.context_D);

  glMatrixMode(GL_PROJECTION);

  /* just resize the viewport to fill the screen */
  glViewport(0, 0, cd->width, cd->height);

  vis->params.x[EXTENT] *= (float)(cd->width/(float)vis->params.draw_wid);
  vis->params.y[EXTENT] *= (float)(cd->height/(float)vis->params.draw_hit);

  vis->params.x[MIN] = vis->params.x[CENTER] - .5 * vis->params.x[EXTENT];
  vis->params.x[MAX] = vis->params.x[CENTER] + .5 * vis->params.x[EXTENT];
  vis->params.y[MIN] = vis->params.y[CENTER] - .5 * vis->params.y[EXTENT];
  vis->params.y[MAX] = vis->params.y[CENTER] + .5 * vis->params.y[EXTENT];

  glLoadIdentity();
   glOrtho
      (
         -vis->params.x[EXTENT]/2.,vis->params.x[EXTENT]/2.,
         -vis->params.y[EXTENT]/2.,vis->params.y[EXTENT]/2.,
         -vis->params.z[EXTENT]/2.,vis->params.z[EXTENT]/2.
      );

  vis->params.draw_wid = cd->width;
  vis->params.draw_hit = cd->height;

  /* redraw */
  draw(vis, 1);

} /* end resize callback function */


/* handles redrawing when the window is exposed */
void exposeCB(Widget w, XtPointer clientD, XtPointer callD)
{
  /* local variables */
  vis_data_struct *vis = (vis_data_struct *)clientD;

  (void) w;
  (void) callD;

  draw(vis, 1);

} /* end expose callback function */

/* called when the transparency slider is slid */
void transSlideCB(Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   vis_data_struct      *vis = (vis_data_struct *)clientD;
   XmScaleCallbackStruct *cb  = (XmScaleCallbackStruct *)callD;
   double *val;

   XtVaGetValues(w, XmNuserData, &val, NULL);

   *val = cb->value/100.;

   /* since we changed transparency, regenerate the display lists */
   glXMakeCurrent
   (
      XtDisplay(vis->params.drawW),
      XtWindow(vis->params.drawW),
      vis->params.context_D
   );

   if (vis->params.rotation_dirty)
   {
      updateTranslations(vis, 1, 1);
   }
   else
   {
      gen_main_mol_lists(vis, (char)1, (char)0, -1.0);
   }

   draw(vis, 1);

} /* end transSlideCB function */

/* color scale initialization callback (when widget is realized) */
void init_sCB (Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   vis_data_struct *vis = (vis_data_struct *)clientD;

   (void) callD;

   vis->params.context_S = glXCreateContext(XtDisplay(w), vis->params.vi, None, GL_TRUE);

   glXMakeCurrent(XtDisplay(w), XtWindow(w), vis->params.context_S);

   /* initialize the gl fonts */
   vis->params.font = initialize_gl_fonts(XtDisplay(w));

   glClearColor(vis->params.bg_color[0],vis->params.bg_color[1],vis->params.bg_color[2],1.); /* background */

   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(-1, 1, -1, 0, -1, 1);

   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   drawColrMap(vis);

} /* end init_s callback function */

/* redraws the color map when it is exposed */
void expose_sCB (Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   vis_data_struct *vis = (vis_data_struct *)clientD;

   (void)w;
   (void)callD;

   drawColrMap(vis);
} /* end expose colormap callback function */

/* color scale resize callback */
void resize_sCB(Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   GLwDrawingAreaCallbackStruct *cd = (GLwDrawingAreaCallbackStruct *)callD;
   vis_data_struct *vis = (vis_data_struct *)clientD;

   glXMakeCurrent(XtDisplay(w), XtWindow(w), vis->params.context_S);

   glMatrixMode(GL_PROJECTION);

   /* just resize the viewport to fill the screen */
   glViewport(0, 0, cd->width, cd->height);

   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(-1, 1, -1, 0, -1, 1);

   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();

   /* redraw */
   drawColrMap(vis);

} /* end resize callback function */

/* The input callback, handles mouse effects in this case,
 * BUTTON_1 = MOVE_FUNC
 * BUTTON_2 = ROTATE_FUNC
 * BUTTON_3 = ZOOM_FUNC
 * ANY 2 BUTTONS = SELECT
 */
void inputCB(Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   XEvent *event = ((GLwDrawingAreaCallbackStruct *)callD)->event;
   vis_data_struct *vis = (vis_data_struct *)clientD;

   (void)w;

   int nearest_res,
            old_res,
             this_x,
             this_y;       /* the x and y locations of the current click */

   this_x = event->xbutton.x;
   this_y = vis->params.draw_hit - VIS_COLORBAR_HEIGHT - event->xbutton.y;

   switch(event->type)
   {
      case ButtonPress:

         /* record the pointer location */
         vis->params.start_x   = this_x;
         vis->params.start_y   = this_y;

         vis->params.click_x   = this_x;
         vis->params.click_y   = this_y;

         vis->params.last_mode = vis->params.mouse_mode;

         if (vis->params.mouse_mode != M_NONE)
         {
            vis->params.mouse_mode = M_SELECT;

            nearest_res = find_nearest_res (this_x, this_y, vis);

            old_res = vis->params.selected_res;

            
            /* regenerate display lists */
            if (old_res != nearest_res)
            {
               vis->params.selected_res = nearest_res;
               gen_main_mol_lists(vis, (char)1, (char)1, -1.0);
               update_atom_info_dialog(vis->params.atom_info);
               residue_select_form_set_selected(vis->params.res_sel,old_res,nearest_res);
               drawColrMap(vis);

               if ((nearest_res > -1)&&(nearest_res < vis->mol_data.nresidues))
               {
                  popup_atom_info_dialog(vis->params.atom_info);
               }
               else
               {
                  popdown_atom_info_dialog(vis->params.atom_info);
               }
            }

         }
         /* each button has its own event associated with it */
         else if (event->xbutton.button == Button1)
            vis->params.mouse_mode = M_MOVE;
         else if (event->xbutton.button == Button2)
            vis->params.mouse_mode = M_ZOOM;
         else if (event->xbutton.button == Button3)
         {
            vis->params.mouse_mode = M_ROTATE;
         }

      break;

      case ButtonRelease:

           if (vis->params.mouse_mode == M_ROTATE)
           {
              memcpy(vis->params.rot_store_mat, vis->params.rot_mat, sizeof(double)*16);
           }
      
           vis->params.mouse_mode = vis->params.last_mode;

           vis->params.last_mode = M_NONE;

      break;

      case MotionNotify:
         if (vis->params.mouse_mode == M_ROTATE)
         {
             /* apply this rotation to the rotation matrix */
             rotate(this_x, this_y, vis);

            /* update the last known positions */
            vis->params.start_x = this_x;
            vis->params.start_y = this_y;
         }
         else if (vis->params.mouse_mode == M_MOVE)
         {
            /* just multiply the pixel difference by the range of the image */
            vis->params.xshift +=
                (this_x-vis->params.start_x)*vis->params.x[EXTENT]/(vis->params.draw_wid*vis->params.scale);
            vis->params.yshift +=
                (this_y-vis->params.start_y)*vis->params.y[EXTENT]/(vis->params.draw_hit*vis->params.scale);

            /* normalize the shifts */
            if (vis->params.xshift > vis->params.x[EXTENT]/2) vis->params.xshift =  vis->params.x[EXTENT]/2;
            if (vis->params.yshift > vis->params.y[EXTENT]/2) vis->params.yshift =  vis->params.y[EXTENT]/2;
            if (vis->params.xshift < -vis->params.x[EXTENT]/2)vis->params.xshift = -vis->params.x[EXTENT]/2;
            if (vis->params.yshift < -vis->params.y[EXTENT]/2)vis->params.yshift = -vis->params.y[EXTENT]/2;

            /* update the last known positions */
            vis->params.start_x = this_x;
            vis->params.start_y = this_y;
         }
         else if (vis->params.mouse_mode == M_ZOOM)
         {
            vis->params.scale += (4.9*(float)(this_y - vis->params.start_y)/vis->params.draw_hit);

            /* normalize the scale */
            if (vis->params.scale > 5) 
               vis->params.scale = 5;
            else if (vis->params.scale < .1)
               vis->params.scale = .1;

            /* update the last known positions */
            vis->params.start_y = this_y;
            vis->params.start_x = this_y;
         }
         else if (vis->params.mouse_mode == M_SELECT)
         {
            nearest_res = find_nearest_res(this_x, this_y, vis);

            old_res = vis->params.selected_res;

            if (nearest_res != old_res)
            {
               vis->params.selected_res = nearest_res;

               /* regenerate display lists */
               gen_main_mol_lists(vis, (char)1, (char)1, -1.);

               update_atom_info_dialog(vis->params.atom_info);
               residue_select_form_set_selected(vis->params.res_sel,old_res,nearest_res);
               drawColrMap(vis);

               if ((vis->params.selected_res > -1) 
                   && (vis->params.selected_res < vis->mol_data.nresidues))
               {
                  popup_atom_info_dialog(vis->params.atom_info);
               }
               else
               {
                  popdown_atom_info_dialog(vis->params.atom_info);
               }
            }
         }

      break;

      default: /* do nothing on other types of input */
         return;
   }

   /* update changes */
   updateTranslations(vis, vis->params.rotation_dirty, 1);

}/* end inputCB */

/* callback to set the color scale, called when you click the colormap */
void set_colorScaleCB(Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   vis_data_struct *vis = (vis_data_struct *)clientD;
   XEvent *event = ((GLwDrawingAreaCallbackStruct *)callD)->event;

   /* only respond to button presses */
   if (event->type != ButtonPress) return;

   set_color_scale_dialog(w, vis);
}
