/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

#include "structures.h"
#include "visualize.h"
#include "limits.h"
#ifdef __APPLE__
#include <OpenGL/glu.h>
#else
#include <GL/glu.h>
#endif

/*
 * This file contains the method for selecting an object in the scene graph  
 * based on an x and y position in 2-D space, it will return the index of the
 * atom which, when transformed to 2-D space, is the closest to the mouse    
 * click.  If there are two or more objects under the mouse click when it    
 * occurs, we use the depth as a tiebreaker, and select the object with the  
 * least depth, meaning that it is closest on the z plane.  --jcg            
 *  --needs touching up i think <><>
 */

/***************************************************************************
 * FUNCTION: find_nearest_res  -- finds the nearest res to a given         *
 *                                 x, y screen coordinate  (pretty ghetto) *
 *                                                                         *
 * INPUTS: x, y  -- 2-D position to sample                                 *
 *         vis   -- the vis data struct (everything)                       *
 *                                                                         *
 * RETURNS: linear index of the nearest atom to the 2-D point              *
 *                                                                         *
 ***************************************************************************/
int find_nearest_res (int x, int y, vis_data_struct *vis)
{
   /* local variables */
   int             numFound,
                          i;

   GLuint sbuffer[256];

   GLuint closest = UINT_MAX,
                       names,
                        *ptr;

   int return_val = -1;

   GLint    viewportCoords[4];

   /* make sure we know which window we are messing with */
   glXMakeCurrent(XtDisplay(vis->params.drawW), XtWindow(vis->params.drawW), vis->params.context_D);

   /* tell GL to use our select buffer */
   glSelectBuffer(256, sbuffer);

   glRenderMode(GL_SELECT);

   glMatrixMode(GL_PROJECTION);
   glPushMatrix();
   glLoadIdentity();

   glGetIntegerv(GL_VIEWPORT, viewportCoords);

   gluPickMatrix(x, y, 5, 5, viewportCoords);

   glOrtho
     (
        -vis->params.x[EXTENT]/2.,vis->params.x[EXTENT]/2.,
        -vis->params.y[EXTENT]/2.,vis->params.y[EXTENT]/2.,
        -vis->params.z[EXTENT]/2.,vis->params.z[EXTENT]/2.
     );

   glMatrixMode(GL_MODELVIEW);

   glInitNames();
   drawSelection(vis->mol_data.residues, vis->mol_data.nresidues);

   glMatrixMode(GL_PROJECTION);
   glPopMatrix();

   glMatrixMode(GL_MODELVIEW);
   glFlush();

   numFound = glRenderMode(GL_RENDER);

   ptr = sbuffer;

   /* if there is a list, find the nearest in it */
   for (i = 0; i < numFound; i++)
   {
      names = *ptr; ptr++;

      if (*ptr < closest)  
      {
        closest = *ptr;
        return_val = *(ptr + 2); /* get the first in the list of names for the nearest */
      }

      ptr += 2+names;
   }

   return return_val;
}
