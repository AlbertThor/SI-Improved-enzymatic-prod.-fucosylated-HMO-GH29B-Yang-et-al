/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include "visualize.h"
#include "calculations.h"
#include "file_io.h"
#include "tellUser.h"
#include <stdlib.h>
#include <Xm/FileSB.h>
#include <Xm/SelectioB.h>
#include <Xm/TextF.h>
#include <stdio.h>

/**********************************************************************
 * Menu bars in motif can tend to be long, tedious, complicated, and
 * have a lot of static variables, so we will encapsulate all the
 * menubar code in this file to avoid having to deal with making
 * init even bigger. --jcg
 *********************************************************************/

/* callbacks */
static void atomCB        (Widget, XtPointer, XtPointer);
static void colorCB       (Widget, XtPointer, XtPointer);
static void surfCB        (Widget, XtPointer, XtPointer);
static void lightCB       (Widget, XtPointer, XtPointer);
static void FileOpCB      (Widget, XtPointer, XtPointer);
static void SaveSelectCB  (Widget, XtPointer, XtPointer);
static void fs_cnCB       (Widget, XtPointer, XtPointer);
static void fs_vertOkCB   (Widget, XtPointer, XtPointer);

/*************************************************************************
 * FUNCTION: createMenubar   -- creates the menubar you see at the top   *
 *                                                                       *
 * INPUTS:   parent  -- the parent widget                                *
 *           vis     -- the vis data struct (everything)                 *
 *                                                                       *
 * RETURNS:  the menu bar widget                                         *
 *                                                                       *
 *************************************************************************/
Widget createMenubar(Widget parent, vis_data_struct *vis)
{
   /* local variables */
   Widget menuBar,
          parentPulldown,
          childPulldown,
          childChildPulldown;

   WidgetList children;

   XmString str1,
            str2,
            str3,
            str4,
            str5,
            str6;
   /* first we make the menubar */
   str1 = XmStringCreateLocalized("File");
   str2 = XmStringCreateLocalized("View");
   menuBar = XmVaCreateSimpleMenuBar
                 (
                    parent,
                    "menubar",
                    XmVaCASCADEBUTTON, str1, 'F',
                    XmVaCASCADEBUTTON, str2, 'V',
                    XmNleftAttachment, XmATTACH_FORM,
                    XmNrightAttachment, XmATTACH_FORM,
                    NULL
                 );
   XmStringFree(str1);
   XmStringFree(str2);

   /* first option is the file pulldown menu */
   /******************************************/
   str1 = XmStringCreateLocalized("Open");
   str2 = XmStringCreateLocalized("Decoration Molecule");
   str3 = XmStringCreateLocalized("Save");
   str4 = XmStringCreateLocalized("Exit");
   parentPulldown = XmVaCreateSimplePulldownMenu
       (
          menuBar,
          "File",
          0,
          FileOpCB,
          XmVaPUSHBUTTON,    str1, 'O', "Ctrl<Key>O", NULL,
          XmVaPUSHBUTTON,    str2, 'D', "Ctrl<Key>D", NULL,
          XmVaCASCADEBUTTON, str3, 'S',
          XmVaPUSHBUTTON,    str4, 'E', "Ctrl<Key>E", NULL,
          NULL
       );
   XmStringFree(str1);
   XmStringFree(str2);
   XmStringFree(str3);
   XmStringFree(str4);

   XtVaSetValues(parentPulldown, XmNuserData, vis,NULL);

   /* need distance calculation to properly handle grid saving */
   str1 = XmStringCreateLocalized("Phimap file");
   str2 = XmStringCreateLocalized("TGA image");
   str3 = XmStringCreateLocalized("Gem vertex information");
   childPulldown = XmVaCreateSimplePulldownMenu
                    (
                      parentPulldown,
                      "Save",
                      2,
                      SaveSelectCB,
                      XmVaPUSHBUTTON, str1, 'P', "Ctrl<Key>P", NULL,
                      XmVaPUSHBUTTON, str2, 'T', "Ctrl<Key>T", NULL,
                      XmVaPUSHBUTTON, str3, 'G', "Ctrl<Key>G", NULL,
                      NULL
                    );
   XmStringFree(str1);
   XmStringFree(str2);
   XmStringFree(str3);

   XtVaSetValues(childPulldown, XmNuserData, vis,NULL);

   /* second option is the view option */
   /************************************/
   str1 = XmStringCreateLocalized("Atoms...");
   str2 = XmStringCreateLocalized("Surface...");
   str3 = XmStringCreateLocalized("Lighting...");
   parentPulldown = XmVaCreateSimplePulldownMenu
       (
          menuBar,
          "View",
          1,
          NULL,
          XmVaCASCADEBUTTON, str1, 'A',
          XmVaCASCADEBUTTON, str2, 'S',
          XmVaCASCADEBUTTON, str3, 'L',
          NULL
       );
   XmStringFree(str1);
   XmStringFree(str2);
   XmStringFree(str3);

   XtVaSetValues(parentPulldown, XmNuserData, vis,NULL);

   str1 = XmStringCreateLocalized("None");
   str2 = XmStringCreateLocalized("Sticks");
   str3 = XmStringCreateLocalized("Ball and Stick");
   str4 = XmStringCreateLocalized("Spacefill");
   str5 = XmStringCreateLocalized("Backbone");
   str6 = XmStringCreateLocalized("Custom Bonds");
   childPulldown = XmVaCreateSimplePulldownMenu
                    (
                      parentPulldown,
                      "Atoms",
                      0,
                      atomCB,
                      XmVaRADIOBUTTON, str1, 'N', "Ctrl<Key>N", NULL,
                      XmVaRADIOBUTTON, str2, 'S', "Ctrl<Key>S", NULL,
                      XmVaRADIOBUTTON, str3, 'B', "Ctrl<Key>B", NULL,
                      XmVaRADIOBUTTON, str4, 'P', "Ctrl<Key>P", NULL,
                      XmVaRADIOBUTTON, str5, 'A', "Ctrl<Key>A", NULL,
                      XmVaRADIOBUTTON, str6, 'C', "Ctrl<Key>C", NULL,
                      XmNradioAlwaysOne, True,
                      XmNradioBehavior, True,
                      NULL
                    );
   XmStringFree(str1);
   XmStringFree(str2);
   XmStringFree(str3);
   XmStringFree(str4);
   XmStringFree(str5);
   XmStringFree(str6);

   XtVaSetValues(childPulldown, XmNuserData, vis,NULL);
   XtVaGetValues(childPulldown, XmNchildren, &children, NULL);

   /* set the default */
   XtVaSetValues(children[vis->params.atomDrawMode], XmNset, True, NULL);


   str1 = XmStringCreateLocalized("Off");
   str2 = XmStringCreateLocalized("On");
   str3 = XmStringCreateLocalized("Mesh Only");
   str4 = XmStringCreateLocalized("Coloring...");
   childPulldown = XmVaCreateSimplePulldownMenu
                    (
                      parentPulldown,
                      "Surface",
                      1,
                      surfCB,
                      XmVaRADIOBUTTON, str1, 'f', "Ctrl<Key>f", NULL,
                      XmVaRADIOBUTTON, str2, 'O', "Ctrl<Key>O", NULL,
                      XmVaRADIOBUTTON, str3, 'm', "Ctrl<Key>m", NULL,
                      XmVaCASCADEBUTTON, str4, 'c',
                      XmNradioAlwaysOne, True,
                      XmNradioBehavior, True,
                      NULL
                    );
   XmStringFree(str1);
   XmStringFree(str2);
   XmStringFree(str3);

   XtVaSetValues(childPulldown, XmNuserData, vis, NULL);
   XtVaGetValues(childPulldown, XmNchildren, &children, NULL);

   XtVaSetValues(children[vis->params.surfDrawMode], XmNset, True, NULL);

   str1 = XmStringCreateLocalized("Potential");
   str2 = XmStringCreateLocalized("Charge");
   str3 = XmStringCreateLocalized("No Coloring");
   childChildPulldown = XmVaCreateSimplePulldownMenu
                    (
                      childPulldown,
                      "Surface",
                      3,
                      colorCB,
                      XmVaRADIOBUTTON, str1, 'P', "Ctrl<Key>P", NULL,
                      XmVaRADIOBUTTON, str2, 'C', "Ctrl<Key>C", NULL,
                      XmVaRADIOBUTTON, str3, 'N', "Ctrl<Key>N", NULL,
                      XmNradioAlwaysOne, True,
                      XmNradioBehavior, True,
                      NULL
                    );
   XmStringFree(str1);
   XmStringFree(str2);
   XmStringFree(str3);

   XtVaSetValues(childChildPulldown, XmNuserData, vis, NULL);
   XtVaGetValues(childChildPulldown, XmNchildren, &children, NULL);

   XtVaSetValues(children[0], XmNset, True, NULL);

   str1 = XmStringCreateLocalized("Off");
   str2 = XmStringCreateLocalized("On");
   childPulldown = XmVaCreateSimplePulldownMenu
                    (
                      parentPulldown,
                      "Lighting",
                      2,
                      lightCB,
                      XmVaRADIOBUTTON, str1, 'f', "Ctrl<Key>f", NULL,
                      XmVaRADIOBUTTON, str2, 'O', "Ctrl<Key>O", NULL,
                      XmNradioAlwaysOne, True,
                      XmNradioBehavior, True,
                      NULL
                    );
   XmStringFree(str1);
   XmStringFree(str2);

   XtVaSetValues(childPulldown, XmNuserData, vis, NULL);
   XtVaGetValues(childPulldown, XmNchildren, &children, NULL);

   XtVaSetValues(children[1], XmNset, True, NULL);

   XtManageChild(menuBar);

   return menuBar;
}

/* Callbacks */
/*************/

/* callback for subfunction of "file" option */
void FileOpCB (Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   int item = (int)clientD;
   vis_data_struct *vis;

   XtVaGetValues(XtParent(w), XmNuserData, &vis, NULL);


   if (item == 0) /* open */
      open_file_dialog(w, vis);
   else if (item == 1) /* open decor */
      open_decor_file_dialog(w, vis);
   else if (item == 3) /* exit */
   {
      /*
       * should clean a bunch of X and GL stuff up here -- hell clean everything
       * up
       */
      exit(0);
   }
}

/* callback for subfunction when "save" option clicked */
void SaveSelectCB (Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   static char *suffixes[] = {"*.phi", "*.tga", "*.gvert"};
   int item = (int) clientD;
   vis_data_struct *vis;
   Widget    fsd;
   Arg       args[5];
   XmString  suff;

   XtVaGetValues(XtParent(w), XmNuserData, &vis, NULL);

   if (item == 0)
   {
      save_grid_dialog (XtParent(w), vis);
      return;
   }

   if (item == 1)
   {
      save_image_dialog(XtParent(w), vis);
      return;
   }

   /* else, we just need a filename and vis to continue */

   suff = XmStringCreateLocalized(suffixes[item]);

   XtSetArg(args[0], XmNfileFilterStyle, XmFILTER_HIDDEN_FILES);
   XtSetArg(args[1], XmNpattern, suff);
   fsd = XmCreateFileSelectionDialog(XtParent(w), "savedialog", args, 2);
   XmStringFree(suff);

   /* unmanage useless or counterproductive options */
   XtUnmanageChild(XmSelectionBoxGetChild(fsd, XmDIALOG_HELP_BUTTON));
   XtUnmanageChild(XmFileSelectionBoxGetChild(fsd, XmDIALOG_FILTER_TEXT));
   XtUnmanageChild(XmFileSelectionBoxGetChild(fsd, XmDIALOG_FILTER_LABEL));

   /* pop up the interface */
   XtAddCallback(fsd, XmNcancelCallback, fs_cnCB, NULL);

   if (item == 2)
      XtAddCallback(fsd, XmNokCallback, fs_vertOkCB, vis);

   XtManageChild(fsd);
   XtPopup(XtParent(fsd), XtGrabNone);
}

/* called when cancel is clicked */
void fs_cnCB(Widget w, XtPointer clientD, XtPointer callD)
{
   XtPopdown(XtParent(w));
   XtDestroyWidget(XtParent(w));
}

/* callback for when people change atom draw type */
void atomCB(Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   int selection = (int)clientD;
   vis_data_struct *vis;

   XtVaGetValues(XtParent(w), XmNuserData, &vis, NULL);

   vis->params.atomDrawMode = selection;

   if ((vis->params.atomDrawMode != A_DRAW_SPACEFILL)
       && (vis->params.atomDrawMode != DRAW_NONE) && ((vis->mol_data.nbonds == 0)||(vis->mol_data.bonds==NULL)))
   {

      vis->mol_data.nbonds = extrapolate_bonds(vis->mol_data.residues, vis->mol_data.nresidues, (bond **)&vis->mol_data.bonds);

      //checks if custom bonds should be shown
      if (vis->params.atomDrawMode == A_DRAW_CUSTOM_BONDS) 
      {
         vis->params.custBonds = 1;
      }
      else
      {
         vis->params.custBonds = 0;
      }

      if (vis->mol_data.nbonds == 0)
      {
         fprintf(stderr, "Error extrapolating bonds, perhaps too little memory?\n");

         if (vis->params.atomDrawMode != A_DRAW_CUSTOM_BONDS)
         {
            vis->params.atomDrawMode = DRAW_NONE;
         }
      }
   }


      //checks if custom bonds should be shown
      if (vis->params.atomDrawMode == A_DRAW_CUSTOM_BONDS) 
      {
         vis->params.custBonds = 1;
      }
      else
      {
         vis->params.custBonds = 0;
      }

   /* regenerate atom call list if it is there*/
   if (vis->params.atomList != 0)
   {
      glXMakeCurrent
      (
         XtDisplay(vis->params.drawW),
         XtWindow(vis->params.drawW),
         vis->params.context_D
      );
      gen_main_mol_lists(vis, (char)0, (char)1, -1.);
   }


   draw(vis, 1);
   drawColrMap(vis);
}

/* callback for when surface display type is changed */
void surfCB (Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   int selection = (int)clientD;
   vis_data_struct *vis;

   XtVaGetValues(XtParent(w), XmNuserData, &vis, NULL);

   vis->params.surfDrawMode = selection;

   gen_main_mol_lists(vis, (char)1, (char)0, -1.);

   draw(vis, 1);
}

/* callback for when lighting is changed */
void lightCB (Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   vis_data_struct *vis;

   XtVaGetValues(XtParent(w), XmNuserData, &vis, NULL);

   glXMakeCurrent
     (
         XtDisplay(vis->params.drawW),
         XtWindow(vis->params.drawW),
         vis->params.context_D
     );

   if (clientD == 0)
   {
      glDisable(GL_LIGHTING);
      glDisable(GL_LIGHT0);
   }
   else
   {
      glEnable(GL_LIGHTING);
      glEnable(GL_LIGHT0);
   }

   draw(vis, 1);
}

void colorCB (Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   vis_data_struct *vis;

   XtVaGetValues(XtParent(w), XmNuserData, &vis, NULL);

   glXMakeCurrent
     (
         XtDisplay(vis->params.drawW),
         XtWindow(vis->params.drawW),
         vis->params.context_D
     );

   if (clientD == 0)
   {
      vis->params.colorType = 0;
   }
   else if (clientD == 2)
   {
      vis->params.colorType = 2;
   } 
   else 
   {
      vis->params.colorType = 1;
   }

   generate_colors (vis);
   gen_main_mol_lists (vis, (char)1, (char)0, -1.);

   draw(vis, 1);
   drawColrMap(vis);
}

/* callback for clicking "ok" under save gverts */
static void fs_vertOkCB (Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   /*******************/
   vis_data_struct *vis = (vis_data_struct *)clientD;
   Widget textField;
   char *fname;

   textField = XmFileSelectionBoxGetChild(w, XmDIALOG_TEXT);

   fname = XmTextFieldGetString(textField);

   write_gverts
     (
        fname,
        vis->mol_data.vert,
        vis->mol_data.tri,
        vis->mol_data.nvert,
        vis->mol_data.ntri
     );

   /* free up allocated memory */
   XtFree(fname);

   XtPopdown(XtParent(w));
   XtDestroyWidget(XtParent(w));
}
