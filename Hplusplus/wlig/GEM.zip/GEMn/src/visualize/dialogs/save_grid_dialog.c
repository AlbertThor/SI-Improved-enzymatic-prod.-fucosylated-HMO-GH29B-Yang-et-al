/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

#include "visualize.h"
#include "structures.h"
#include "calculations.h"
#include "file_io.h"
#include <pthread.h>

#include <Xm/MwmUtil.h>
#include <X11/Shell.h>
#include <Xm/Label.h>
#include <Xm/TextF.h>
#include <Xm/Frame.h>
#include <Xm/Form.h>
#include <Xm/PushB.h>
#include <stdlib.h>
#include <math.h>

typedef struct
{
      Widget topLevel,
             filename,
             gridRes,
             width;

      vis_data_struct *vis;

} save_grid_struct;

/* callbacks */
static void save_ok_cancelCB(Widget w, XtPointer clientD, XtPointer callD);

/****************************************************************************
 * FUNCTION:  save_grid_dialog -- writes data to a grid file                *
 *                                                                          *
 * INPUTS:    w                -- the parent widget                         *
 *            vis              -- the vis data struct                       *
 *                                                                          *
 * OUTPUTS:   nothing                                                       *
 *                                                                          *
 ****************************************************************************/
void save_grid_dialog (Widget w, vis_data_struct *vis)
{
   /* local variables */
   static save_grid_struct save = {NULL, NULL, NULL, NULL};

   Widget mainForm,    /* subform of the toplevel shell  */
             frame,    /* a frame widget                 */
             child,    /* a child widget                 */
             form;     /* a form widget                  */

   XmString label;     /* to label various widgets       */
   char     textval[64]; /* to print to text fields      */

   save.vis=vis;

  save.topLevel = XtVaCreatePopupShell
                (
                   "Please Enter Grid Parameters",
                   topLevelShellWidgetClass,
                   XtParent(w),
                   XmNwidth,  340,
                   XmNheight, 150,
                   XmNmwmDecorations, MWM_DECOR_ALL|MWM_DECOR_ALL,
                   XmNmwmFunctions,   MWM_FUNC_ALL|MWM_FUNC_ALL,
                   XmNmwmInputMode,   MWM_INPUT_FULL_APPLICATION_MODAL,
                   NULL
                );

   mainForm = XtVaCreateManagedWidget
                (
                   "Main Color Select Form",
                   xmFormWidgetClass,
                   save.topLevel,
                   XmNtopAttachment, XmATTACH_FORM,
                   XmNleftAttachment, XmATTACH_FORM,
                   XmNrightAttachment, XmATTACH_FORM,
                   XmNbottomAttachment, XmATTACH_FORM,
                   NULL
                 );

   frame = XtVaCreateManagedWidget
             (
                "frame",
                xmFrameWidgetClass,
                mainForm,
                XmNtopAttachment, XmATTACH_FORM,
                XmNleftAttachment, XmATTACH_FORM,
                XmNrightAttachment, XmATTACH_FORM,
                NULL
             );

   form = XtVaCreateManagedWidget
            (
               "form",
               xmFormWidgetClass,
               frame,
               NULL  /* all attachments default to form when only child */
            );

   save.filename = XtVaCreateManagedWidget
                     (
                       "saveText",
                       xmTextFieldWidgetClass,
                       form,
                       XmNtopAttachment, XmATTACH_FORM,
                       XmNtopOffset, 3,
                       XmNrightAttachment, XmATTACH_FORM,
                       XmNrightOffset, 3,
                       XmNcolumns, 20,
                       NULL
                     );

   label = XmStringCreate("File Name:", XmFONTLIST_DEFAULT_TAG);
   child = XtVaCreateManagedWidget
             (
               "label",
               xmLabelWidgetClass,
               form,
               XmNlabelString, label,
               XmNrightAttachment, XmATTACH_WIDGET,
               XmNrightWidget, save.filename,
               XmNrightOffset, 4,
               XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET,
               XmNtopWidget, save.filename,
               XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
               XmNbottomWidget, save.filename,
               NULL
             );
   XmStringFree(label);


   if ((vis->mol_data.calc_type & CALC_FLAG) == 0)
   {
       sprintf(textval, "%2.3f", 
          (vis->mol_data.grid_world_dims[3] - vis->mol_data.grid_world_dims[0])
             /(float)(vis->mol_data.grid_x_dim-1));
   }
   else
   {
       sprintf(textval, "%2.3f", 0.5);
   }

   save.gridRes = XtVaCreateManagedWidget
                    (
                      "gridResText",
                      xmTextFieldWidgetClass,
                      form,
                      XmNtopAttachment, XmATTACH_WIDGET,
                      XmNtopWidget,     save.filename,
                      XmNtopOffset,     6,
                      XmNrightAttachment, XmATTACH_FORM,
                      XmNvalue, textval,
                      XmNcolumns, 20,
                      NULL
                    );

   label = XmStringCreate("Element Size (Angstroms):", XmFONTLIST_DEFAULT_TAG);
   child = XtVaCreateManagedWidget
             (
               "label",
               xmLabelWidgetClass,
               form,
               XmNlabelString, label,
               XmNrightAttachment, XmATTACH_WIDGET,
               XmNrightWidget, save.gridRes,
               XmNrightOffset, 4,
               XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET,
               XmNtopWidget, save.gridRes,
               XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
               XmNbottomWidget, save.gridRes,
               NULL
             );
   XmStringFree(label);

   if ((vis->mol_data.calc_type & CALC_FLAG) == 0)
   {
     sprintf(textval, "%2.1f", (vis->mol_data.grid_world_dims[3] - vis->mol_data.grid_world_dims[0]));
   }
   else
   {
     sprintf(textval,"%2.1f", floor(vis->params.x[EXTENT]+.5));
   }

   save.width = XtVaCreateManagedWidget
                    (
                      "widthText",
                      xmTextFieldWidgetClass,
                      form,
                      XmNtopAttachment, XmATTACH_WIDGET,
                      XmNtopWidget,     save.gridRes,
                      XmNtopOffset,     6,
                      XmNrightAttachment, XmATTACH_FORM,
                      XmNcolumns, 20,
                      XmNvalue, textval,
                      XmNeditable, (((vis->mol_data.calc_type & CALC_FLAG) == 0)?0:1),
                      NULL
                    );
   if ((vis->mol_data.calc_type & CALC_FLAG) == 0)
   {
      XtSetSensitive(save.width, False);
      XtSetSensitive(save.gridRes, False);
   }

   label = XmStringCreate("Bounding Cube Size (Angstroms):", XmFONTLIST_DEFAULT_TAG);
   child = XtVaCreateManagedWidget
             (
               "label",
               xmLabelWidgetClass,
               form,
               XmNlabelString, label,
               XmNrightAttachment, XmATTACH_WIDGET,
               XmNrightWidget, save.width,
               XmNrightOffset, 4,
               XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET,
               XmNtopWidget, save.width,
               XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
               XmNbottomWidget, save.width,
               NULL
             );
   XmStringFree(label);

   frame = XtVaCreateManagedWidget
             (
                "frame",
                xmFrameWidgetClass,
                mainForm,
                XmNtopAttachment,   XmATTACH_WIDGET,
                XmNtopWidget,       frame,
                XmNleftAttachment,  XmATTACH_FORM,
                XmNrightAttachment, XmATTACH_FORM,
                NULL
             );

   form = XtVaCreateManagedWidget
            (
               "form",
               xmFormWidgetClass,
               frame,
               NULL
            );

   label = XmStringCreate("Cancel", XmFONTLIST_DEFAULT_TAG);
   child = XtVaCreateManagedWidget
             (
                "cancelbutton",
                xmPushButtonWidgetClass,
                form,
                XmNlabelString, label,
                XmNleftAttachment, XmATTACH_FORM,
                XmNtopAttachment, XmATTACH_FORM,
                XmNbottomAttachment, XmATTACH_FORM,
                XmNheight, 30,
                XmNwidth, 75,
                XmNuserData, 0,
                NULL
             );
   XmStringFree(label);
   XtAddCallback(child, XmNactivateCallback, save_ok_cancelCB, &save);

   label = XmStringCreate("OK", XmFONTLIST_DEFAULT_TAG);
   child = XtVaCreateManagedWidget
             (
                "okbutton",
                xmPushButtonWidgetClass,
                form,
                XmNlabelString, label,
                XmNrightAttachment, XmATTACH_FORM,
                XmNtopAttachment, XmATTACH_FORM,
                XmNbottomAttachment, XmATTACH_FORM,
                XmNheight, 30,
                XmNwidth, 75,
                XmNuserData, 1,
                NULL
             );
   XmStringFree(label);
   XtAddCallback(child, XmNactivateCallback, save_ok_cancelCB, &save);

   XtPopup(save.topLevel, XtGrabNone);

}

/* called when ok ore cancel are clicked */
void save_ok_cancelCB(Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   save_grid_struct *save = (save_grid_struct *)clientD;
   vis_data_struct *vis = save->vis;

   int  edge;
   
   char *data = NULL;
   float width, resolution;
   int  val;

   XtPopdown(save->topLevel);
   XFlush(XtDisplay(save->topLevel));

   XtVaGetValues(w, XmNuserData, &val, NULL);

   /* OK pressed if val == 1 */
   if (val)
   {
      data = XmTextFieldGetString(save->width);
      width = atof(data);
      XtFree(data);

      data = XmTextFieldGetString(save->gridRes);
      resolution = atof(data);
      XtFree(data);

      edge = /* implicit floor */ width / resolution + 1;

      /* make sure edge is odd for MEAD and other programs that like to have a center point */
      edge += ( (edge % 2)? 0 : 1);

      data = XmTextFieldGetString(save->filename);

      write_grid_from_vis (data, edge, width, vis);

      XtFree(data);
   }

   /* clean up the popup window */
   XtDestroyWidget(save->topLevel);
}
