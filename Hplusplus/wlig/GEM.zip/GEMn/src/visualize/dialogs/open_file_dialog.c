/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include "visualize.h"
#include "partitioned_open.h"
#include "tellUser.h"
#include "defines.h"
#include "calculations.h"
#include "structures.h"
#include "vis_defines.h"

/*********************************************************************
 * This function pops up an open file dialog that allows the user to
 * open a file and calculate the potentials for it --jcg
 ********************************************************************/

/* for various Motif Widgets */
#include <Xm/MwmUtil.h>
#include <X11/Shell.h>
#include <Xm/RowColumn.h>
#include <Xm/SelectioB.h>
#include <Xm/FileSB.h>
#include <Xm/ToggleB.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>
#include <Xm/TextF.h>
#include <Xm/PushB.h>
#include <Xm/Form.h>

#define DIEL_EXT     0
#define DIEL_INT     1
#define SALT         2
#define PROJ_LEN     3
#define TRI_DENSITY  4
#define A_ESTIMATE   5
#define PROBE_RAD    6
#define SALT_RAD     7

typedef struct
{
   vis_data_struct *vis;

   Widget topLevel,
          GBparamFrame,
          PHIparamFrame,
          PQRtextField,
          PHIoptionTextField;

   int    calcType,
          phiType,  /* 0 = nothing, 1 = reaction field, 2 = coulomb, 3 = total */
          userA;

   double diel_int,
          diel_ext,
          ion_exc_rad,
          salt,
          proj_len,
	       triDens,
          probeRadius,
          A_value;

} FOpenCB_struct;


/* callbacks */
static void sp_cnCB (Widget w, XtPointer clientD, XtPointer callD);
static void userAtoggleCB (Widget w, XtPointer clientD, XtPointer callD);
static void selectPhimapButtonOkCB(Widget w, XtPointer clientD, XtPointer callD);
static void selectPhimapButtonCB(Widget w, XtPointer clientD, XtPointer callD);
static void PotentialSourceCB(Widget w, XtPointer clientD, XtPointer callD);
static void PotentialTypeCB(Widget w, XtPointer clientD, XtPointer callD);
static void openOkCancelCB(Widget w, XtPointer clientD, XtPointer callD);
static void numberTextEntryCB(Widget w, XtPointer clientD, XtPointer callD);

/************************************************************************
 * FUNCTION:  create_open_file_dialog  -- creates the open file dialog  *
 *                                                                      *
 * INPUTS:    parent  -- the parent widget                              *
 *            CBD     -- the callback struct to populate                *
 *                                                                      *
 * OUTPUTS:   none                                                      *
 *                                                                      *
 ************************************************************************/
void create_open_file_dialog (Widget parent, FOpenCB_struct *CBD)
{
   /* local variables */
   Widget mainForm,
          frame,
          form,
          child,
          radioBox,
          labelW;

   XmString label;
   Arg args[5];
   char text[32];

   CBD->topLevel = XtVaCreatePopupShell
                    (
                       "Open File",
                       topLevelShellWidgetClass,
                       parent,
                       XmNwidth,  OPEN_FILE_DIALOG_START_WIDTH,
                       XmNheight, OPEN_FILE_DIALOG_START_HEIGHT,
                       XmNmwmDecorations, MWM_DECOR_RESIZEH|MWM_DECOR_BORDER|MWM_DECOR_MINIMIZE|MWM_DECOR_TITLE|MWM_DECOR_RESIZEH,
                       XmNmwmFunctions,   MWM_FUNC_ALL|MWM_FUNC_CLOSE|MWM_FUNC_MAXIMIZE,
                       XmNmwmInputMode,   MWM_INPUT_FULL_APPLICATION_MODAL,
                       XmNdeleteResponse, XmDO_NOTHING,
                       NULL
                   );

   mainForm = XtVaCreateManagedWidget
                (
                   "mainFileSelectForm",
                   xmFormWidgetClass,
                   CBD->topLevel,
                   XmNtopAttachment,   XmATTACH_FORM,
                   XmNleftAttachment,  XmATTACH_FORM,
                   XmNrightAttachment, XmATTACH_FORM,
                   NULL
                );

   /* the first field on the top will be the Pqr File Name */
   label = XmStringCreate("*.pqr", XmFONTLIST_DEFAULT_TAG);
   XtSetArg(args[0], XmNfileFilterStyle, XmFILTER_HIDDEN_FILES);
   XtSetArg(args[1], XmNpattern, label);
   //XtSetArg(args[2], XmNpathMode, XmPATH_MODE_RELATIVE);
   
   form = XmCreateFileSelectionBox(mainForm, "hoy", args, 2);
   XmStringFree(label);

   XtVaSetValues(form, XmNleftAttachment, XmATTACH_FORM, XmNrightAttachment, XmATTACH_FORM, NULL);
   XtUnmanageChild(XmSelectionBoxGetChild(form, XmDIALOG_OK_BUTTON));
   XtUnmanageChild(XmSelectionBoxGetChild(form, XmDIALOG_HELP_BUTTON));
   XtUnmanageChild(XmSelectionBoxGetChild(form, XmDIALOG_CANCEL_BUTTON));
   XtUnmanageChild(XmSelectionBoxGetChild(form, XmDIALOG_DEFAULT_BUTTON));
   XtUnmanageChild(XmSelectionBoxGetChild(form, XmDIALOG_SEPARATOR));
   XtUnmanageChild(XmFileSelectionBoxGetChild(form, XmDIALOG_FILTER_TEXT));
   XtUnmanageChild(XmFileSelectionBoxGetChild(form, XmDIALOG_FILTER_LABEL));

   // <><>
   label = XmStringCreate("", XmFONTLIST_DEFAULT_TAG);
   XtVaSetValues(XmFileSelectionBoxGetChild(form, XmDIALOG_APPLY_BUTTON), XmNlabelString, label, XmNwidth, 0, XmNheight, 0, NULL);
   XmStringFree(label);

   XtUnmanageChild(XmFileSelectionBoxGetChild(form, XmDIALOG_SEPARATOR));
   CBD->PQRtextField = XmSelectionBoxGetChild(form, XmDIALOG_TEXT);

   XtManageChild(form);

   frame = XtVaCreateManagedWidget
             (
                "frame widget",
                xmFrameWidgetClass,
                mainForm,
                XmNtopAttachment, XmATTACH_WIDGET,
                XmNtopWidget, form,
                XmNleftAttachment,  XmATTACH_FORM,
                XmNrightAttachment, XmATTACH_FORM,
                NULL
             );

   label = XmStringCreate("Potential Source", XmFONTLIST_DEFAULT_TAG);
   labelW = XtVaCreateManagedWidget
              (
                 "label widget",
                 xmLabelWidgetClass,
                 frame,
                 XmNlabelString, label,
                 XmNchildType, XmFRAME_TITLE_CHILD,
                 NULL
              );
   XmStringFree(label);

   radioBox = XtVaCreateManagedWidget
              (
                 "form widget",
                 xmRowColumnWidgetClass,
                 frame,
                 XmNpacking, XmPACK_COLUMN,
                 XmNradioAlwaysOne, True,
                 XmNradioBehavior, True,
                 XmNorientation, XmHORIZONTAL,
                 XmNentryClass, xmToggleButtonWidgetClass,
                 XmNleftAttachment, XmATTACH_FORM,
                 XmNrightAttachment, XmATTACH_FORM,
                 XmNtopAttachment, XmATTACH_FORM,
                 XmNbottomAttachment, XmATTACH_FORM,
                 NULL
              );

   label = XmStringCreate("No Potential", XmFONTLIST_DEFAULT_TAG);
   child = XtVaCreateManagedWidget
             (
                "toggleButton",
                xmToggleButtonWidgetClass,
                radioBox,
                XmNlabelString, label,
                XmNindicatorType, XmONE_OF_MANY,
                XmNvisibleWhenOff, True,
                XmNuserData, POPEN_CALC_NONE,
                XmNset, (Boolean)(CBD->calcType == POPEN_CALC_NONE),
                NULL
             );
   XmStringFree(label);
   XtAddCallback(child, XmNvalueChangedCallback, PotentialSourceCB, CBD);

   label = XmStringCreate("Calculate Directly", XmFONTLIST_DEFAULT_TAG);
   child = XtVaCreateManagedWidget
             (
                "toggleButton",
                xmToggleButtonWidgetClass,
                radioBox,
                XmNlabelString, label,
                XmNindicatorType, XmONE_OF_MANY,
                XmNvisibleWhenOff, True,
                XmNuserData, POPEN_CALC_DIRECTLY,
                XmNset, (Boolean)(CBD->calcType == POPEN_CALC_DIRECTLY),
                NULL
             );
   XmStringFree(label);
   XtAddCallback(child, XmNvalueChangedCallback, PotentialSourceCB, CBD);

   XtVaSetValues(radioBox, XmNmenuHistory, child, NULL);

   label = XmStringCreate("Read Phi Grid", XmFONTLIST_DEFAULT_TAG);
   child = XtVaCreateManagedWidget
             (
                "toggleButton",
                xmToggleButtonWidgetClass,
                radioBox,
                XmNlabelString, label,
                XmNindicatorType, XmONE_OF_MANY,
                XmNvisibleWhenOff, True,
                XmNuserData, POPEN_READ_PHIMAP,
                XmNset, (Boolean)(CBD->calcType == POPEN_READ_PHIMAP),
                NULL
             );
   XmStringFree(label);
   XtAddCallback(child, XmNvalueChangedCallback, PotentialSourceCB, CBD);

   /* now for the calculation specific parameter frame */
   CBD->PHIparamFrame = XtVaCreateWidget
                        (
                           "GB param Frame",
                           xmFrameWidgetClass,
                           mainForm,
                           XmNtopAttachment, XmATTACH_WIDGET,
                           XmNtopWidget, frame,
                           XmNleftAttachment,  XmATTACH_FORM,
                           XmNrightAttachment, XmATTACH_FORM,
                           NULL
                        );
   if (CBD->calcType == POPEN_READ_PHIMAP)
     XtManageChild(CBD->PHIparamFrame);

   label = XmStringCreate("Phimap Parameters", XmFONTLIST_DEFAULT_TAG);
   labelW = XtVaCreateManagedWidget
              (
                 "label widget",
                 xmLabelWidgetClass,
                 CBD->PHIparamFrame,
                 XmNlabelString, label,
                 XmNchildType, XmFRAME_TITLE_CHILD,
                 NULL
              );
   XmStringFree(label);

   form = XtVaCreateManagedWidget
            (
              "Form",
              xmFormWidgetClass,
              CBD->PHIparamFrame,
              NULL
            );

   label = XmStringCreate("Browse", XmFONTLIST_DEFAULT_TAG);
   labelW = XtVaCreateManagedWidget
              (
                 "SelectButton",
                 xmPushButtonWidgetClass,
                 form,
                 XmNrightAttachment, XmATTACH_FORM,
                 XmNtopAttachment, XmATTACH_FORM,
                 XmNbottomAttachment, XmATTACH_FORM,
                 XmNlabelString, label,
                 NULL
              );
   XmStringFree(label);
   XtAddCallback(labelW, XmNactivateCallback, selectPhimapButtonCB, CBD);

   sprintf(text, "none");
   CBD->PHIoptionTextField = XtVaCreateManagedWidget
                              (
                                 "PHI option Field",
                                 xmTextFieldWidgetClass,
                                 form,
                                 XmNrightAttachment, XmATTACH_WIDGET,
                                 XmNrightWidget, labelW,
                                 XmNtopAttachment, XmATTACH_FORM,
                                 XmNvalue, text,
                                 XmNcolumns, 40,
                                 NULL
                              );

   label = XmStringCreate("Phimap file name:", XmFONTLIST_DEFAULT_TAG);
   labelW = XtVaCreateManagedWidget
              (
                 "label widget",
                 xmLabelWidgetClass,
                 form,
                 XmNrightAttachment, XmATTACH_WIDGET,
                 XmNrightWidget, CBD->PHIoptionTextField,
                 XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNtopWidget, CBD->PHIoptionTextField,
                 XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNbottomWidget, CBD->PHIoptionTextField,
                 XmNleftAttachment, XmATTACH_FORM,
                 XmNlabelString, label,
                 NULL
              );
   XmStringFree(label);


   CBD->GBparamFrame = XtVaCreateWidget
                         (
                            "GB param Frame",
                            xmFrameWidgetClass,
                            mainForm,
                            XmNtopAttachment, XmATTACH_WIDGET,
                            XmNtopWidget, frame,
                            XmNleftAttachment,  XmATTACH_FORM,
                            XmNrightAttachment, XmATTACH_FORM,
                            NULL
                         );
   if (CBD->calcType == POPEN_CALC_DIRECTLY)
     XtManageChild(CBD->GBparamFrame);

   label = XmStringCreate("ALPB Parameters",XmFONTLIST_DEFAULT_TAG);
   labelW = XtVaCreateManagedWidget
              (
                 "label widget",
                 xmLabelWidgetClass,
                 CBD->GBparamFrame,
                 XmNlabelString, label,
                 XmNchildType, XmFRAME_TITLE_CHILD,
                 NULL
              );
   XmStringFree(label);

   form = XtVaCreateManagedWidget
            (
              "form",
              xmFormWidgetClass,
              CBD->GBparamFrame,
              NULL
            );

   sprintf(text, "%2.2lf", CBD->diel_int);
   child = XtVaCreateManagedWidget
             (
               "text field",
               xmTextFieldWidgetClass,
               form,
               XmNrightAttachment, XmATTACH_FORM,
               XmNtopAttachment, XmATTACH_WIDGET,
               XmNtopWidget, labelW,
               XmNuserData, DIEL_INT,
               XmNvalue, text,
               NULL
             );
   XtAddCallback(child, XmNactivateCallback, numberTextEntryCB, CBD);
   XtAddCallback(child, XmNlosingFocusCallback, numberTextEntryCB, CBD);

   label = XmStringCreate("Internal dielectric:", XmFONTLIST_DEFAULT_TAG);
   labelW = XtVaCreateManagedWidget
              (
                 "label widget",
                 xmLabelWidgetClass,
                 form,
                 XmNrightAttachment, XmATTACH_WIDGET,
                 XmNrightWidget, child,
                 XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNtopWidget, child,
                 XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNbottomWidget, child,
                 XmNlabelString, label,
                 NULL
              );
   XmStringFree(label);

   sprintf(text, "%2.2lf", CBD->diel_ext);
   child = XtVaCreateManagedWidget
             (
               "text field",
               xmTextFieldWidgetClass,
               form,
               XmNrightAttachment, XmATTACH_FORM,
               XmNtopAttachment, XmATTACH_WIDGET,
               XmNtopWidget, child,
               XmNuserData, DIEL_EXT,
               XmNvalue, text,
               NULL
             );
   XtAddCallback(child, XmNactivateCallback, numberTextEntryCB, CBD);
   XtAddCallback(child, XmNlosingFocusCallback, numberTextEntryCB, CBD);

   label = XmStringCreate("External dielectric:", XmFONTLIST_DEFAULT_TAG);
   labelW = XtVaCreateManagedWidget
              (
                 "label widget",
                 xmLabelWidgetClass,
                 form,
                 XmNrightAttachment, XmATTACH_WIDGET,
                 XmNrightWidget, child,
                 XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNtopWidget, child,
                 XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNbottomWidget, child,
                 XmNlabelString, label,
                 NULL
              );
   XmStringFree(label);

   sprintf(text, "%2.2lf", CBD->salt);
   child = XtVaCreateManagedWidget
             (
               "text field",
               xmTextFieldWidgetClass,
               form,
               XmNrightAttachment, XmATTACH_FORM,
               XmNtopAttachment, XmATTACH_WIDGET,
               XmNtopWidget, child,
               XmNuserData, SALT,
               XmNvalue, text,
               NULL
             );
   XtAddCallback(child, XmNactivateCallback, numberTextEntryCB, CBD);
   XtAddCallback(child, XmNlosingFocusCallback, numberTextEntryCB, CBD);

   label = XmStringCreate("Salt Concentration:", XmFONTLIST_DEFAULT_TAG);
   labelW = XtVaCreateManagedWidget
              (
                 "label widget",
                 xmLabelWidgetClass,
                 form,
                 XmNrightAttachment, XmATTACH_WIDGET,
                 XmNrightWidget, child,
                 XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNtopWidget, child,
                 XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNbottomWidget, child,
                 XmNlabelString, label,
                 NULL
              );
   XmStringFree(label);

   sprintf(text, "%2.2lf", CBD->ion_exc_rad);
   child = XtVaCreateManagedWidget
             (
               "text field",
               xmTextFieldWidgetClass,
               form,
               XmNrightAttachment, XmATTACH_FORM,
               XmNtopAttachment, XmATTACH_WIDGET,
               XmNtopWidget, child,
               XmNuserData, SALT_RAD,
               XmNvalue, text,
               NULL
             );
   XtAddCallback(child, XmNactivateCallback, numberTextEntryCB, CBD);
   XtAddCallback(child, XmNlosingFocusCallback, numberTextEntryCB, CBD);

   label = XmStringCreate("Ion Exclusion Radius:", XmFONTLIST_DEFAULT_TAG);
   labelW = XtVaCreateManagedWidget
              (
                 "label widget",
                 xmLabelWidgetClass,
                 form,
                 XmNrightAttachment, XmATTACH_WIDGET,
                 XmNrightWidget, child,
                 XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNtopWidget, child,
                 XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNbottomWidget, child,
                 XmNlabelString, label,
                 NULL
              );
   XmStringFree(label);

   sprintf(text, "%2.2lf", CBD->diel_ext);
   child = XtVaCreateManagedWidget
             (
               "text field",
               xmTextFieldWidgetClass,
               form,
               XmNrightAttachment, XmATTACH_FORM,
               XmNtopAttachment, XmATTACH_WIDGET,
               XmNtopWidget, child,
               XmNuserData, A_ESTIMATE,
               XmNvalue, "",
               NULL
             );
   XtSetSensitive(child, False);
   XtAddCallback(child, XmNactivateCallback, numberTextEntryCB, CBD);
   XtAddCallback(child, XmNlosingFocusCallback, numberTextEntryCB, CBD);

   label = XmStringCreate("User Defined Electrostatic Radius:", XmFONTLIST_DEFAULT_TAG);
   child = XtVaCreateManagedWidget
             (
                "toggleButton",
                xmToggleButtonWidgetClass,
                form,
                XmNlabelString, label,
                XmNrightAttachment, XmATTACH_WIDGET,
                XmNrightWidget, child,
                XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET,
                XmNtopWidget, child,
                XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
                XmNbottomWidget, child,
                XmNuserData, child,
                XmNset, (Boolean)CBD->userA,
                NULL
             );
   XmStringFree(label);
   XtAddCallback(child, XmNvalueChangedCallback, userAtoggleCB, CBD);

   radioBox = XtVaCreateManagedWidget
              (
                 "form widget",
                 xmRowColumnWidgetClass,
                 form,
                 XmNpacking, XmPACK_COLUMN,
                 XmNradioAlwaysOne, True,
                 XmNradioBehavior, True,
                 XmNentryClass, xmToggleButtonWidgetClass,
                 XmNtopAttachment, XmATTACH_WIDGET,
                 XmNtopWidget, child,
                 XmNrightAttachment, XmATTACH_FORM,
                 XmNleftAttachment, XmATTACH_FORM,
                 XmNbottomAttachment, XmATTACH_FORM,
                 XmNorientation, XmHORIZONTAL,
                 NULL
              );

   label = XmStringCreate("Total Potential", XmFONTLIST_DEFAULT_TAG);
   child = XtVaCreateManagedWidget
             (
                "toggleButton",
                xmToggleButtonWidgetClass,
                radioBox,
                XmNlabelString, label,
                XmNindicatorType, XmONE_OF_MANY,
                XmNvisibleWhenOff, True,
                XmNuserData, (REACTION_POTENTIAL + COULOMB_POTENTIAL),
                XmNset, (Boolean)(CBD->phiType == (COULOMB_POTENTIAL + REACTION_POTENTIAL)),
                NULL
             );
   XmStringFree(label);
   XtAddCallback(child, XmNvalueChangedCallback, PotentialTypeCB, CBD);

   //XtVaSetValues(radioBox, XmNmenuHistory, child, NULL);

   label = XmStringCreate("Reaction Field", XmFONTLIST_DEFAULT_TAG);
   child = XtVaCreateManagedWidget
             (
                "toggleButton",
                xmToggleButtonWidgetClass,
                radioBox,
                XmNlabelString, label,
                XmNindicatorType, XmONE_OF_MANY,
                XmNvisibleWhenOff, True,
                XmNuserData, REACTION_POTENTIAL,
                XmNset, (Boolean) (CBD->phiType == REACTION_POTENTIAL),
                NULL
             );
   XmStringFree(label);
   XtAddCallback(child, XmNvalueChangedCallback, PotentialTypeCB, CBD);


   label = XmStringCreate("Coulomb Potential", XmFONTLIST_DEFAULT_TAG);
   child = XtVaCreateManagedWidget
             (
                "toggleButton",
                xmToggleButtonWidgetClass,
                radioBox,
                XmNlabelString, label,
                XmNindicatorType, XmONE_OF_MANY,
                XmNvisibleWhenOff, True,
                XmNuserData, COULOMB_POTENTIAL,
                XmNset, (Boolean) (CBD->phiType == COULOMB_POTENTIAL),
                NULL
             );
   XmStringFree(label);
   XtAddCallback(child, XmNvalueChangedCallback, PotentialTypeCB, CBD);


   frame = XtVaCreateManagedWidget
             (
               "frame",
               xmFrameWidgetClass,
               mainForm,
               XmNbottomAttachment, XmATTACH_FORM,
               XmNrightAttachment, XmATTACH_FORM,
               XmNleftAttachment, XmATTACH_FORM,
               NULL
             );

   form = XtVaCreateManagedWidget
            (
              "form",
              xmFormWidgetClass,
              frame,
              NULL
            );

   label = XmStringCreate("Open", XmFONTLIST_DEFAULT_TAG);
   child = XtVaCreateManagedWidget
             (
               "child",
               xmPushButtonWidgetClass,
               form,
               XmNlabelString, label,
               XmNrightAttachment, XmATTACH_FORM,
               XmNbottomAttachment, XmATTACH_FORM,
               XmNheight, VIS_PUSH_BUTTON_HEIGHTS,
               XmNwidth, VIS_PUSH_BUTTON_WIDTHS,
               XmNuserData, OK,
               NULL
             );
   XmStringFree(label);
   XtAddCallback(child, XmNactivateCallback, openOkCancelCB, CBD);

   label = XmStringCreate("Cancel", XmFONTLIST_DEFAULT_TAG);
   child = XtVaCreateManagedWidget
             (
               "child",
               xmPushButtonWidgetClass,
               form,
               XmNlabelString, label,
               XmNleftAttachment, XmATTACH_FORM,
               XmNtopAttachment, XmATTACH_FORM,
               XmNbottomAttachment, XmATTACH_FORM,
               XmNheight, VIS_PUSH_BUTTON_HEIGHTS,
               XmNwidth, VIS_PUSH_BUTTON_WIDTHS,
               XmNuserData, CANCEL,
               NULL
             );
   XmStringFree(label);
   XtAddCallback(child, XmNactivateCallback, openOkCancelCB, CBD);


   /* now just above the bottom frame, universal options will appear */
   /* universal options include, projection length */
   sprintf(text, "%2.2f", (float)CBD->proj_len);
   child = XtVaCreateManagedWidget
             (
               "projection length",
               xmTextFieldWidgetClass,
               mainForm,
               XmNbottomAttachment, XmATTACH_WIDGET,
               XmNbottomWidget, frame,
               XmNrightAttachment, XmATTACH_FORM,
               XmNcolumns, 20,
               XmNuserData, PROJ_LEN,
               NULL
             );
   XmTextFieldSetString(child, text);
   XtAddCallback(child, XmNactivateCallback, numberTextEntryCB, CBD);
   XtAddCallback(child, XmNlosingFocusCallback, numberTextEntryCB, CBD);

   label = XmStringCreate("Projection Length (Angstroms):", XmFONTLIST_DEFAULT_TAG);
   labelW = XtVaCreateManagedWidget
              (
                 "label",
                 xmLabelWidgetClass,
                 mainForm,
                 XmNrightAttachment, XmATTACH_WIDGET,
                 XmNrightWidget, child,
                 XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNtopWidget, child,
                 XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNbottomWidget, child,
                 XmNlabelString, label,
                 NULL
              );
   XmStringFree (label);

   sprintf(text, "%2.2f", (float)CBD->probeRadius);
   child = XtVaCreateManagedWidget
            (
               "Probe radius text field",
               xmTextFieldWidgetClass,
               mainForm,
               XmNbottomAttachment, XmATTACH_WIDGET,
               XmNbottomWidget, child,
               XmNrightAttachment, XmATTACH_FORM,
               XmNuserData, PROBE_RAD,
               NULL
            );
   XmTextFieldSetString(child, text);

   XtAddCallback(child, XmNactivateCallback, numberTextEntryCB, CBD);
   XtAddCallback(child, XmNlosingFocusCallback, numberTextEntryCB, CBD);
   label = XmStringCreate("Probe Radius:", XmFONTLIST_DEFAULT_TAG);
   labelW = XtVaCreateManagedWidget
              (
                 "label widget",
                 xmLabelWidgetClass,
                 mainForm,
                 XmNrightAttachment, XmATTACH_WIDGET,
                 XmNrightWidget, child,
                 XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNtopWidget, child,
                 XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNbottomWidget, child,
                 XmNlabelString, label,
                 NULL
              );
   XmStringFree(label);

   sprintf(text, "%2.2f", (float)CBD->triDens);
   child = XtVaCreateManagedWidget
            (
               "density text field",
               xmTextFieldWidgetClass,
               mainForm,
               XmNtopAttachment, XmATTACH_WIDGET,
               XmNtopWidget, CBD->GBparamFrame,
               XmNbottomAttachment, XmATTACH_WIDGET,
               XmNbottomWidget, child,
               XmNrightAttachment, XmATTACH_FORM,
               XmNuserData, TRI_DENSITY,
               NULL
            );
   XmTextFieldSetString(child, text);

   XtAddCallback(child, XmNactivateCallback, numberTextEntryCB, CBD);
   XtAddCallback(child, XmNlosingFocusCallback, numberTextEntryCB, CBD);
   label = XmStringCreate("Surface Triangle Density:", XmFONTLIST_DEFAULT_TAG);
   labelW = XtVaCreateManagedWidget
              (
                 "label widget",
                 xmLabelWidgetClass,
                 mainForm,
                 XmNrightAttachment, XmATTACH_WIDGET,
                 XmNrightWidget, child,
                 XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNtopWidget, child,
                 XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNbottomWidget, child,
                 XmNlabelString, label,
                 NULL
              );
   XmStringFree(label);

}

/************************************************************************
 * FUNCTION:  open_file_dialog  -- creates or pops up the dialog        *
 *                                                                      *
 * INPUTS:    w   -- the parent widget                                  *
 *            vis -- the vis data struct (everything)                   *
 *                                                                      *
 * OUTPUTS:   none                                                      *
 *                                                                      *
 ************************************************************************/
void open_file_dialog(Widget w, vis_data_struct *vis)
{
   /* local variables */
   /*******************/
   static FOpenCB_struct CBD={NULL,NULL,NULL,NULL,NULL,NULL,1,3,0,1.,80.,2.0,.1,1.5, 3., 2.0, 0.}; 

   /* probably want to tie most of these values back into the vis struct to make
    * this run smoother between command line and gui */

   if (CBD.topLevel == NULL)
   {
      CBD.vis = vis;
      create_open_file_dialog (XtParent(w), &CBD);
   }
   
   XtPopup(CBD.topLevel, XtGrabNone);
}

void PotentialTypeCB(Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   FOpenCB_struct *CBD = (FOpenCB_struct *)clientD;
   int which;

   XtVaGetValues(w, XmNuserData, &which, NULL);

   CBD->phiType = which;
}

/* called when the potential source is toggled */
void PotentialSourceCB(Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   FOpenCB_struct *CBD = (FOpenCB_struct *)clientD;
   int which;
   XmToggleButtonCallbackStruct *tgcb = (XmToggleButtonCallbackStruct *)callD;

   if (!tgcb->set) return;
   
   XtVaGetValues(w, XmNuserData, &which, NULL);

   CBD->calcType = which;

   if (which == POPEN_CALC_NONE)
   {
      XtUnmanageChild(CBD->GBparamFrame);
      XtUnmanageChild(CBD->PHIparamFrame);
   }
   else if (which == POPEN_CALC_DIRECTLY)
   {
      XtManageChild(CBD->GBparamFrame);
      XtUnmanageChild(CBD->PHIparamFrame);
   }
   else
   {
      XtUnmanageChild(CBD->GBparamFrame);
      XtManageChild(CBD->PHIparamFrame);
   }
}

/* called when people type numbers into a text field */
void numberTextEntryCB(Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   FOpenCB_struct *CBD = (FOpenCB_struct *)clientD;
   int which, tmp;
   int err = 0;
   char *newMem;
   char buff[32];
   float val = 911911;

   XtVaGetValues(w, XmNuserData, &which, NULL);

   newMem = XmTextFieldGetString(w);

   if (sscanf(newMem, "%f", &val) < 1)
   {
      if (sscanf(newMem, "%i", &tmp) < 1)
        err = 1;
      else
        val = tmp;
   }

   XtFree(newMem);

   if (which == DIEL_EXT)
   {
      if (err)
         val = CBD->diel_ext;
      else
         CBD->diel_ext = val;

      sprintf(buff, "%2.2f", val);
      XtVaSetValues(w, XmNvalue, buff, NULL);
   }
   else if (which == DIEL_INT)
   {
      if (err)
         val = CBD->diel_int;
      else
         CBD->diel_int = val;

      sprintf(buff, "%2.2f", val);
      XtVaSetValues(w, XmNvalue, buff, NULL);
   }
   else if (which == SALT)
   {
      if (err)
         val = CBD->salt;
      else
         CBD->salt = val;

      sprintf(buff, "%2.2f", val);
      XtVaSetValues(w, XmNvalue, buff, NULL);
   }
   else if (which == SALT_RAD)
   {
      if (err)
         val = CBD->ion_exc_rad;
      else
         CBD->ion_exc_rad = val;

      sprintf(buff, "%2.2f", val);
      XtVaSetValues(w, XmNvalue, buff, NULL);
   }
   else if (which ==  PROJ_LEN)
   {
      if (err)
         val = CBD->proj_len;
      else
         CBD->proj_len = val;

      sprintf(buff, "%2.2f", val);
      XtVaSetValues(w, XmNvalue, buff, NULL);
   }
   else if (which == A_ESTIMATE)
   {
      if (err)
        val = CBD->A_value;
      else
        CBD->A_value = val;

      sprintf(buff, "%2.2f", val);
      XtVaSetValues(w, XmNvalue, buff, NULL);

   }
   else if (which == PROBE_RAD)
   {
      if (err)
        val = CBD->probeRadius;
      else
        CBD->probeRadius = val;

      sprintf(buff, "%2.2f", val);
      XtVaSetValues(w, XmNvalue, buff, NULL);
   }
   else /* TRI_DENSITY */
   {
      if (err)
         val = CBD->triDens;
      else
         CBD->triDens = val;

      sprintf(buff, "%2.2f", val);
      XtVaSetValues(w, XmNvalue, buff, NULL);
   }
}

/* called when ok or cancel are clicked */
void openOkCancelCB(Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   FOpenCB_struct *CBD = (FOpenCB_struct *)clientD;
   vis_data_struct *vis = CBD->vis;
   int which;
   char *molname = NULL,
        *aux     = NULL;

   /* first, lets hide the interface... */
   XtPopdown(CBD->topLevel);

   XtVaGetValues(w, XmNuserData, &which, NULL);

   if (which == OK)
   {
      molname = XmTextFieldGetString(CBD->PQRtextField);

      /* directories are not files... */
      if ((strlen(molname) < 6)||(molname[strlen(molname)-1] == '/'))
      {
         tellUser("Error", "Invalid file name.\n");
         XtFree(molname);
         XtPopup(CBD->topLevel, XtGrabNone);
         return;
      }
      /* else */

      /* strip the ".pqr" */
      molname[strlen(molname)-4] = '\0';

      if (CBD->calcType == POPEN_READ_PHIMAP)
         aux = XmTextFieldGetString(CBD->PHIoptionTextField);

      /* going to need to pass the phiType through <><> */
      popen_file
        (
           vis->params.toplevel,
           molname,
           CBD->calcType,
           aux,
           CBD->diel_int,
           CBD->diel_ext,
           CBD->salt,
           CBD->proj_len,
	        CBD->triDens,
           CBD->probeRadius,
           CBD->ion_exc_rad,
           CBD->phiType,
           ((CBD->userA)?CBD->A_value:0.0),
           vis
         );

      if (molname)
         XtFree(molname);
      if (aux)
         XtFree(aux);
   }

   /* break down shop */
   XtPopdown(CBD->topLevel);
}

/* called when people click "select" for a phimap file */
void selectPhimapButtonCB(Widget w, XtPointer clientD, XtPointer callD)
{
    /* local variables */
    FOpenCB_struct *CBD = (FOpenCB_struct *)clientD;

    Widget fsd;
    Arg args[5];
    XmString suff;
    
    suff = XmStringCreate("*.[fp][lh][di]", XmFONTLIST_DEFAULT_TAG);

    XtSetArg(args[0], XmNfileFilterStyle, XmFILTER_HIDDEN_FILES);
    XtSetArg(args[1], XmNpattern, suff);
    fsd = XmCreateFileSelectionDialog(XtParent(w), "opendialog", args, 2);
    XmStringFree(suff);

    XtUnmanageChild(XmSelectionBoxGetChild(fsd, XmDIALOG_HELP_BUTTON));
    XtUnmanageChild(XmFileSelectionBoxGetChild(fsd, XmDIALOG_FILTER_TEXT));
    XtUnmanageChild(XmFileSelectionBoxGetChild(fsd, XmDIALOG_FILTER_LABEL));

    /* add the callbacks */
    XtAddCallback(fsd, XmNokCallback, selectPhimapButtonOkCB, CBD);
    XtAddCallback(fsd, XmNcancelCallback, sp_cnCB, NULL);

    /* manage the dialog */
    XtManageChild(fsd);
    XtPopup(XtParent(fsd), XtGrabNone);

}

/* called when the ok or cancel buttons are clicked in the phimap select
   dialog */
void selectPhimapButtonOkCB(Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   FOpenCB_struct *CBD = (FOpenCB_struct *)clientD;
   Widget textField;
   char *fname;
  
   textField = XmFileSelectionBoxGetChild(w, XmDIALOG_TEXT);
   fname = XmTextFieldGetString(textField);

   printf("%s\n", fname);
   XmTextFieldSetString(CBD->PHIoptionTextField, fname);

   XtFree(fname);

   XtPopdown(XtParent(w));
   XtDestroyWidget(XtParent(w));
}

void sp_cnCB (Widget w, XtPointer clientD, XtPointer callD)
{
   XtPopdown(XtParent(w));
   XtDestroyWidget(XtParent(w));
}

/* called when the user A selection box is toggled on or off */
static void userAtoggleCB (Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   FOpenCB_struct *CBD = (FOpenCB_struct *)clientD;
   Widget textbox;

   XtVaGetValues(w, XmNuserData, &textbox, NULL);

   /* deselecting user input A values */
   if (CBD->userA)
   {
	XtSetSensitive(textbox, False);
        CBD->userA = 0;
   }
   else
   {
        XtSetSensitive(textbox, True);
	CBD->userA = 1;
   }
}
