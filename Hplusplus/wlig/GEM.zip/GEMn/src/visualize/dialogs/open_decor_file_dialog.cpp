/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
/*********************************************************************
 * This function pops up an open file dialog that allows the user to
 * open a file and calculate the potentials for it --jcg
 ********************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include "visualize.h"
#include "tellUser.h"
#include "structures.h"
#include "vis_defines.h"

/* for various Motif Widgets */
#include <Xm/MwmUtil.h>
#include <X11/Shell.h>
#include <Xm/RowColumn.h>
#include <Xm/SelectioB.h>
#include <Xm/FileSB.h>
#include <Xm/ToggleB.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>
#include <Xm/TextF.h>
#include <Xm/PushB.h>
#include <Xm/Form.h>

#include <string>
using namespace std;

typedef struct
{
   vis_data_struct *vis;

   Widget topLevel,
          fileTextField;

    char *filename;
    int option;

} DOpenCB_struct;

static void decorOkCancelCB(Widget w, XtPointer clientD, XtPointer callD);
static void decorDisplayTypeCB(Widget w, XtPointer clientD, XtPointer callD);

/**************************************************************************
 * FUNCTION:  create_open_decor_file_dialog  --creates and pops up the    *
 *                                             dialog to select and open  *
 *                                             a decoration molecule      *
 *                                                                        *
 * INPUTS:    parent  -- the parent widget                                *
 *            CBD -- the callback structure to contain all this data      *
 *                                                                        *
 * OUTPUTS:   none                                                        *
 *                                                                        *
 **************************************************************************/
void create_open_decor_file_dialog (Widget parent, DOpenCB_struct *CBD)
{
   /* local variables */
   Widget mainForm,
          frame,
          child,
          labelW,
          radioBox,
          form;

   XmString label;
   Arg args[5];

   CBD->topLevel = XtVaCreatePopupShell
                    (
                       "Open File",
                       topLevelShellWidgetClass,
                       parent,
                       XmNwidth,  DECOR_FILE_DIALOG_START_WIDTH,
                       XmNheight, DECOR_FILE_DIALOG_START_HEIGHT,
                       XmNmwmDecorations, MWM_DECOR_RESIZEH|MWM_DECOR_BORDER|MWM_DECOR_MINIMIZE|MWM_DECOR_TITLE,
                       XmNmwmFunctions,   MWM_FUNC_ALL|MWM_FUNC_CLOSE|MWM_FUNC_MAXIMIZE,
                       XmNmwmInputMode,   MWM_INPUT_FULL_APPLICATION_MODAL,
                       XmNdeleteResponse, XmDO_NOTHING,
                       NULL
                   );

   mainForm = XtVaCreateManagedWidget
                (
                   "mainFileSelectForm",
                   xmFormWidgetClass,
                   CBD->topLevel,
                   XmNtopAttachment,   XmATTACH_FORM,
                   XmNleftAttachment,  XmATTACH_FORM,
                   XmNrightAttachment, XmATTACH_FORM,
                   NULL
                );

   /* the first field on the top will be the Pqr File Name */
   label = XmStringCreate("*.pqr", XmFONTLIST_DEFAULT_TAG);
   XtSetArg(args[0], XmNfileFilterStyle, XmFILTER_HIDDEN_FILES);
   XtSetArg(args[1], XmNpattern, label);
   
   form = XmCreateFileSelectionBox(mainForm, "hoy", args, 2);
   XmStringFree(label);

   XtVaSetValues(form, XmNleftAttachment, XmATTACH_FORM, XmNrightAttachment, XmATTACH_FORM, NULL);
   XtUnmanageChild(XmSelectionBoxGetChild(form, XmDIALOG_OK_BUTTON));
   XtUnmanageChild(XmSelectionBoxGetChild(form, XmDIALOG_HELP_BUTTON));
   XtUnmanageChild(XmSelectionBoxGetChild(form, XmDIALOG_CANCEL_BUTTON));
   //XtUnmanageChild(XmSelectionBoxGetChild(form, XmDIALOG_APPLY_BUTTON));
   XtUnmanageChild(XmSelectionBoxGetChild(form, XmDIALOG_DEFAULT_BUTTON));
   XtUnmanageChild(XmSelectionBoxGetChild(form, XmDIALOG_SEPARATOR));
   XtUnmanageChild(XmFileSelectionBoxGetChild(form, XmDIALOG_FILTER_TEXT));
   XtUnmanageChild(XmFileSelectionBoxGetChild(form, XmDIALOG_FILTER_LABEL));

   label = XmStringCreate("Apply", XmFONTLIST_DEFAULT_TAG);
   XtVaSetValues(XmFileSelectionBoxGetChild(form, XmDIALOG_APPLY_BUTTON), XmNlabelString, label, NULL);
   XmStringFree(label);

   XtUnmanageChild(XmFileSelectionBoxGetChild(form, XmDIALOG_SEPARATOR));
   CBD->fileTextField = XmSelectionBoxGetChild(form, XmDIALOG_TEXT);

   XtManageChild(form);

   /* frame for the draw type */
   frame = XtVaCreateManagedWidget
             (
                "Radio Frame",
                xmFrameWidgetClass,
                mainForm,
                XmNtopAttachment, XmATTACH_WIDGET,
                XmNtopWidget, form,
                XmNleftAttachment, XmATTACH_FORM,
                XmNrightAttachment, XmATTACH_FORM,
                NULL
             );

   label = XmStringCreate("Draw Type", XmFONTLIST_DEFAULT_TAG);
   labelW = XtVaCreateManagedWidget
              (
                 "radio frame label",
                 xmLabelWidgetClass,
                 frame,
                 XmNlabelString, label,
                 XmNchildType, XmFRAME_TITLE_CHILD,
                 NULL
              );
    XmStringFree(label);

    radioBox = XtVaCreateManagedWidget
                 (
                    "radioBox",
                    xmRowColumnWidgetClass,
                    frame,
                    XmNpacking, XmPACK_COLUMN,
                    XmNradioAlwaysOne, True,
                    XmNradioBehavior, True,
                    XmNentryClass, xmToggleButtonWidgetClass,
                    NULL
                 );

      label = XmStringCreate("Surface Only", XmFONTLIST_DEFAULT_TAG);
      child = XtVaCreateManagedWidget
                (
                   "toggleButton",
                   xmToggleButtonWidgetClass,
                   radioBox,
                   XmNlabelString, label,
                   XmNindicatorType, XmONE_OF_MANY,
                   XmNvisibleWhenOff, True,
                   XmNuserData, 0,
                   XmNset, True,
                   NULL
                );
       XmStringFree(label);
       XtAddCallback(child, XmNvalueChangedCallback, decorDisplayTypeCB, CBD);

       XtVaSetValues(radioBox, XmNmenuHistory, child, NULL);

      label = XmStringCreate("Surface and Sticks", XmFONTLIST_DEFAULT_TAG);
      child = XtVaCreateManagedWidget
                (
                   "toggleButton",
                   xmToggleButtonWidgetClass,
                   radioBox,
                   XmNlabelString, label,
                   XmNindicatorType, XmONE_OF_MANY,
                   XmNvisibleWhenOff, True,
                   XmNuserData, 1,
                   XmNset, False,
                   NULL
                );
       XmStringFree(label);
       XtAddCallback(child, XmNvalueChangedCallback, decorDisplayTypeCB, CBD);

      label = XmStringCreate("Surface and Balls and Sticks", XmFONTLIST_DEFAULT_TAG);
      child = XtVaCreateManagedWidget
                (
                   "toggleButton",
                   xmToggleButtonWidgetClass,
                   radioBox,
                   XmNlabelString, label,
                   XmNindicatorType, XmONE_OF_MANY,
                   XmNvisibleWhenOff, True,
                   XmNuserData, 2,
                   XmNset, False,
                   NULL
                );
       XmStringFree(label);
       XtAddCallback(child, XmNvalueChangedCallback, decorDisplayTypeCB, CBD);

      label = XmStringCreate("Surface and Backbone", XmFONTLIST_DEFAULT_TAG);
      child = XtVaCreateManagedWidget
                (
                   "toggleButton",
                   xmToggleButtonWidgetClass,
                   radioBox,
                   XmNlabelString, label,
                   XmNindicatorType, XmONE_OF_MANY,
                   XmNvisibleWhenOff, True,
                   XmNuserData, 3,
                   XmNset, False,
                   NULL
                );
       XmStringFree(label);
       XtAddCallback(child, XmNvalueChangedCallback, decorDisplayTypeCB, CBD);

      label = XmStringCreate("Sticks", XmFONTLIST_DEFAULT_TAG);
      child = XtVaCreateManagedWidget
                (
                   "toggleButton",
                   xmToggleButtonWidgetClass,
                   radioBox,
                   XmNlabelString, label,
                   XmNindicatorType, XmONE_OF_MANY,
                   XmNvisibleWhenOff, True,
                   XmNuserData, 4,
                   XmNset, False,
                   NULL
                );
       XmStringFree(label);
       XtAddCallback(child, XmNvalueChangedCallback, decorDisplayTypeCB, CBD);

      label = XmStringCreate("Balls and Sticks", XmFONTLIST_DEFAULT_TAG);
      child = XtVaCreateManagedWidget
                (
                   "toggleButton",
                   xmToggleButtonWidgetClass,
                   radioBox,
                   XmNlabelString, label,
                   XmNindicatorType, XmONE_OF_MANY,
                   XmNvisibleWhenOff, True,
                   XmNuserData, 5,
                   XmNset, False,
                   NULL
                );
       XmStringFree(label);
       XtAddCallback(child, XmNvalueChangedCallback, decorDisplayTypeCB, CBD);

      label = XmStringCreate("Backbone", XmFONTLIST_DEFAULT_TAG);
      child = XtVaCreateManagedWidget
                (
                   "toggleButton",
                   xmToggleButtonWidgetClass,
                   radioBox,
                   XmNlabelString, label,
                   XmNindicatorType, XmONE_OF_MANY,
                   XmNvisibleWhenOff, True,
                   XmNuserData, 6,
                   XmNset, False,
                   NULL
                );
       XmStringFree(label);
       XtAddCallback(child, XmNvalueChangedCallback, decorDisplayTypeCB, CBD);

      label = XmStringCreate("Spacefill", XmFONTLIST_DEFAULT_TAG);
      child = XtVaCreateManagedWidget
                (
                   "toggleButton",
                   xmToggleButtonWidgetClass,
                   radioBox,
                   XmNlabelString, label,
                   XmNindicatorType, XmONE_OF_MANY,
                   XmNvisibleWhenOff, True,
                   XmNuserData, 7,
                   XmNset, False,
                   NULL
                );
       XmStringFree(label);
       XtAddCallback(child, XmNvalueChangedCallback, decorDisplayTypeCB, CBD);

   /* frame for ok and cancel buttons */
   frame = XtVaCreateManagedWidget
             (
               "ok cancel frame",
               xmFrameWidgetClass,
               mainForm,
               XmNtopAttachment, XmATTACH_WIDGET,
               XmNtopWidget, frame,
               XmNleftAttachment, XmATTACH_FORM,
               XmNrightAttachment, XmATTACH_FORM,
               NULL
             );

   form = XtVaCreateManagedWidget
            (
              "ok cancel form",
              xmFormWidgetClass,
              frame,
              NULL
            );

   label = XmStringCreate("Cancel", XmFONTLIST_DEFAULT_TAG);
   child = XtVaCreateManagedWidget
             (
               "cancel button",
               xmPushButtonWidgetClass,
               form,
               XmNlabelString, label,
               XmNleftAttachment, XmATTACH_FORM,
               XmNbottomAttachment, XmATTACH_FORM,
               XmNheight, VIS_PUSH_BUTTON_HEIGHTS,
               XmNwidth, VIS_PUSH_BUTTON_WIDTHS,
               XmNuserData, CANCEL,
               NULL
             );
   XmStringFree(label);
   XtAddCallback(child, XmNactivateCallback, decorOkCancelCB, CBD);

   label = XmStringCreate("Open", XmFONTLIST_DEFAULT_TAG);
   child = XtVaCreateManagedWidget
             (
               "ok button",
               xmPushButtonWidgetClass,
               form,
               XmNlabelString, label,
               XmNrightAttachment, XmATTACH_FORM,
               XmNbottomAttachment, XmATTACH_FORM,
               XmNheight, VIS_PUSH_BUTTON_HEIGHTS,
               XmNwidth, VIS_PUSH_BUTTON_WIDTHS,
               XmNuserData, OK,
               NULL
             );
    XmStringFree(label);
    XtAddCallback(child, XmNactivateCallback, decorOkCancelCB, CBD);


}

/**************************************************************************
 * FUNCTION:  open_decor_file_dialog         --creates and pops up the    *
 *                                             dialog to select and open  *
 *                                             a decoration molecule if   *
 *                                             it needs it, just pops up  *
 *                                             otherwise.                 *
 *                                                                        *
 * INPUTS:    w  -- the parent widget                                     *
 *            vis -- the vis data struct                                  *
 *                                                                        *
 * OUTPUTS:   none                                                        *
 *                                                                        *
 **************************************************************************/
void open_decor_file_dialog(Widget w, vis_data_struct *vis)
{
   /* local variables */
   /*******************/
   static DOpenCB_struct CBD={NULL,NULL,NULL,NULL,0};

   if (CBD.topLevel == NULL)
   {
      CBD.vis = vis;
      create_open_decor_file_dialog (XtParent(w), &CBD);
   }
   
   XtPopup(CBD.topLevel, XtGrabNone);
}

/* called when either ok or cancel is pressed */
void decorOkCancelCB(Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   DOpenCB_struct *CBD = (DOpenCB_struct *)clientD;
   vis_data_struct *vis = CBD->vis;
   int which, i;
   char *molname = NULL,
        *aux     = NULL;

   const int ntypes = 8;
   string names[ntypes]={"decorSurf","decorSurfSticks","decorSurfBallsSticks","decorSurfBackbone",
                         "decorSticks","decorBallsSticks","decorBackbone","decorSpacefill"};

   /* first, lets hide the interface... */
   XtPopdown(CBD->topLevel);

   XtVaGetValues(w, XmNuserData, &which, NULL);

   if (which == OK)
   {
      molname = XmTextFieldGetString(CBD->fileTextField);

      /* directories are not files... */
      if ((strlen(molname) < 6)||(molname[strlen(molname)-1] == '/'))
      {
         tellUser("Error", "Invalid file name.\n");
         XtFree(molname);
         XtPopup(CBD->topLevel, XtGrabNone);
         return;
      }
      /* else */

      /* to maintain a more or less constant maximum memory usage, lets
       * free up the old data before we end up allocating new data */
      if (vis->decor_mol.residues != NULL)
      {
         for (i = 0; i < vis->decor_mol.nresidues; i++)
            free(vis->decor_mol.residues[i].atoms);

         free(vis->decor_mol.residues);
      }

      if (vis->decor_mol.vert != NULL)
         free(vis->decor_mol.vert);
      if (vis->decor_mol.tri != NULL)
         free(vis->decor_mol.tri);
      if (vis->decor_mol.bonds != NULL)
         free(vis->decor_mol.bonds);

      /* make sure everything knows that there are no atoms, etc. */
      vis->decor_mol.nresidues = 0;
      vis->decor_mol.nvert     = 0;
      vis->decor_mol.ntri      = 0;
      vis->decor_mol.nbonds    = 0;

      /* strip the ".pqr" */
      molname[strlen(molname)-4] = '\0';

      open_decoration_molecule(molname, (char *)names[CBD->option].c_str(), vis);

      populate_statistics(vis);

      glXMakeCurrent
      (
         XtDisplay(vis->params.drawW),
         XtWindow(vis->params.drawW),
         vis->params.context_D
      );

      /* reset the view volume to fit the new space */
      glMatrixMode(GL_PROJECTION);
      glLoadIdentity();
      glOrtho
        (
           -vis->params.x[EXTENT]/2.,vis->params.x[EXTENT]/2.,
           -vis->params.y[EXTENT]/2.,vis->params.y[EXTENT]/2.,
           -vis->params.z[EXTENT]/2.,vis->params.z[EXTENT]/2.
        );

      glMatrixMode(GL_MODELVIEW);
      glLoadIdentity();

      glGetDoublev(GL_MODELVIEW_MATRIX, vis->params.rot_mat);
      glGetDoublev(GL_MODELVIEW_MATRIX, vis->params.rot_store_mat);

      /* refresh the decor list and now that we have changed the region, the atom and surface list */
      if (vis->params.atomList != 0)
      {
          gen_main_mol_lists(vis, (char)1, (char)1, -1.);

          gen_decor_mol_list(vis);
      }

      updateTranslations(vis, 1, 1);

      if (molname)
         XtFree(molname);
      if (aux)
         XtFree(aux);
   }
}

/* called when the display type is toggled */
static void decorDisplayTypeCB(Widget w, XtPointer clientD, XtPointer callD)
{
DOpenCB_struct *CBD = (DOpenCB_struct *)clientD;
int type;
    
    XtVaGetValues(w, XmNuserData, &type, NULL);
    CBD->option = type;
}
