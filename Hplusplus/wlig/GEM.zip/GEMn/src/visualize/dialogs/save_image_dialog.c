/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include "visualize.h"
#include "tellUser.h"
#include "structures.h"
#include "vis_defines.h"
#include "file_io.h"

/* for various Motif Widgets */
#include <Xm/MwmUtil.h>
#include <X11/Shell.h>
#include <Xm/RowColumn.h>
#include <Xm/SelectioB.h>
#include <Xm/FileSB.h>
#include <Xm/ToggleB.h>
#include <Xm/Frame.h>
#include <Xm/Label.h>
#include <Xm/TextF.h>
#include <Xm/PushB.h>
#include <Xm/Form.h>

typedef struct
{
   vis_data_struct *vis;

   Widget topLevel,
          filename_text_field,
          width_text_field,
          height_text_field;

} saveimage_CB_struct;

/* callbacks */
static void save_imageOkCancelCB(Widget w, XtPointer clientD, XtPointer callD);
static void entryCB (Widget w, XtPointer clientD, XtPointer callD);


/***********************************************************************
 * FUNCTION:  save_image_dialog  -- dialog to save a tga image         *
 *                                                                     *
 * INPUTS:     parent   -- the parent widget                           *
 *             vis      -- the vis data struct                         *
 *                                                                     *
 * OUTPUTS:    nothing                                                 *
 *                                                                     *
 ***********************************************************************/
void save_image_dialog (Widget parent, vis_data_struct *vis)
{
   /* local variables */
   Widget mainForm,
          frame,
          form,
          child,
          labelW;

   XmString label;
   Arg args[5];
   char text[32];

   saveimage_CB_struct *CBD;

   CBD = calloc(sizeof(saveimage_CB_struct), 1);

   CBD->vis = vis;
   CBD->topLevel = XtVaCreatePopupShell
                    (
                       "Open File",
                       topLevelShellWidgetClass,
                       parent,
                       XmNwidth,  SAVE_IMAGE_DIALOG_START_WIDTH,
                       XmNheight, SAVE_IMAGE_DIALOG_START_HEIGHT,
                       XmNmwmDecorations, MWM_DECOR_RESIZEH|MWM_DECOR_BORDER|MWM_DECOR_MINIMIZE|MWM_DECOR_TITLE|MWM_DECOR_MINIMIZE|MWM_DECOR_RESIZEH,
                       XmNmwmFunctions,   MWM_FUNC_ALL|MWM_FUNC_CLOSE|MWM_FUNC_MAXIMIZE,
                       XmNmwmInputMode,   MWM_INPUT_FULL_APPLICATION_MODAL,
                       NULL
                   );

   mainForm = XtVaCreateManagedWidget
                (
                   "mainFileSelectForm",
                   xmFormWidgetClass,
                   CBD->topLevel,
                   XmNtopAttachment,   XmATTACH_FORM,
                   XmNleftAttachment,  XmATTACH_FORM,
                   XmNrightAttachment, XmATTACH_FORM,
                   NULL
                );

   /* the first field on the top will be the Pqr File Name */
   label = XmStringCreate("*.tga", XmFONTLIST_DEFAULT_TAG);
   XtSetArg(args[0], XmNfileFilterStyle, XmFILTER_HIDDEN_FILES);
   XtSetArg(args[1], XmNpattern, label);
   
   form = XmCreateFileSelectionBox(mainForm, "hoy", args, 2);
   XmStringFree(label);

   XtVaSetValues(form, XmNleftAttachment, XmATTACH_FORM, XmNrightAttachment, XmATTACH_FORM, NULL);
   XtUnmanageChild(XmSelectionBoxGetChild(form, XmDIALOG_OK_BUTTON));
   XtUnmanageChild(XmSelectionBoxGetChild(form, XmDIALOG_HELP_BUTTON));
   XtUnmanageChild(XmSelectionBoxGetChild(form, XmDIALOG_CANCEL_BUTTON));
   //XtUnmanageChild(XmSelectionBoxGetChild(form, XmDIALOG_APPLY_BUTTON));
   XtUnmanageChild(XmSelectionBoxGetChild(form, XmDIALOG_DEFAULT_BUTTON));
   XtUnmanageChild(XmSelectionBoxGetChild(form, XmDIALOG_SEPARATOR));
   XtUnmanageChild(XmFileSelectionBoxGetChild(form, XmDIALOG_FILTER_TEXT));
   XtUnmanageChild(XmFileSelectionBoxGetChild(form, XmDIALOG_FILTER_LABEL));

   label = XmStringCreate("Apply", XmFONTLIST_DEFAULT_TAG);
   XtVaSetValues(XmFileSelectionBoxGetChild(form, XmDIALOG_APPLY_BUTTON), XmNlabelString, label, NULL);
   XmStringFree(label);

   XtUnmanageChild(XmFileSelectionBoxGetChild(form, XmDIALOG_SEPARATOR));
   CBD->filename_text_field = XmSelectionBoxGetChild(form, XmDIALOG_TEXT);

   XtManageChild(form);

   frame = XtVaCreateManagedWidget
             (
                "frame widget",
                xmFrameWidgetClass,
                mainForm,
                XmNtopAttachment, XmATTACH_WIDGET,
                XmNtopWidget, form,
                XmNleftAttachment,  XmATTACH_FORM,
                XmNrightAttachment, XmATTACH_FORM,
                NULL
             );

   label = XmStringCreate("Image Dimensions", XmFONTLIST_DEFAULT_TAG);
   labelW = XtVaCreateManagedWidget
              (
                 "label widget",
                 xmLabelWidgetClass,
                 frame,
                 XmNlabelString, label,
                 XmNchildType, XmFRAME_TITLE_CHILD,
                 NULL
              );
   XmStringFree(label);

   form = XtVaCreateManagedWidget
              (
                 "form widget",
                 xmFormWidgetClass,
                 frame,
                 XmNtopAttachment,    XmATTACH_FORM,
                 XmNleftAttachment,   XmATTACH_FORM,
                 XmNrightAttachment,  XmATTACH_FORM,
                 XmNbottomAttachment, XmATTACH_FORM,
                 NULL
              );


   /* going to need width and height fields here */
   sprintf(text, "%i", vis->params.draw_wid);
   CBD->width_text_field = XtVaCreateManagedWidget
                              (
                                 "width text field",
                                 xmTextFieldWidgetClass,
                                 form,
                                 XmNrightAttachment, XmATTACH_FORM,
                                 XmNrightOffset, 3,
                                 XmNtopAttachment, XmATTACH_FORM,
                                 XmNtopOffset, 3,
                                 XmNcolumns, 30,
                                 XmNuserData, 0,
                                 XmNvalue, text,
                                 NULL
                              );
    XtAddCallback(CBD->width_text_field, XmNactivateCallback, entryCB, CBD);
    XtAddCallback(CBD->width_text_field, XmNlosingFocusCallback, entryCB, CBD);

    label = XmStringCreateLocalized("Width:");
    child = XtVaCreateManagedWidget
               (
                 "width label",
                 xmLabelWidgetClass,
                 form,
                 XmNrightAttachment, XmATTACH_WIDGET,
                 XmNrightWidget, CBD->width_text_field,
                 XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNtopWidget, CBD->width_text_field,
                 XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNbottomWidget, CBD->width_text_field,
                 XmNlabelString, label,
                 NULL
               );
     XmStringFree(label);

   sprintf(text, "%i", vis->params.draw_hit - VIS_COLORBAR_HEIGHT);
   CBD->height_text_field = XtVaCreateManagedWidget
                               (
                                  "height text field",
                                  xmTextFieldWidgetClass,
                                  form,
                                  XmNrightAttachment, XmATTACH_FORM,
                                  XmNrightOffset,     3,
                                  XmNtopAttachment, XmATTACH_WIDGET,
                                  XmNtopWidget, CBD->width_text_field,
                                  XmNtopOffset,       3,
                                  XmNcolumns, 30,
                                  XmNvalue, text,
                                  XmNuserData, 1,
                                  NULL
                               );
    XtAddCallback(CBD->height_text_field, XmNactivateCallback, entryCB, CBD);
    XtAddCallback(CBD->height_text_field, XmNlosingFocusCallback, entryCB, CBD);

    label = XmStringCreateLocalized("height:");
    child = XtVaCreateManagedWidget
               (
                 "height label",
                 xmLabelWidgetClass,
                 form,
                 XmNrightAttachment, XmATTACH_WIDGET,
                 XmNrightWidget, CBD->height_text_field,
                 XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNtopWidget, CBD->height_text_field,
                 XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNbottomWidget, CBD->height_text_field,
                 XmNlabelString, label,
                 NULL
               );
     XmStringFree(label);




   frame = XtVaCreateManagedWidget
             (
               "frame",
               xmFrameWidgetClass,
               mainForm,
               XmNbottomAttachment, XmATTACH_FORM,
               XmNrightAttachment,  XmATTACH_FORM,
               XmNleftAttachment,   XmATTACH_FORM,
               XmNtopAttachment,    XmATTACH_WIDGET,
               XmNtopWidget,        frame,
               NULL
             );

   form = XtVaCreateManagedWidget
            (
              "form",
              xmFormWidgetClass,
              frame,
              NULL
            );

   label = XmStringCreate("Save", XmFONTLIST_DEFAULT_TAG);
   child = XtVaCreateManagedWidget
             (
               "child",
               xmPushButtonWidgetClass,
               form,
               XmNlabelString, label,
               XmNrightAttachment, XmATTACH_FORM,
               XmNbottomAttachment, XmATTACH_FORM,
               XmNheight, VIS_PUSH_BUTTON_HEIGHTS,
               XmNwidth, VIS_PUSH_BUTTON_WIDTHS,
               XmNuserData, OK,
               NULL
             );
   XmStringFree(label);
   XtAddCallback(child, XmNactivateCallback, save_imageOkCancelCB, CBD);

   label = XmStringCreate("Cancel", XmFONTLIST_DEFAULT_TAG);
   child = XtVaCreateManagedWidget
             (
               "child",
               xmPushButtonWidgetClass,
               form,
               XmNlabelString, label,
               XmNleftAttachment, XmATTACH_FORM,
               XmNbottomAttachment, XmATTACH_FORM,
               XmNheight, VIS_PUSH_BUTTON_HEIGHTS,
               XmNwidth, VIS_PUSH_BUTTON_WIDTHS,
               XmNuserData, CANCEL,
               NULL
             );
   XmStringFree(label);
   XtAddCallback(child, XmNactivateCallback, save_imageOkCancelCB, CBD);

   XtPopup(CBD->topLevel, XtGrabNone);
}

static void entryCB (Widget w, XtPointer clientD, XtPointer callD)
{
saveimage_CB_struct *CBD = (saveimage_CB_struct *)clientD;
vis_data_struct *vis = CBD->vis;
int val1 = 0, val2 = 0;
char buff[32];
int which;
int hit, wid;
char *newmem = XmTextFieldGetString(w);

   XtVaGetValues(w, XmNuserData, &which, NULL);

   sscanf(newmem, "%i", &val1);

   XtFree(newmem);

   hit = vis->params.draw_hit - VIS_COLORBAR_HEIGHT;
   wid = vis->params.draw_wid;

   if (which == 0)
   {
      val2 = (val1 * hit)/(float)wid;
      sprintf(buff, "%i", val2);
      XtVaSetValues(CBD->height_text_field, XmNvalue, buff, NULL);
   }
   else
   {
      val2 = (val1 * wid)/(float)hit;
      sprintf(buff, "%i", val2);
      XtVaSetValues(CBD->width_text_field, XmNvalue, buff, NULL);
   }
}

/* called when ok or cancel are clicked */
void save_imageOkCancelCB(Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   saveimage_CB_struct *CBD = (saveimage_CB_struct *)clientD;
   vis_data_struct *vis = CBD->vis;
   char *filename   = NULL,
        *width_str  = NULL,
        *height_str = NULL;

   int width, height, which;

   char *withTail;

   /* first, lets hide the interface... */
   XtPopdown(CBD->topLevel);

   XtVaGetValues(w, XmNuserData, &which, NULL);

   if (which == OK)
   {
      filename = XmTextFieldGetString(CBD->filename_text_field);

      /* directories are not files... */
      if ((strlen(filename) < 5)||(filename[strlen(filename)-1] == '/'))
      {
         tellUser("Error", "Invalid file name.\n");
         XtFree(filename);
         XtPopup(CBD->topLevel, XtGrabNone);
         return;
      }

      width_str   = XmTextFieldGetString(CBD->width_text_field);
      height_str  = XmTextFieldGetString(CBD->height_text_field);

      if ((sscanf(width_str, "%i", &width) < 1)||(sscanf(height_str, "%i", &height) < 1))
      {
         tellUser("Error", "Width and height must be integers.\n");
         XtFree(filename);
         XtFree(width_str);
         XtFree(height_str);
         XtPopup(CBD->topLevel, XtGrabNone);
         return;
      }
      /* else */

     withTail = (char *)calloc(strlen(filename)+5, sizeof(char));
     if (filename[strlen(filename)-4] != '.')
     {
        sprintf(withTail, "%s.tga", filename);
     }
     else
     {
        sprintf(withTail, "%s", filename);
     }

     /* want to add dialog options for width and height eventually */
#ifdef __APPLE__
     if (!screenshot_framebuff(vis, width, height, withTail))
#else
     if (!screenshot_pbuff(vis, width, height, withTail))
#endif
     {
           width  = vis->params.draw_wid;
           height = vis->params.draw_hit;
           SaveScreenShot(vis, withTail, width, height);
           tellUser("Warning:","GEM could not allocate a pbuffer for off-screen rendering, captured image from screen.\n");
     }

     XtFree(filename);
     free(withTail);
   }

   /* break down shop */
   XtDestroyWidget(CBD->topLevel);
   free(CBD);
}
