/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include "visualize.h"
#include "file_io.h"
#include "calculations.h"
#include <stdlib.h>

/***************************************************************************
 * FUNCTION: write_grid_from_vis -- writes a phimap from a vis data struct *
 *                                  simplifies writing phimaps if you have *
 *                                  access to a vis data struct            *
 *                                                                         *
 * INPUTS:   filename -- the filename to write                             *
 *           edge     -- the number of cells on an edge of the grid        *
 *           width    -- the width of the phimap (real space)              *
 *           vis      -- the vis_data_struct pointer  (everything)         *
 **************************************************************************/
void write_grid_from_vis (char *filename, int edge, float width, vis_data_struct *vis)
{
/* local variables */
/*******************/
float cen_x, cen_y, cen_z;

/* need to determine Grid World Dims somehow */
float minDistanceGridWorldDims[6],
      new_grid_dims[6],
      halfwid = width/2.;

float *grd;
int *surfaceIdx;
int i, j, natoms;

  if ((vis->mol_data.calc_type & CALC_FLAG) == 0)
  {
     cen_x = (vis->mol_data.grid_world_dims[0] + vis->mol_data.grid_world_dims[3]) / 2.;
     cen_y = (vis->mol_data.grid_world_dims[1] + vis->mol_data.grid_world_dims[4]) / 2.;
     cen_z = (vis->mol_data.grid_world_dims[2] + vis->mol_data.grid_world_dims[5]) / 2.;

     new_grid_dims[0] = cen_x - halfwid;
     new_grid_dims[1] = cen_y - halfwid;
     new_grid_dims[2] = cen_z - halfwid;
     new_grid_dims[3] = cen_x + halfwid;
     new_grid_dims[4] = cen_y + halfwid;
     new_grid_dims[5] = cen_z + halfwid;

     /* subsample grid if our current data is based on a grid --jcg */
     grd = (float *)calloc(edge*edge*edge, sizeof(float));
     resample_grid
        (vis->mol_data.grid,
         vis->mol_data.grid_x_dim, vis->mol_data.grid_world_dims,
         grd, edge, new_grid_dims);

     write_grid
        (
           filename,
           edge,
           grd,
           cen_x,
           cen_y,
           cen_z,
           width
        );

     free(grd);
   }
   else  /* calculated by GEM */
   {

      /* have to go through mol to find center of mass of atoms to be happy with
       * MEAD and such, we usually use center of mass of surface... --jcg */
      cen_x = cen_y = cen_z = 0;
      natoms = 0;

      for (i = 0; i < vis->mol_data.nresidues; i++)
      {
          natoms += vis->mol_data.residues[i].natoms;

          for (j = 0; j < vis->mol_data.residues[i].natoms; j++)
          {
              cen_x += vis->mol_data.residues[i].atoms[j].x;
              cen_y += vis->mol_data.residues[i].atoms[j].y;
              cen_z += vis->mol_data.residues[i].atoms[j].z;
          }
      }

      cen_x /= (float)natoms;
      cen_y /= (float)natoms;
      cen_z /= (float)natoms;
      
      printf("writing a phimap centered at (%f, %f, %f)\n", cen_x, cen_y, cen_z);
      fflush(stdout);

      /* bounding cube needs to be of width "width" */
      minDistanceGridWorldDims[0] = cen_x - halfwid;
      minDistanceGridWorldDims[1] = cen_y - halfwid;
      minDistanceGridWorldDims[2] = cen_z - halfwid;
      minDistanceGridWorldDims[3] = cen_x + halfwid;
      minDistanceGridWorldDims[4] = cen_y + halfwid;
      minDistanceGridWorldDims[5] = cen_z + halfwid;

      /* get grid distances */
      printf("starting distance calculations\n");
      fflush(stdout);
      gridDistances(&grd,
               &surfaceIdx,
               edge, edge, edge,
               minDistanceGridWorldDims,
               vis->mol_data.vert,
               vis->mol_data.nvert);

      if ((grd == NULL)||(surfaceIdx == NULL))
      {
         fprintf(stderr,"Error: not enough space to store the grid.\n");
         return;
      }

      printf("Starting potential calculations\n");
      fflush(stdout);

      calc_potential_grid
           (
               vis->mol_data.residues,
               vis->mol_data.nresidues,
               vis->mol_data.vert,
               vis->mol_data.nvert,
               surfaceIdx,
               grd,
               edge,edge,edge,
               minDistanceGridWorldDims,
               vis->mol_data.A,
               vis->mol_data.diel_int,
               vis->mol_data.diel_ext,
               vis->mol_data.sal,
               vis->mol_data.ion_exc_rad,
               vis->mol_data.phiType
           );

      free(surfaceIdx);

      write_grid
         (
            filename,
            edge,
            grd,
            cen_x,
            cen_y,
            cen_z,
            width
         );

      free(grd);
   }

   printf("Done writing phimap\n");
   fflush(stdout);
}
