/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

#include "visualize.h"
#include <Xm/Form.h>
#include <Xm/Label.h>
#include <Xm/PushB.h>
#include <Xm/MwmUtil.h>
#include <GL/GLwDrawA.h>
#include <stdlib.h>
#include <stdio.h>

/*****************************************************************
 * This file defines the status dialog widget, which effectively *
 * manages a run by executing it on a timer piece by piece, while*
 * providing feedback to the user about the status and progress  *
 * of the run.                                  --jcg            *
 ****************************************************************/

/* callback functions */
static void _statusInitCB   (Widget, XtPointer, XtPointer);
static void _statusResizeCB (Widget, XtPointer, XtPointer);
static void _statusExposeCB (Widget, XtPointer, XtPointer);
static Boolean _statusUpdateCB (XtPointer);

/* utility functions */
void _statusRedraw (status_dialog_struct *status);
Boolean _statusRunStep (status_dialog_struct *status);

/*
 * This function creates a status dialog that calls the function "f"
 * on data "d" with label "s" --jcg
 */

status_dialog_struct *create_status_dialog(Widget w, void *d, int (*f)(void *, int), char *s, XVisualInfo *vi)
{
   /* local variables */
   status_dialog_struct *status;
   Widget mainForm,
          label;

   XmString str;

   char     tmp [20];

   /* also initializes the struct to all zeroes */
   status = (status_dialog_struct *)calloc(1, sizeof(status_dialog_struct));

   status->func     = f;
   status->userData = d;

   status->toplevel = XtVaCreatePopupShell
                        (
                           "Status Dialog",
                           topLevelShellWidgetClass,
                           w,
                           XmNwidth,  310,
                           XmNheight, 100,
                           XmNmwmDecorations, MWM_DECOR_ALL|MWM_DECOR_ALL,
                           XmNmwmFunctions,   MWM_FUNC_ALL|MWM_FUNC_ALL,
                           XmNdeleteResponse, XmUNMAP,
                           NULL
                        );

   mainForm = XtVaCreateManagedWidget
                (
                   "mainForm",
                   xmFormWidgetClass,
                   status->toplevel,
                   NULL
                );

   if (s != NULL)
      str = XmStringCreateLocalized(s);
   else
      str = XmStringCreateLocalized("Running");
   label = XtVaCreateManagedWidget
             (
                "label",
                xmLabelWidgetClass,
                mainForm,
                XmNlabelString, str,
                XmNtopAttachment,   XmATTACH_FORM,
                XmNleftAttachment,  XmATTACH_FORM,
                XmNrightAttachment, XmATTACH_FORM,
                XmNalignment,       XmALIGNMENT_CENTER,
                NULL
             );
   XmStringFree(str);

   status->statusBar = XtVaCreateManagedWidget
                         (
                            "status Bar",
                            glwDrawingAreaWidgetClass,
                            mainForm,
                            GLwNvisualInfo, vi,
                            XmNheight, 47,
                            XmNtopAttachment, XmATTACH_WIDGET,
                            XmNtopWidget, label,
                            XmNtopOffset, 3,
                            XmNleftAttachment, XmATTACH_FORM,
                            XmNleftOffset, 3,
                            XmNrightAttachment, XmATTACH_FORM,
                            XmNrightOffset, 3,
                            NULL
                         );
  XtAddCallback(status->statusBar, GLwNginitCallback,  _statusInitCB,   status);
  XtAddCallback(status->statusBar, GLwNresizeCallback, _statusResizeCB, status);
  XtAddCallback(status->statusBar, GLwNexposeCallback, _statusExposeCB, status);

  
  sprintf(tmp, "%i %c", status->progress, '%');
  str = XmStringCreateLocalized(tmp);
  status->progressW = XtVaCreateManagedWidget
                       (
                         "progress",
                         xmLabelWidgetClass,
                         mainForm,
                         XmNlabelString, str,
                         XmNtopAttachment, XmATTACH_WIDGET,
                         XmNtopWidget, status->statusBar,
                         XmNleftAttachment, XmATTACH_FORM,
                         XmNleftOffset, 3,
                         XmNrightAttachment, XmATTACH_FORM,
                         XmNrightOffset, 3,
                         XmNalignment, XmALIGNMENT_CENTER,
                         NULL
                       );
   XmStringFree(str);

   return status;
}

/* manages the status window and starts the run */
void status_start_run(XtAppContext app, status_dialog_struct *status)
{
   XtPopup(status->toplevel, XtGrabNone);

   /* start the run */
   status->workId = XtAppAddWorkProc(app, _statusUpdateCB, status);

}

void status_pause_run(status_dialog_struct *status)
{
   XtRemoveWorkProc(status->workId);
}

void status_set_finalize (status_dialog_struct *status,void (*c)(void *))
{
    status->clean = c;
}

void destroy_status_dialog(status_dialog_struct *status)
{
    XtRemoveWorkProc(status->workId);
    XtPopdown(status->toplevel);
    XtDestroyWidget(status->toplevel);
    free(status);
}

/**********************/
/* callback functions */
/**********************/

void _statusInitCB (Widget w, XtPointer clientD, XtPointer callD)
{
    /* local variables */
    XVisualInfo *vi;
    status_dialog_struct *status = (status_dialog_struct *)clientD;

    XtVaGetValues(w, GLwNvisualInfo, &vi, NULL);
    
    /* create the context we are going to reuse */
    status->con = glXCreateContext(XtDisplay(w), vi, None, GL_TRUE);

    glXMakeCurrent(XtDisplay(w), XtWindow(w), status->con);

    glMatrixMode(GL_PROJECTION);
    glClearColor(1., 0., 0., 1.);    /* red background */
    glLoadIdentity();

    glOrtho
      (
         0, 100,
        -1, 1,
        -1, 1
      );

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    _statusRedraw(status);
        
}

void _statusResizeCB (Widget w, XtPointer clientD, XtPointer callD)
{
    /* local variables */
    status_dialog_struct *status = (status_dialog_struct *)clientD;
    GLwDrawingAreaCallbackStruct *cd = (GLwDrawingAreaCallbackStruct *)callD;

    glXMakeCurrent(XtDisplay(w), XtWindow(w), status->con);

    glMatrixMode(GL_PROJECTION);
    glViewport(0, 0, cd->width, cd->height);

    _statusRedraw (status);

}

void _statusExposeCB (Widget w, XtPointer clientD, XtPointer callD)
{
    /* local variables */
    status_dialog_struct *status = (status_dialog_struct *)clientD;

    glXMakeCurrent(XtDisplay(w), XtWindow(w), status->con);
    _statusRedraw (status);

}

static Boolean _statusUpdateCB (XtPointer clientD)
{
   /* local variables */
   status_dialog_struct *status = (status_dialog_struct *)clientD;

   return _statusRunStep(status);

}

/*********************/
/* utility functions */
/*********************/

void _statusRedraw (status_dialog_struct *status)
{
   glClear(GL_COLOR_BUFFER_BIT);

   glColor3f(.1,1,.1); /* green */

   glBegin(GL_QUADS);
      glVertex3i(0,                -1, -1);
      glVertex3i(0,                 1, -1);
      glVertex3i(status->progress,  1, -1);
      glVertex3i(status->progress, -1, -1);
   glEnd();

   /* swap the buffers to show the update */
   glXSwapBuffers(XtDisplay(status->statusBar), XtWindow(status->statusBar));
}

Boolean _statusRunStep (status_dialog_struct *status)
{
   /* local variables */
   char status_str[32];
   XmString label;

   if (!status)
   {
      printf("Status is not defined\n");
      return True;
   }

   /* do a step of the run */
   if (status->func)
   {
      status->progress = status->func(status->userData, status->progress);
   }
   else
   {
      printf("NO FUNCTION DEFINED\n");
      return True;
   }

   if ((status->progress - status->lastUp) > 0)
   {
      /* redraw the bar */
      glXMakeCurrent
         (
            XtDisplay(status->statusBar),
            XtWindow(status->statusBar),
            status->con
         );

      _statusRedraw(status);

      sprintf(status_str, "%i %c", status->progress, '%');
      label = XmStringCreateLocalized(status_str);
      XtVaSetValues(status->progressW, XmNlabelString, label, NULL);
      XmStringFree(label);

      /* let the application know it has updated */
      status->lastUp = status->progress;
   }

   /* check for done */
   if ((status->progress >= 100) || (status->progress <= 0))
   {
      XtRemoveWorkProc (status->workId);

      /* call the finalization routine */
      if (status->clean)
         status->clean(status->userData);

      return True;
   }

   /* else */
   return False;
}
