/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

#include "visualize.h"
#include "structures.h"
#include "defines.h"
#include <Xm/MwmUtil.h>
#include <Xm/Frame.h>
#include <Xm/PushB.h>
#include <X11/Shell.h>
#include <Xm/Label.h>
#include <Xm/RowColumn.h>
#include <Xm/ScrolledW.h>
#include <Xm/Form.h>
#include <stdlib.h>
#include <stdio.h>

/* callback functions */
static void atomInfoCloseCB(Widget, XtPointer, XtPointer);

/***************************************************************************
 * FUNCTION:  clear_atom_info_dialog  -- clears an atom info dialog        * 
 *                                                                         *
 * INPUTS:    parent  -- the parent widget                                 *
 *                                                                         *
 ***************************************************************************/
void clear_atom_info_dialog(atom_info_dialog_struct *atom_info)
{
/* local variables */
Widget parent;

   if ((atom_info == NULL) || (atom_info->vis_ptr == NULL)) return;

   parent = XtParent(XtParent(atom_info->atomRowCol));
   XtUnmanageChild(atom_info->atomRowCol);
   XtDestroyWidget(atom_info->atomRowCol);

   atom_info->atomRowCol = XtVaCreateManagedWidget
                             (
                                "rowcol",
                                xmRowColumnWidgetClass,
                                parent,
                                XmNtopAttachment, XmATTACH_FORM,
                                XmNleftAttachment, XmATTACH_FORM,
                                XmNrightAttachment, XmATTACH_FORM,
                                XmNbottomAttachment, XmATTACH_FORM,
                                XmNpacking, XmPACK_COLUMN,
                                XmNorientation, XmVERTICAL,
                                XmNnumColumns, 1,
                                NULL
                             );

   XtVaSetValues(parent, XmNworkWindow, atom_info->atomRowCol, NULL);

}

/***************************************************************************
 * FUNCTION:  fill_atom_info_dialog  -- fills the atom info dialog         *
 *                                                                         *
 * INPUTS:    parent  -- the parent widget                                 *
 *                                                                         *
 ***************************************************************************/
void fill_atom_info_dialog(atom_info_dialog_struct *atom_info)
{
/* local variables */
vis_data_struct *vis;
Widget form,
       labelW;

XmString label;

char buffer[64];

int i, natoms, res;

   /* conditions where we do not fill the dialog (extensive i guess) */
   if ((atom_info == NULL) || (atom_info->vis_ptr == NULL) 
      || (atom_info->current_res < 0)) return;

   res = atom_info->current_res;
   vis = (vis_data_struct *)atom_info->vis_ptr;

   if (res > vis->mol_data.nresidues) return;

   /* else */
   natoms = vis->mol_data.residues[res].natoms;

   for (i = 0; i < natoms; i++)
   {
      form = XtVaCreateManagedWidget
               (
                  "form",
                  xmRowColumnWidgetClass,
                  atom_info->atomRowCol,
                  XmNorientation, XmHORIZONTAL,
                  XmNnumColumns, 1,
                  XmNpacking, XmPACK_COLUMN,
                  NULL
               );

      label = XmStringCreateLocalized(vis->mol_data.residues[res].atoms[i].name);
      labelW = XtVaCreateManagedWidget
                 (
                    "label",
                    xmLabelWidgetClass,
                    form,
                    XmNlabelString, label,
                    XmNtopAttachment, XmATTACH_FORM,
                    XmNleftAttachment, XmATTACH_FORM,
                    XmNbottomAttachment, XmATTACH_FORM,
                    NULL
                 );
      XmStringFree(label);

      sprintf(buffer, "%i", vis->mol_data.residues[res].atoms[i].index);
      label = XmStringCreateLocalized(buffer);
      labelW = XtVaCreateManagedWidget
                 (
                    "label",
                    xmLabelWidgetClass,
                    form,
                    XmNlabelString, label,
                    XmNtopAttachment, XmATTACH_FORM,
                    XmNleftAttachment, XmATTACH_WIDGET,
                    XmNleftWidget, labelW,
                    XmNbottomAttachment, XmATTACH_FORM,
                    NULL
                 );
      XmStringFree(label);

      sprintf(buffer, "%2.2f", vis->mol_data.residues[res].atoms[i].x);
      label = XmStringCreateLocalized(buffer);
      labelW = XtVaCreateManagedWidget
                 (
                    "label",
                    xmLabelWidgetClass,
                    form,
                    XmNlabelString, label,
                    XmNtopAttachment, XmATTACH_FORM,
                    XmNleftAttachment, XmATTACH_WIDGET,
                    XmNleftWidget, labelW,
                    XmNbottomAttachment, XmATTACH_FORM,
                    NULL
                 );
      XmStringFree(label);

      sprintf(buffer, "%2.2f", vis->mol_data.residues[res].atoms[i].y);
      label = XmStringCreateLocalized(buffer);
      labelW = XtVaCreateManagedWidget
                 (
                    "label",
                    xmLabelWidgetClass,
                    form,
                    XmNlabelString, label,
                    XmNtopAttachment, XmATTACH_FORM,
                    XmNleftAttachment, XmATTACH_WIDGET,
                    XmNleftWidget, labelW,
                    XmNbottomAttachment, XmATTACH_FORM,
                    NULL
                 );
      XmStringFree(label);

      sprintf(buffer, "%2.2f", vis->mol_data.residues[res].atoms[i].z);
      label = XmStringCreateLocalized(buffer);
      labelW = XtVaCreateManagedWidget
                 (
                    "label",
                    xmLabelWidgetClass,
                    form,
                    XmNlabelString, label,
                    XmNtopAttachment, XmATTACH_FORM,
                    XmNleftAttachment, XmATTACH_WIDGET,
                    XmNleftWidget, labelW,
                    XmNbottomAttachment, XmATTACH_FORM,
                    NULL
                 );
      XmStringFree(label);

      sprintf(buffer, "%2.2f", vis->mol_data.residues[res].atoms[i].charge/ELECTROSTATIC_CONVERSION_FACTOR);
      label = XmStringCreateLocalized(buffer);
      labelW = XtVaCreateManagedWidget
                 (
                    "label",
                    xmLabelWidgetClass,
                    form,
                    XmNlabelString, label,
                    XmNtopAttachment, XmATTACH_FORM,
                    XmNleftAttachment, XmATTACH_WIDGET,
                    XmNleftWidget, labelW,
                    XmNbottomAttachment, XmATTACH_FORM,
                    NULL
                 );
      XmStringFree(label);

      sprintf(buffer, "%2.2f", vis->mol_data.residues[res].atoms[i].radius);
      label = XmStringCreateLocalized(buffer);
      labelW = XtVaCreateManagedWidget
                 (
                    "label",
                    xmLabelWidgetClass,
                    form,
                    XmNlabelString, label,
                    XmNtopAttachment, XmATTACH_FORM,
                    XmNleftAttachment, XmATTACH_WIDGET,
                    XmNleftWidget, labelW,
                    XmNbottomAttachment, XmATTACH_FORM,
                    XmNrightAttachment, XmATTACH_FORM,
                    NULL
                 );
      XmStringFree(label);
   }
}

/***************************************************************************
 * FUNCTION:  create_atom_info_dialog  -- creates an atom info dialog      *
 *                                                                         *
 * INPUTS:    parent  -- the parent widget                                 *
 *                                                                         *
 * RETRNS:    a structure containing an atom info dialog and some key      *
 *            handles                                                      *
 *                                                                         *
 ***************************************************************************/
atom_info_dialog_struct *create_atom_info_dialog (Widget parent, void *vis)
{
   /* local variables */
   atom_info_dialog_struct *atom_info;

   Widget topForm,
          frame,
          labelW,
          closeButton,
          scrolledWin;

   XmString label,
            none;

   atom_info = (atom_info_dialog_struct *)calloc(1, sizeof(atom_info_dialog_struct));

   atom_info->vis_ptr = vis;

   none = XmStringCreateLocalized("none");

   atom_info->topLevel = XtVaCreatePopupShell
                         (
                            "Atom Information",
                            topLevelShellWidgetClass,
                            parent,
                            XmNwidth,  305,
                            XmNheight, 255,
                            XmNmwmDecorations, MWM_DECOR_ALL|MWM_DECOR_ALL,
                            XmNmwmFunctions,   MWM_FUNC_ALL|MWM_FUNC_ALL,
                            XmNdeleteResponse, XmUNMAP,
                            NULL
                         );

   topForm = XtVaCreateManagedWidget
            (
               "MainForm",
               xmFormWidgetClass,
               atom_info->topLevel,
               NULL
            );

   label = XmStringCreateLocalized("Residue:");
   labelW = XtVaCreateManagedWidget
           (
              "tag",
              xmLabelWidgetClass,
              topForm,
              XmNtopAttachment, XmATTACH_FORM,
              XmNleftAttachment, XmATTACH_FORM,
              XmNleftOffset, 5,
              XmNlabelString, label,
              NULL
           );
   XmStringFree(label);

   atom_info->residueLabel = XtVaCreateManagedWidget
                               (
                                  "residue",
                                  xmLabelWidgetClass,
                                  topForm,
                                  XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET,
                                  XmNtopWidget, labelW,
                                  XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
                                  XmNbottomWidget, labelW,
                                  XmNleftAttachment, XmATTACH_WIDGET,
                                  XmNleftWidget, labelW,
                                  XmNlabelString, none,
                                  NULL
                               );


   label = XmStringCreateLocalized("Close");
   closeButton = XtVaCreateManagedWidget
                   (
                      "closeButton",
                      xmPushButtonWidgetClass,
                      topForm,
                      XmNrightAttachment, XmATTACH_FORM,
                      XmNrightOffset, 5,
                      XmNbottomAttachment, XmATTACH_FORM,
                      XmNbottomOffset, 5,
                      XmNwidth, 75,
                      XmNheight, 30,
                      XmNlabelString, label,
                      NULL
                   );
   XmStringFree(label);
   XtAddCallback(closeButton, XmNactivateCallback, atomInfoCloseCB, atom_info);

   atom_info->totalChargeLabel = XtVaCreateManagedWidget
                                   (
                                      "total_charge",
                                      xmLabelWidgetClass,
                                      topForm,
                                      XmNlabelString, none,
                                      XmNbottomAttachment, XmATTACH_WIDGET,
                                      XmNbottomWidget, closeButton,
                                      XmNrightAttachment, XmATTACH_FORM,
                                      NULL
                                   );

   label = XmStringCreateLocalized("Total Charge:");
   XtVaCreateManagedWidget
     (
        "label",
        xmLabelWidgetClass,
        topForm,
        XmNlabelString, label,
        XmNrightAttachment, XmATTACH_WIDGET,
        XmNrightWidget, atom_info->totalChargeLabel,
        XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET,
        XmNtopWidget, atom_info->totalChargeLabel,
        XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
        XmNbottomWidget, atom_info->totalChargeLabel,
        NULL
     );
   XmStringFree(label);

   XmStringFree(none);

   frame = XtVaCreateManagedWidget
             (
                "frame",
                xmFrameWidgetClass,
                topForm,
                XmNtopAttachment, XmATTACH_WIDGET,
                XmNtopWidget, atom_info->residueLabel,
                XmNleftAttachment, XmATTACH_FORM,
                XmNrightAttachment, XmATTACH_FORM,
                XmNbottomAttachment, XmATTACH_WIDGET, 
                XmNbottomWidget, atom_info->totalChargeLabel,
                NULL
             );

   label = XmStringCreateLocalized("Atoms");
   labelW = XtVaCreateManagedWidget
              (
                 "atomlabel",
                 xmLabelWidgetClass,
                 frame,
                 XmNchildType, XmFRAME_TITLE_CHILD,
                 XmNlabelString, label,
                 NULL
              );
   XmStringFree(label);

   scrolledWin = XtVaCreateManagedWidget
                   (
                       "scrolledwin",
                       xmScrolledWindowWidgetClass,
                       frame,
                       XmNchildType, XmFRAME_WORKAREA_CHILD,
                       XmNtopAttachment, XmATTACH_FORM,
                       XmNleftAttachment, XmATTACH_FORM, 
                       XmNrightAttachment, XmATTACH_FORM, 
                       XmNbottomAttachment, XmATTACH_FORM, 
                       XmNscrollBarDisplayPolicy, XmAS_NEEDED,
                       XmNscrollingPolicy, XmAUTOMATIC,
                       XmNvisualPolicy, XmSTATIC,
                       NULL
                   );

   atom_info->atomRowCol = XtVaCreateManagedWidget
                             (
                                "rowcol",
                                xmRowColumnWidgetClass,
                                scrolledWin,
                                XmNtopAttachment, XmATTACH_FORM,
                                XmNleftAttachment, XmATTACH_FORM,
                                XmNrightAttachment, XmATTACH_FORM,
                                XmNbottomAttachment, XmATTACH_FORM,
                                XmNpacking, XmPACK_COLUMN,
                                XmNorientation, XmVERTICAL,
                                XmNnumColumns, 2,
                                NULL
                             );

   return atom_info;
}

/* pops up the atom info dialog */
void popup_atom_info_dialog(atom_info_dialog_struct *atom_info)
{
   if (atom_info)
   {
      XtPopup(atom_info->topLevel, XtGrabNone);
      atom_info->popped_up = 1;
   }
}

/* hides the atom info dialog */
void popdown_atom_info_dialog(atom_info_dialog_struct *atom_info)
{
   if ((atom_info)&&(atom_info->popped_up))
   {
      XtPopdown(atom_info->topLevel);
      atom_info->popped_up = 0;
   }
}

/* updates all the fields in the atom info dialog */
void update_atom_info_dialog(atom_info_dialog_struct *atom_info)
{
   /* local variables */
   char     text[64];
   XmString label;
   vis_data_struct *vis;

   if ((atom_info != NULL) && (atom_info->vis_ptr != NULL)) 
   {
      vis = (vis_data_struct *)atom_info->vis_ptr;
      atom_info->current_res = vis->params.selected_res;

      clear_atom_info_dialog(atom_info);

      if (atom_info->current_res > -1)
      {
         sprintf
           (
              text, 
              "%s %i",
              vis->mol_data.residues[atom_info->current_res].name,
              vis->mol_data.residues[atom_info->current_res].res_num
           );

         label = XmStringCreateLocalized(text);
         XtVaSetValues(atom_info->residueLabel, XmNlabelString, label, NULL);
         XmStringFree(label);

         sprintf(text, "%2.2f", vis->mol_data.residues[atom_info->current_res].total_charge/ELECTROSTATIC_CONVERSION_FACTOR);
         label = XmStringCreateLocalized(text);
         XtVaSetValues(atom_info->totalChargeLabel, XmNlabelString, label, NULL);
         XmStringFree(label);

         fill_atom_info_dialog(atom_info);
      }
      else
      {
         label = XmStringCreateLocalized("None");

         XtVaSetValues(atom_info->residueLabel, XmNlabelString, label, NULL);
         XtVaSetValues(atom_info->totalChargeLabel, XmNlabelString, label, NULL);

         XmStringFree(label);
      }
   }
}

/* called when close is clicked */
void atomInfoCloseCB(Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   atom_info_dialog_struct *atom_info = (atom_info_dialog_struct *)clientD;

   popdown_atom_info_dialog(atom_info);
}
