/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

#include "visualize.h"
#include "structures.h"

#include <Xm/MwmUtil.h>
#include <X11/Shell.h>
#include <Xm/Label.h>
#include <Xm/Scale.h>
#include <Xm/Frame.h>
#include <Xm/Form.h>
#include <Xm/PushB.h>
#include <math.h>

typedef struct
{
      Widget topLevel,
             highSlider,
             lowSlider;

      vis_data_struct *vis;

} color_set_struct;

/* callbacks */
static void ok_cancelCB(Widget w, XtPointer clientD, XtPointer callD);

/*************************************************************************
 * FUNCTION:  set_color_scale_dialog  -- dialog to set the color scale   *
 *                                                                       *
 * INPUTS:  w  -- the parent widget                                      *
 *          vis -- the vis data struct                                   *
 *                                                                       *
 * RETURNS: nothing                                                      *
 *                                                                       *
 *************************************************************************/
void set_color_scale_dialog (Widget w, vis_data_struct *vis)
{
   /* local variables */
   static color_set_struct c_set = {NULL, NULL, NULL, NULL};

   Widget mainForm,    /* subform of the toplevel shell  */
             frame,    /* a frame widget                 */
             child,    /* a child widget                 */
             form;     /* a form widget                  */

   XmString label;     /* to label various widgets       */

   float vals[4];

   c_set.vis=vis;

   if (vis->params.colorMapType == SURFACE_CM)
      memcpy(vals, vis->params.vp, sizeof(float)*4);
   else return;

  c_set.topLevel = XtVaCreatePopupShell
                (
                   "Value Selector",
                   topLevelShellWidgetClass,
                   XtParent(w),
                   XmNwidth,  250,
                   XmNheight, 130,
                   XmNmwmDecorations, MWM_DECOR_ALL|MWM_DECOR_ALL,
                   XmNmwmFunctions,   MWM_FUNC_ALL|MWM_FUNC_ALL,
                   XmNmwmInputMode,   MWM_INPUT_FULL_APPLICATION_MODAL,
                   NULL
                );

   mainForm = XtVaCreateManagedWidget
                (
                   "Main Color Select Form",
                   xmFormWidgetClass,
                   c_set.topLevel,
                   XmNtopAttachment, XmATTACH_FORM,
                   XmNleftAttachment, XmATTACH_FORM,
                   XmNrightAttachment, XmATTACH_FORM,
                   XmNbottomAttachment, XmATTACH_FORM,
                   NULL
                 );

   frame = XtVaCreateManagedWidget
             (
                "frame",
                xmFrameWidgetClass,
                mainForm,
                XmNtopAttachment, XmATTACH_FORM,
                XmNleftAttachment, XmATTACH_FORM,
                XmNrightAttachment, XmATTACH_FORM,
                NULL
             );

   if (vis->params.colorMapType == SURFACE_CM)
       label = XmStringCreate("Surface Color Values", XmFONTLIST_DEFAULT_TAG);
   else 
       label = XmStringCreate("Atom Color Values", XmFONTLIST_DEFAULT_TAG);

   child = XtVaCreateManagedWidget
             (
                "title",
                xmLabelWidgetClass,
                frame,
                XmNchildType, XmFRAME_TITLE_CHILD,
                XmNlabelString, label,
                NULL
              );
   XmStringFree(label);

   form = XtVaCreateManagedWidget
            (
               "form",
               xmFormWidgetClass,
               frame,
               NULL  /* all attachments default to form when only child */
            );

    c_set.lowSlider = XtVaCreateManagedWidget
                  (
                     "low value slide bar",
                      xmScaleWidgetClass,
                      form,
                      XmNtopAttachment,   XmATTACH_FORM,
                      XmNrightAttachment, XmATTACH_FORM,
                      XmNorientation,     XmHORIZONTAL,
                      XmNdecimalPoints,   2,
                      XmNmaximum, (int)((vals[MAX])*100),
                      XmNminimum, (int)((vals[MIN] - fabs(vals[MIN]))*100),
                      XmNvalue,   (int)(vals[MIN]*100),
                      XmNshowValue, True,
                      NULL
                  );

    label = XmStringCreate("Low Color Value:", XmFONTLIST_DEFAULT_TAG);
    child = XtVaCreateManagedWidget
              (
                 "label",
                 xmLabelWidgetClass,
                 form,
                 XmNlabelString,      label,
                 XmNtopAttachment,    XmATTACH_OPPOSITE_WIDGET,
                 XmNtopWidget,        c_set.lowSlider,
                 XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNbottomWidget,     c_set.lowSlider,
                 XmNrightAttachment,  XmATTACH_WIDGET,
                 XmNrightWidget,      c_set.lowSlider,
                 NULL
               );
    XmStringFree(label);

    c_set.highSlider = XtVaCreateManagedWidget
                   (
                      "high value slide bar",
                       xmScaleWidgetClass,
                       form,
                       XmNtopAttachment,   XmATTACH_WIDGET,
                       XmNtopWidget,       c_set.lowSlider,
                       XmNrightAttachment, XmATTACH_FORM,
                       XmNorientation,     XmHORIZONTAL,
                       XmNdecimalPoints,   2,
                       XmNmaximum, (int)((vals[MAX]+fabs(vals[MAX]))*100),
                       XmNminimum, (int)((vals[MIN])*100),
                       XmNvalue,   (int)(vals[MAX]*100),
                       XmNshowValue, True,
                       NULL
                   );

    label = XmStringCreate("High Color Value:", XmFONTLIST_DEFAULT_TAG);
    child = XtVaCreateManagedWidget
              (
                 "label",
                 xmLabelWidgetClass,
                 form,
                 XmNlabelString,      label,
                 XmNtopAttachment,    XmATTACH_OPPOSITE_WIDGET,
                 XmNtopWidget,        c_set.highSlider,
                 XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
                 XmNbottomWidget,     c_set.highSlider,
                 XmNrightAttachment,  XmATTACH_WIDGET,
                 XmNrightWidget,      c_set.highSlider,
                 NULL
               );
    XmStringFree(label);

   frame = XtVaCreateManagedWidget
             (
                "frame",
                xmFrameWidgetClass,
                mainForm,
                XmNtopAttachment,   XmATTACH_WIDGET,
                XmNtopWidget,       frame,
                XmNleftAttachment,  XmATTACH_FORM,
                XmNrightAttachment, XmATTACH_FORM,
                NULL
             );

   form = XtVaCreateManagedWidget
            (
               "form",
               xmFormWidgetClass,
               frame,
               NULL
            );

   label = XmStringCreate("Cancel", XmFONTLIST_DEFAULT_TAG);
   child = XtVaCreateManagedWidget
             (
                "cancelbutton",
                xmPushButtonWidgetClass,
                form,
                XmNlabelString, label,
                XmNleftAttachment, XmATTACH_FORM,
                XmNtopAttachment, XmATTACH_FORM,
                XmNbottomAttachment, XmATTACH_FORM,
                XmNheight, 30,
                XmNwidth, 75,
                XmNuserData, 0,
                NULL
             );
   XmStringFree(label);
   XtAddCallback(child, XmNactivateCallback, ok_cancelCB, &c_set);

   label = XmStringCreate("OK", XmFONTLIST_DEFAULT_TAG);
   child = XtVaCreateManagedWidget
             (
                "okbutton",
                xmPushButtonWidgetClass,
                form,
                XmNlabelString, label,
                XmNrightAttachment, XmATTACH_FORM,
                XmNtopAttachment, XmATTACH_FORM,
                XmNbottomAttachment, XmATTACH_FORM,
                XmNheight, 30,
                XmNwidth, 75,
                XmNuserData, 1,
                NULL
             );
   XmStringFree(label);
   XtAddCallback(child, XmNactivateCallback, ok_cancelCB, &c_set);

   XtPopup(c_set.topLevel, XtGrabNone);

}

/* called when ok or cancel are clicked */
void ok_cancelCB(Widget w, XtPointer clientD, XtPointer callD)
{
   /* local variables */
   color_set_struct *c_set = (color_set_struct *)clientD;
   vis_data_struct *vis = c_set->vis;
   int val;
   int high, low;
   float vals[3];

   XtVaGetValues(w, XmNuserData, &val, NULL);

   /* OK pressed if val == 1 */
   if (val)
   {
      XtVaGetValues(c_set->highSlider, XmNvalue, &high, NULL);
      XtVaGetValues(c_set->lowSlider, XmNvalue, &low, NULL);

      vals[MIN]    = ((float)low)/100.;
      vals[MAX]    = ((float)high)/100.;
      vals[EXTENT] = vals[MAX] - vals[MIN];
      vals[CENTER] = (vals[MAX] + vals[MIN])/2.;

      if (vis->params.colorMapType == SURFACE_CM)
         memcpy(vis->params.vp, vals, sizeof(float)*3);

      /* generate the colors for the vertices or atoms and redraw */
      generate_colors(vis);

      glXMakeCurrent
      (
         XtDisplay(vis->params.drawW),
         XtWindow(vis->params.drawW),
         vis->params.context_D
      );

      /* regenerate display lists */
      gen_main_mol_lists(vis, (char)1, (char)1, -1.);

      drawColrMap(vis);
      draw(vis, 1);
   }

   /* clean up the popup window */
   XtPopdown(c_set->topLevel);
   XtDestroyWidget(c_set->topLevel);
}
