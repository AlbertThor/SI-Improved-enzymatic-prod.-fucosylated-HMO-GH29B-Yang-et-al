/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

/****************************************************************************
 * This file contains code to compute surface charge for a given molecular  *
 * surface from either a phimap or through the analytical solution.  --jcg  *
 ****************************************************************************/
#include "structures.h"
#include <stdlib.h> /* for NULL */
#include <stdio.h>
#include "calculations.h"

/*****************************************************************************
 * FUNCTION: calculate_surface_charge_single_step -- calculates the surface  *
 * charge                                                                    *
 *                                                                           *
 * MODIFIES: the surf_charge field of the vertices will be filled with the   *
 *           surface charges, so vert are input and output.                  *
 ****************************************************************************/
void calc_charge_single_step(residue *residues, int nres, vertx *vert, int nvert, double A, double proj_len, double diel_int, double diel_ext, double sal, double ion_exc_rad, int phiType, int *i, int step_size)
{
        /* THIS IS THE STUB FOR GEM */
int eye = *i;
int bound = min(eye + step_size, nvert);

   for (; eye < bound; eye++)
   {
      vert[eye].surface_charge = 1;
   }

   *i = eye;
}


/*****************************************************************************
 * FUNCTION: calculate_surface_charge -- calculates the surface charge       *
 *                                                                           *
 * INPUTS: 
 *         vert -- the vertices making up the molecular surface              *
 *         nvert -- the number of vertices in the surface                    *
 *         grid  -- a float grid containing phi values IF calc is false      *
 *         gdim  -- the length of one edge of the grid IF calc is false      *
 *         spacing -- the grid spacing if calc is false                      *
 *         wrld_dim -- the real space dimensions of the world                *
 *         proj_len -- the length to project outward for this computation    *
 *                                                                           *
 * MODIFIES: the surf_charge field of the vertices will be filled with the   *
 *           surface charges, so vert are input and output.                  *
 ****************************************************************************/
int calculate_surface_charge(vertx *vert, int nvert, float *grid, int gdim,
                             float spacing, float wrld_dim[6], float proj_len)
{
/*local variables */
int i;
vertx p1, p2;
float pot1, pot2;


   /* obviously won't work without a surface */
   if ((vert == NULL)||(nvert <= 0))
     return 0;


   /* obviously won't work without a grid here */
   if ( (grid == NULL) || (gdim <= 0) ) return 0;

   /* loop through all the vertices determining surface charge */
   for (i = 0; i < nvert; i++)
   {
      p1.x = vert[i].x + vert[i].xNorm * proj_len;
      p1.y = vert[i].y + vert[i].yNorm * proj_len;
      p1.z = vert[i].z + vert[i].zNorm * proj_len;

      p2.x = p1.x + vert[i].xNorm * spacing;
      p2.y = p1.y + vert[i].yNorm * spacing;
      p2.z = p1.z + vert[i].zNorm * spacing;

      pot1 = sample_grid(p1.x, p1.y, p1.z, grid, gdim, gdim, gdim, wrld_dim);
      pot2 = sample_grid(p2.x, p2.y, p2.z, grid, gdim, gdim, gdim, wrld_dim);

      /* simple forward difference */
      vert[i].surface_charge = (pot2 - pot1) / spacing;
   }

   return 1;
}
