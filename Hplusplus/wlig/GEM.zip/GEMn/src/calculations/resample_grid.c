/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include "calculations.h"

/****************************************************************************
 * FUNCTION: resample_grid (populate a new grid from values in an old grid) *
 *                                                                          *
 * INPUTS:   inGrid (old grid to sample)                                    *
 *           inDim  (dimension of old grid <<cubic>>)                       *
 *           in_wrld_dims (world dimensions of old grid)                    *
 *           outDim (dimension of new grid <<cubic>>)                       *
 *           out_wrld_dims (dimensions of new grid <<cubic>>)               *
 *                                                                          *
 * CHANGES:  outGrid (by populating it with values sampled from inGrid)     *
 *                                                                          *
 * RETURNS:  nothing                                                        *
 *                                                                          *
 ****************************************************************************/
void resample_grid (float *inGrid, int inDim, float in_wrld_dims[6], float *outGrid, int outDim, float out_wrld_dims[6])
{
  /* local variables */
  /*******************/
  int i,   /* x loop counter for output grid dimensions */
      j,   /* y loop counter for output grid dimensions */
      k,   /* z loop counter for output grid dimensions */
      dimsq; /* outDim squared */

  float x, y, z, scale;

  scale = (out_wrld_dims[3] - out_wrld_dims[0])/((float)(outDim-1));

  dimsq = outDim*outDim;

  z = out_wrld_dims[2];
  for (i = 0; i < outDim; i++)
  {
      y = out_wrld_dims[1];
      for (j = 0; j < outDim; j++)
      {
          x = out_wrld_dims[0];
          for (k = 0; k < outDim; k++)
          {
             outGrid[i*dimsq + j*outDim + k] = sample_grid(x, y, z, inGrid, inDim, inDim, inDim, in_wrld_dims);

             x += scale;
          }
          y += scale;
      }
      z += scale;
  }
} /* end function resample_grid */
