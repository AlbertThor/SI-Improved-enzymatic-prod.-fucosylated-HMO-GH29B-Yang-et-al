/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include "calculations.h"


/* This function calls calculate_potential_single_step and 
 * calculate_charge_single_step all at one time. --jcg
 */
void calc_charge_potential_single_step(residue *residues, int nres, vertx *vert, int nvert, double A, double proj_len, double diel_int, double diel_ext, double sal, double ion_exc_rad, int phiType, int *i, int step_size)
{
static int dup;

     dup = *i;
     calc_potential_single_step(residues, nres, vert, nvert, A, proj_len, diel_int, diel_ext, sal, ion_exc_rad, phiType, i, step_size);

     calc_charge_single_step(residues, nres, vert, nvert, A, proj_len, diel_int, diel_ext, sal, ion_exc_rad, phiType, &dup, step_size); 
}
