/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include "calculations.h"
#include "defines.h"
#include <stdio.h>
#include <stdlib.h>

/****************************************************************************
 * FUNCTION: project_grd (projects grid values onto surface vertices)       *
 *                                                                          *
 * INPUTS: grid      (grid to sample)                                       *
 *         nvert     (number of vertices)                                   *
 *         xdim      (x size of cube)                                       *
 *         ydim      (y size of cube)                                       *
 *         zdim      (z size of cube)                                       *
 *         wrld_dim  (dimensions of the cube in world coords)               *
 *         rng       (range to project away from surf)                      *
 *         op        (operation to do to the verices)                       *
 *                                                                          *
 * CHANGES:  vert (assigns potential value)                                 *
 *                                                                          *
 * RETURNS: nothing                                                         *
 *                                                                          *
 ****************************************************************************/
void project_grd
(
   vertx *vert, 
   float *grid, 
   int nvert, 
   int xdim, 
   int ydim, 
   int zdim, 
   float wrld_dim[6], 
   float rng, 
   unsigned char op
)
{
   /* local variables */
   /*******************/
   int n;

   float x,y,z; /* the point to sample */
   float pot;
          
   for (n = 0; n < nvert; n++)
   {
      x = vert[n].x + (rng * vert[n].xNorm);
      y = vert[n].y + (rng * vert[n].yNorm);
      z = vert[n].z + (rng * vert[n].zNorm);

      pot = sample_grid(x, y, z, grid, xdim, ydim, zdim, wrld_dim);

      if (op == SET_VALUES)
         vert[n].potential = pot;
      else if (op == DIFFERENTIATE)
         vert[n].potential -= pot;

   }/* end for (n < nvert) */

}/* end function project_grd */
