/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include "structures.h" /* for MIN, MAX, EXTENT, CENTER */
#include <ctype.h>
#include <string.h>

/*
 * This function assigns a color to a value based on the range of values 
 * present.  Red is 1 from min to mid, blue is 1 from mid to max, and
 * green is 1 at mid, but slopes toward zero as we go toward the extrema.
 *  --jcg
 */

/*************************************************************************
 * FUNCTION: getColor                                                    *
 *                                                                       *
 * INPUTS:   val   (the value to sample in the hat function)             *
 *           range (the range of the hat function)                       *
 *                                                                       *
 * CHANGES:  r     (red component of the color)                          *
 *           g     (blue component of the color)                         *
 *           b     (green component of the color)                        *
 *                                                                       *
 * RETURNS:  nothing                                                     *
 *************************************************************************/
void getColor (float *r, float *g, float *b, float val, float range[4])
{
  /* initialize */
  *r=*b=*g=1.;

  /* normalize to avoid negative colors */
  /* its just temporary anyway, val is passed by value */
  if (val < range[MIN]) val = range[MIN];
  if (val > range[MAX]) val = range[MAX];

  if (val < range[CENTER])
  {
    *b = *g = (val-range[MIN])/(range[CENTER]-range[MIN]); /* linear upward slope */
    *r = 1;
  }
  if (val > range[CENTER])
  {
    *r = *g = 1 - ((val-range[CENTER])/(range[MAX]-range[CENTER])); /* linear downward slope */
    *b = 1;
  }

} /* end getColor function */

/*************************************************************************
 * FUNCTION: getAtomTypeColor - assign a color based on a name for type  *
 *                                                                       *
 * INPUTS:   val   (the value to sample in the hat function)             *
 *                                                                       *
 * CHANGES:  r     (red component of the color)                          *
 *           g     (blue component of the color)                         *
 *           b     (green component of the color)                        *
 *                                                                       *
 * RETURNS:  nothing                                                     *
 *************************************************************************/
void getAtomTypeColor (float *r, float *g, float *b, char *name)
{
  /* local variables */
  unsigned int i,       /* loop counter */
               length,  /* length of the string */
               fc;      /* first character index */


  /* initialize default purple */
  *r=*b=1.;
  *g = 0.;

  fc = length = strlen(name);
  /* find first alphabetical letter (a-z)(A-Z) */
  for (i = 0; i< length; i++)
  {
     if (isalpha(name[i]))
     {
        fc = i;
        break;
     }
  }

/*
 * rough approximations of standard colors for atom types are:
 * O     - red    (255, 0, 0)
 * P     - yellow (255, 255, 0)
 * N     - blue   (0, 0, 255)
 * H     - white  (255, 255, 255)
 * C     - grey   (155, 155, 155)
 * S     - yellow (255, 200, 0)
 * FE    - orange (255, 145, 0)
 * other - purple (255, 0, 255)
 * <<as an unsigned byte... clamped to floats below >>
 *  --jcg
 */

  /* if we break the loop because we found the first character... */
  if (fc < length)
  {
     switch (name[fc])
     {
         case 'O':
           *r = 1.;
           *b = *g = 0.;
           break;
         case 'P':
           *r = *g = 1.;
           *b = 0.;
           break;
         case 'N':
           *r = *g = 0.;
           *b = 1.;
           break;
         case 'H':
           *r = *g = *b = 1.;
           break;
         case 'C':
           *r = *g = *b = .5;
           break;
         case 'S':
           *r = 1.;
           *g = .8;
           *b = 0.;
           break;
         case 'F':
           if (fc < length - 2)
           {
              if (name[fc+1] == 'E')
              {
                 *r = 1.;
                 *g = .45;
                 *b = 0.;
              }
           }
           break;
         default:
           break;
     }
  }

} /* end getColor function */
