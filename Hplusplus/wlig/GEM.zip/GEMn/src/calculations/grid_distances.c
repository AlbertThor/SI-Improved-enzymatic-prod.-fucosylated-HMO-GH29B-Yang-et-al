/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include <stdio.h>
#include <float.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "structures.h"     /*for vertx struct definition       */
#include "calculations.h"   /*for distance calculation function */

/*
 * This function will determine the minimum distance between a given grid point
 * and a set of surface points.  These values will be stored in a float array
 * that represents a minimum distance value
 *
 * The initial real world coordinates start at the minimum x, y, and z values.
 * Subsequent values are determined by adding 1/xscale, 1/yscale, or 1/zscale
 * to the real world coordinate while advancing through the grid (recursive
 * relation)
 *
 * These values are used to then calculate the distance to each vertex in the
 * set of surface vertices.  The minimum distance is calculated by comparing
 * the current distance value with the minimum stored so far.  After iterating
 * through all surface vertex points, the minimum distance is stored in the
 * current grid point.  This is repeated for all points in the grid.
 */

/*****************************************************************************
 *  FUNCTION: gridDistances (calculates distances in a regular grid)         *
 *                                                                           *
 *  INPUTS: gridxDim (x dimension of grid <int>)                             *
 *          gridyDim (y dimension of grid <int>)                             *
 *          gridzDim (z dimension of grid <int>)                             *
 *          gridWorldDims  (world dimensions of grid)                        *
 *          molVerts       (input points to which we find min dist)          *
 *          numMolVerts    (size of the input vertex set)                    *
 *                                                                           *
 *  CHANGES: grd (gives distances when done, allocates memory)               *
 *           surfaceIdx (nearest surface point, allocates memory)            *
 *                                                                           *
 *****************************************************************************/

void gridDistances (float** grd,
                    int** surfaceIdx,
                    const int gridxDim, 
                    const int gridyDim, 
                    const int gridzDim,
                    float gridWorldDims[6],
                    const vertx* molVerts,
                    const int numMolVerts)
{

  float *currgptr;
  int   *currvptr;

  if ((molVerts == NULL) || (numMolVerts == 0))
  {
     *grd = NULL;
     *surfaceIdx = NULL;
     return;
  }

  *grd = (float*)malloc(gridxDim * 
                               gridyDim * 
                               gridzDim * 
                               sizeof(float)   );


  //This will serve as a grid of surface vertex indices that correspond
  //to minimum distance values
  *surfaceIdx = (int*)malloc(gridxDim *
                             gridyDim *
                             gridzDim *
                             sizeof(int)       );


  float gridxWorldMin = gridWorldDims[0];
  float gridyWorldMin = gridWorldDims[1];
  float gridzWorldMin = gridWorldDims[2];

  float gridxExtent = gridWorldDims[3] - gridxWorldMin;
  float gridyExtent = gridWorldDims[4] - gridyWorldMin;
  float gridzExtent = gridWorldDims[5] - gridzWorldMin;

  float xScale = gridxExtent / (float)(gridxDim-1);
  float yScale = gridyExtent / (float)(gridyDim-1);
  float zScale = gridzExtent / (float)(gridzDim-1);

  int ctr;

  //Populate the grid

  //loop counters
  int i, j, k;

  //calculated world coordinate values
  float gridxWorld = gridxWorldMin;
  float gridyWorld = gridyWorldMin;
  float gridzWorld = gridzWorldMin;

  //values used to store minimum index and distance
  float minDistanceSq = FLT_MAX;
  float minDistance;
  float currDistanceSq;
  int minSurfaceIdx = INT_MAX;          //vertx index corresponding to min 
                                        //distance surface point
  float dotProd = 0.f;

  float surfaceToGridVect[3] = {0.f, 0.f, 0.f};

  currgptr = *grd;
  currvptr = *surfaceIdx;

  if ((!currgptr) || (!currvptr))
  {
     if (currgptr) free(currgptr);

     *grd = *surfaceIdx = NULL;

     return;
  }

  gridzWorld = gridzWorldMin;
  for (i = 0; i < gridzDim; ++i)
  {
    gridyWorld = gridyWorldMin; 
    for (j = 0; j < gridyDim; ++j)
    {
      gridxWorld = gridxWorldMin;
      for (k = 0; k < gridxDim; ++k)
      {
        //now loop through gridDistanceList array and fill in the distance
        //values using the grid point just calculated
        for (ctr = 0; ctr < numMolVerts; ctr++)
        {
          currDistanceSq = dist2(gridxWorld, 
                                 gridyWorld, 
                                 gridzWorld,
                                 (molVerts[ctr]).x, 
                                 (molVerts[ctr]).y, 
                                 (molVerts[ctr]).z);

          if (currDistanceSq < minDistanceSq)
          {
            minDistanceSq = currDistanceSq;
            minSurfaceIdx = ctr;
          }
        }

        //Compute actual min distance
        minDistance = sqrt(minDistanceSq);
          
        //Write the minimum distance value for this grid point to the
        //grid array
        *currgptr = minDistance;

        //Write index of surface vertx array that corresponds to the minimum 
        //distance surface point
        *currvptr = minSurfaceIdx; 

        //Determine the vector from the surface point to the nearest grid point
        surfaceToGridVect[0] = gridxWorld - (molVerts[minSurfaceIdx]).x;
        surfaceToGridVect[1] = gridyWorld - (molVerts[minSurfaceIdx]).y;
        surfaceToGridVect[2] = gridzWorld - (molVerts[minSurfaceIdx]).z;

        //Compute the dot product of this vector and the normal vector
        dotProd = surfaceToGridVect[0] * (molVerts[minSurfaceIdx]).xNorm +
                  surfaceToGridVect[1] * (molVerts[minSurfaceIdx]).yNorm +
                  surfaceToGridVect[2] * (molVerts[minSurfaceIdx]).zNorm;

        //If the dot product is negative, then the point lies inside the molecule
        if (dotProd < 0.f)
           *currgptr *= -1.;


        //Reset value of minDistanceSq and minSurfaceIdx to FLT_MAX/INT_MAX for next 
        //iteration
        minDistanceSq = FLT_MAX;
        minSurfaceIdx = INT_MAX;
        dotProd = 0.f;

        gridxWorld += xScale;
        currgptr++;
        currvptr++;
      }
      gridyWorld += yScale;
    }
    gridzWorld += zScale;
  }
}
