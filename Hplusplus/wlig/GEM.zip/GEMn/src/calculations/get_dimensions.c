/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include "structures.h"
#include "calculations.h"
#include <stdlib.h> /* for NULL of all things */


/******************************************************************************
 * FUNCTION: get_dimensions (gets the minimal bounding box for a set of verts)*
 *                                                                            *
 * INPUTS: vert  (vertices)                                                   *
 *         nvert (number of vertices)                                         *
 *                                                                            *
 * CHANGES: x     (x bounding box)                                            *
 *          y     (y bounding box)                                            *
 *          z     (z bounding box)                                            *
 *                                                                            *
 * RETURNS: 1 on success, 0 on failure                                        *
 ******************************************************************************/
int get_dimensions(vertx *vert, int nvert, float x[4], float y[4], float z[4])
{
   /* local variables */
   int i;
   float cenx, ceny, cenz,
         max_ext, min_ext, ext;

   if (vert == NULL)
   {
      return 0;
   }

   /* else */

   /* initialize to point[0] */
   cenx = x[MIN] = x[MAX] = vert[0].x;
   ceny = y[MIN] = y[MAX] = vert[0].y;
   cenz = z[MIN] = z[MAX] = vert[0].z;


   for (i = 0; i < nvert; i++)
   {
       /* geometric center */
       cenx += vert[i].x;
       ceny += vert[i].y;
       cenz += vert[i].z;

       /* minima */
       if (vert[i].x < x[MIN])
          x[MIN] = vert[i].x;
       if (vert[i].y < y[MIN])
          y[MIN] = vert[i].y;
       if (vert[i].z < z[MIN])
          z[MIN] = vert[i].z;

       /* maxima */
       if (vert[i].x > x[MAX])
          x[MAX] = vert[i].x;
       if (vert[i].y > y[MAX])
          y[MAX] = vert[i].y;
       if (vert[i].z > z[MAX])
          z[MAX] = vert[i].z;

   } /* end for (i < nvert) */

   cenx /= (float)nvert;
   ceny /= (float)nvert;
   cenz /= (float)nvert;

   max_ext = x[MAX] - cenx;
   min_ext = cenx - x[MIN];
   ext = max(max_ext, min_ext);

   x[MAX] = cenx + ext;
   x[MIN] = cenx - ext;
   x[EXTENT] = ext + ext;

   max_ext = y[MAX] - ceny;
   min_ext = ceny - y[MIN];
   ext = max(max_ext, min_ext);

   y[MAX] = ceny + ext;
   y[MIN] = ceny - ext;
   y[EXTENT] = ext + ext;
   
   max_ext = z[MAX] - cenx;
   min_ext = cenx - z[MIN];
   ext = max(max_ext, min_ext);

   z[MAX] = cenz + ext;
   z[MIN] = cenz - ext;
   z[EXTENT] = ext + ext;

   /* set centers */
   x[CENTER] = cenx;
   y[CENTER] = ceny;
   z[CENTER] = cenz;

   return 1;
} /* end function get_dimensions */
