/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include "calculations.h"
#include "defines.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

/*
 * There is a figure in this directory called "surfacepot.fig"
 * demonstrating the computation of these potentials and the 
 * relative distances, etc. --jcg
 */

 /* If we intend to continue work on this we have to __HAVE TO HAVE TO__
  * unify the positional calculations used in both methods, by writing
  * a subfunction that takes position (x, y, z) and vert and res and 
  * returns the potential at that point (will also be useful for 
  * arbitrary sample point distributions) --jcg
  */

/***************************************************************************
 * FUNCTION: calculate_potential_contribution -- calculates the potential  *
 *                                             contribution of one atom    *
 *                                             to the total potential of a *
 *                                             given point in space. Note  *
 *                                             that while this function is *
 *                                             slower (slightly) it is     *
 *                                             really easy to use.         *
 *                                                                         *
 * INPUTS: r            -- distance from point to charge                   *
 *         rprime       -- distance from point to surface along r          *
 *         d            -- distance from point to center                   *
 *         dprime       -- distance from point to surface along d          *
 *         A            -- electrostatic radius of the molecule            *
 *         r0           -- rnaut in the formulations                       *
 *         sal          -- salt concentration                              *
 *         charge       -- charge under consideration                      *
 *         diel_ext     -- external dielectric environment                 *
 *         diel_int     -- internal dielectric environment                 *
 *         defs         -- definitions to speed things up                  *
 *                                                                         *
 * RETURNS: the potential contribution                                     *
 *                                                                         *
 ***************************************************************************/
inline double calculate_potential_contribution (double d, double dprime, double r,
                                                double rprime, double r0, double A,
                                                double sal, double charge,
                                                double diel_int, double diel_ext,
                                                analytical_definitions_struct *defs)
{
   /* local variables */
   /*******************/
   double sum1 = 0,
          sum2 = 0,
          sum3 = 0,
          sum4 = 0,
          salt = 0,
          coulomb = 0,
          to_return = 0,
          one_over_one_plus_kappa_rprime;

   /* <><> add salt to the inside <><> */

   if (defs->phiType != TOTAL_POTENTIAL) 
   {
      coulomb = charge/(d * diel_int);
   }

   if (defs->phiType & REACTION_POTENTIAL)
   {
      if (defs->region == 3)  /* Dist to surf > ion_excl_rad */
      {
   
         sum1 = (charge 
                    * (exp (-defs->kappa * (d - dprime))) / d)
                       * (defs->one_plus_alpha / (1. + defs->kappa * dprime));
   
         sum2 = charge 
                  * (defs->alpha_by_one_minus_beta * exp (-defs->kappa * (r-rprime)) / (r * (1. + defs->kappa*rprime)));
   
         to_return = defs->inverse_one_plus_ab_by_diel_ext * (sum1 - sum2);
      }
      else if (defs->region == 2) /* 0 < dist_to_surf <= ion_excl_rad */
      {
   
         one_over_one_plus_kappa_rprime = 1./(1. + (defs->kappa * rprime));
   
         /* electrostatic terms for region 2 */
         sum1 = defs->one_plus_alpha * charge / d;
         sum2 = defs->alpha_by_one_minus_beta * charge/r;
   
         /* salt terms for region 2 */
         sum3 = charge * (defs->alpha_by_one_minus_beta / rprime) * (1. - one_over_one_plus_kappa_rprime);
         sum4 = defs->one_plus_alpha * charge
                  * ( 1.0 / (dprime + defs->kappa * dprime * dprime) - (1. / dprime));
   
         to_return = defs->inverse_one_plus_ab_by_diel_ext * (sum1 - sum2 + sum3 + sum4);
      }
      else /* region = 1 */
      {

         one_over_one_plus_kappa_rprime = 1./(1. + (defs->kappa * rprime));
   
         sum1 =  1. / (d * diel_int);
   
         sum2 =  (1./diel_int - 1./diel_ext) / (defs->one_plus_alpha_beta * A);
   
         sum3 = defs->Asq / sqrt(defs->Asq_minus_rnautsq*defs->Asq_minus_rsq + defs->Asq_by_dsq);

         salt = defs->inverse_one_plus_ab_by_diel_ext
                  * (defs->one_plus_alpha/dprime*(1./(1.+defs->kappa*dprime)-1.)  
                     +defs->alpha_by_one_minus_beta/rprime*(1.-one_over_one_plus_kappa_rprime));
   
         to_return = (sum1 - sum2*sum3 + salt) * charge;
      }

      if (defs->phiType == REACTION_POTENTIAL)
      {
         to_return -= coulomb;
      }
   }
   else
   {
      to_return = coulomb;
   }

   if (to_return != to_return)
   {
     printf("Found a NaN contribution %f\n", to_return);
     printf("region = %i\n", defs->region);
     printf("sum1, sum2, sum3, sum4 %f %f %f %f\n", sum1, sum2, sum3, sum4);

     if (defs->region == 1)
     {
        printf("sum under root = %f\n", defs->Asq_minus_rnautsq*defs->Asq_minus_rsq + defs->Asq_by_dsq);
        printf("A-r by A-r0 = %f\n", defs->Asq_minus_rnautsq*defs->Asq_minus_rsq);
        printf("Asq_by_dsq = %f\n", defs->Asq_by_dsq);
        printf("A = %f\n", A);
        printf("r = %f\n", r);
        printf("r0 = %f\n", r0);
        printf("d = %f\n", d);
     }

     fflush(stdout);

   }

   return to_return;
}

/* Calculates potential for surface out of a molecule -- this is the free
 * space solution. --JCG */
void calc_potential_single_step(residue *residues, int nres, vertx *vert, int nvert, double A, double proj_len, double diel_int, double diel_ext, double sal, double ion_exc_rad, int phiType, int *i, int step_size)
{
   /* local variables */
   /*******************/
   int eye, j, k, m, bound, natoms;
   int use_charge_approx;   /* YES = use charge approx */
   double r,
          r0,
          rprime,
          d, d2,            /* d=dist, d2=dist squared */
          dprime,
          vert_x, vert_y, vert_z,
          vert_xprime, vert_yprime, vert_zprime;

   analytical_definitions_struct defs;

   eye = *i;

   r = A + proj_len;
   rprime = A + ion_exc_rad;

   defs.Asq   = A*A;
   defs.Asq_minus_rsq = defs.Asq - (r*r);

   defs.kappa = 0.316 * sqrt(sal);
   defs.beta = diel_int/diel_ext;
   defs.alpha_by_one_minus_beta = ALPHA_OF*(1. - defs.beta);
   defs.alpha_beta = ALPHA_OF * defs.beta;
   defs.one_plus_alpha_beta = 1.0 + defs.alpha_beta;
   defs.one_plus_alpha = 1.0 + ALPHA_OF;
   defs.inverse_one_plus_ab_by_diel_ext = 1.0/(defs.one_plus_alpha_beta*diel_ext);
   defs.phiType = phiType;

   if (r > rprime)
   {
      defs.region = 3;
   }
   else if (r > A)
   {
      defs.region = 2;
   }
   else
   {
      defs.region = 1;
   }

   bound = eye + step_size;

   if (nvert < bound) bound = nvert;

   for (; eye < bound; eye++)
   {

       /* offset point for calculation of d */
       vert_x = vert[eye].x + proj_len * vert[eye].xNorm;
       vert_y = vert[eye].y + proj_len * vert[eye].yNorm;
       vert_z = vert[eye].z + proj_len * vert[eye].zNorm;

       /* offset point for calculation of d' only */
       vert_xprime = vert[eye].x + ion_exc_rad * vert[eye].xNorm;
       vert_yprime = vert[eye].y + ion_exc_rad * vert[eye].yNorm;
       vert_zprime = vert[eye].z + ion_exc_rad * vert[eye].zNorm;

       vert[eye].potential = 0;

       for (k = 0; k < nres; k++)
       {

          /* check if charge approx should be used */
          if (CHARGE_APPROX)
          {
             d2 = dist2
                  (
                        vert_x, vert_y, vert_z,
                        residues[k].x,
                        residues[k].y,
                        residues[k].z
                  );

             use_charge_approx = (d2 > CHARGE_APPROX_DIST2);
          }

         /* charge approximation */
          if (use_charge_approx)
          {
             for (m = 0; m < CHARGE_APPROX; m++)
             {
                if ((residues[k].qc[m] > .01) 
                   || (residues[k].qc[m] < -.01))   /* charged */
                {
                   d = dist
                      (
                        vert_x, vert_y, vert_z,
                        residues[k].xc[m],
                        residues[k].yc[m],
                        residues[k].zc[m]
                      );

                   /* distance from point to charge */
                   dprime = dist
                      (
                         vert_xprime, vert_yprime, vert_zprime,
                         residues[k].xc[m],
                         residues[k].yc[m],
                         residues[k].zc[m]
                      );   

                   /* need to estimate r0, dist from atom to surface */
                   /* if we intend to support negative projection lengths <><> */
                   r0 = A/2.;  /* might be tricky ... hrmmm */

                   defs.Asq_minus_rnautsq = defs.Asq - r0*r0;
                   defs.Asq_by_dsq = A*A * d*d;

                   vert[eye].potential +=
                      calculate_potential_contribution 
                            (
                               d, dprime, r, rprime,
                               r0, A, sal,
                               residues[k].qc[m],
                               diel_int, diel_ext, &defs
                            );
                }   /* end charged */
             }      /* end m  CHARGE_APPROX loop*/
          }      /* end charge approx */
          else   /* do not use charge approx */
          {
             natoms = residues[k].natoms;

             for (j = 0; j < natoms; j++)
             {
                 /* distance from point to charge */
                 d = dist
                       (
                           vert_x, vert_y, vert_z,
                           residues[k].atoms[j].x,
                           residues[k].atoms[j].y,
                           residues[k].atoms[j].z
                       );  

                 /* distance from point to charge */
                 dprime = dist
                       (
                           vert_xprime, vert_yprime, vert_zprime,
                           residues[k].atoms[j].x,
                           residues[k].atoms[j].y,
                           residues[k].atoms[j].z
                       );  

                 /* need to estimate r0, dist from atom to surface */
                 /* if we intend to support negative projection lengths <><> */
                 r0 = A/2.;  /* might be tricky ... hrmmm */

                 defs.Asq_minus_rnautsq = defs.Asq - r0*r0;

                 defs.Asq_by_dsq = A*A * d*d;

                  vert[eye].potential +=
                       calculate_potential_contribution 
                            (
                               d, dprime, r, rprime,
                               r0, A, sal,
                               residues[k].atoms[j].charge,
                               diel_int, diel_ext, &defs
                            );
            } /* end j atoms */
         } /* end do not use charge approx */
      } /* end k residues */
   } /* end eye vertices */

   *i = eye;
}

/* calculates potential for the grid positions in the given grid structure,
 * using approximations of the ALPB solution --jcg
 * this is the grid writing method
 */
void calc_potential_grid (residue *residues, int nres, vertx *verts, int nverts, int *nearest_verts, float *grid, int xdim, int ydim, int zdim, float world[6], double A, double diel_int, double diel_ext, double sal, double ion_exc_rad, int phiType)
{
   /* local variables */
   /*******************/
   float *gptr;
   float *sdist, *distances;
   int   *vptr;
   int i, j, k, l, m,
       gx, gy, gz,
       xydim;
       /* i j k step through grid, l,m step through residues/atoms */

   vertx  grid_loc,
          surf_loc;

   double r,
          r0 = 0, /* <><><><> need to estimate this <><><><> */
          rprime,
          d, d2,   /* d=dist, d2=dist squared */
          dprime,
          xscale, yscale, zscale;

   analytical_definitions_struct defs;

   int use_charge_approx;   /* YES = use charge approx */

   /* sanity checks */
   if ((!nearest_verts) || (!grid))
      return;

   xydim = xdim*ydim;

   xscale=(world[3] - world[0])/(float)(xdim-1);
   yscale=(world[4] - world[1])/(float)(ydim-1);
   zscale=(world[5] - world[2])/(float)(zdim-1);

   rprime =  A + ion_exc_rad;
   if (rprime < xscale) rprime = xscale;

   grid_loc.z = world[2];

   gptr = grid;

   sdist = distances = (float *)calloc(xdim*ydim*zdim, sizeof(float));

   if (!distances)
   {
      printf("not enough space to hold the calculated results\n");
      return;
   }

   defs.Asq   = A*A;

   defs.kappa = 0.316 * sqrt(sal);
   defs.beta = diel_int/diel_ext;
   defs.alpha_by_one_minus_beta = ALPHA_OF*(1. - defs.beta);
   defs.alpha_beta = ALPHA_OF * defs.beta;
   defs.one_plus_alpha_beta = 1.0 + defs.alpha_beta;
   defs.one_plus_alpha = 1.0 + ALPHA_OF;
   defs.inverse_one_plus_ab_by_diel_ext = 1.0/(defs.one_plus_alpha_beta*diel_ext);
   defs.phiType = phiType;

   for (i = xdim*ydim*zdim; i > 0; i --)
   {
       *sdist = *gptr;

       sdist++;
       gptr++;
   }

   sdist = distances;
   gptr = grid;

   vptr = nearest_verts;
   for (i=0; i < zdim; i++)
   {

       grid_loc.y = world[1];
       for (j = 0; j < ydim; j++)
       {

          grid_loc.x = world[0];
          for (k = 0; k < xdim; k++)
          {
              /* it is dubious that anything could go wrong here, but there is
                 no sense in not being cautious --jcg */
              if ((*vptr > -1)
                  && (*vptr < nverts))
              {

                 /* set the surface location to the surface vertex + ion_excl rad in normal
                  * direction --jcg
                  */
                 surf_loc = verts[*vptr];
                 surf_loc.x += ion_exc_rad * surf_loc.xNorm;
                 surf_loc.y += ion_exc_rad * surf_loc.yNorm;
                 surf_loc.z += ion_exc_rad * surf_loc.zNorm;
              }
              else
              {
                 fprintf(stderr, "Error in nearest vertex index, out of bounds\n");
                 continue;
              }

              /* distance from point to center, as distance from point to surf + distance from surf
               * to center */
              r = A + *gptr;

              if (r < xscale)      r = xscale;

              if (r > rprime)
              {
                 defs.region = 3;
              }
              else if (r > A)
              {
                 defs.region = 2;
              }
              else
              {
                 defs.region = 1;
              }

              defs.Asq_minus_rsq = defs.Asq - r*r;

              *gptr = 0.;
              for (l = 0; l < nres; l++)
              {
/*           check if charge approx should be used */
                  use_charge_approx = NO;
                  if (CHARGE_APPROX)
                  {
                     d2 = dist2
                        (
                           grid_loc.x, grid_loc.y, grid_loc.z,
                           residues[l].x,
                           residues[l].y,
                           residues[l].z
                        );
                     if (d2 > CHARGE_APPROX_DIST2)
                     {
                        use_charge_approx = YES;
                     }
                  }
/*                charge approximation */
                  if (use_charge_approx)
                  {
                     for (m = 0; m < CHARGE_APPROX; m++)
                     { 
                        if ((residues[l].qc[m] > .01) 
                           || (residues[l].qc[m] < -.01)) /* charged */
                        {
                           d = dist
                              (
                                grid_loc.x, grid_loc.y, grid_loc.z,
                                residues[l].xc[m],
                                residues[l].yc[m],
                                residues[l].zc[m]
                              );
                     
                           if (d < xscale)      d = xscale;
          
                           /* distance from surface + ion exclusion rad to charge */
                           dprime = dist
                               (
                                  surf_loc.x, surf_loc.y, surf_loc.z,
                                  residues[l].xc[m],
                                  residues[l].yc[m],
                                  residues[l].zc[m]
                               );   

                           if (dprime < xscale) dprime = xscale;

                           defs.Asq_by_dsq = A*A * d*d;
                     
                           gx = (residues[l].xc[m] - world[0])/xscale;
                           gy = (residues[l].yc[m] - world[1])/yscale;
                           gz = (residues[l].zc[m] - world[2])/zscale;

                           r0 = distances[gz*xdim*ydim + gy*xdim + gx] + A;

                           if (r0 < xscale)     r0 = xscale;

                           if (r0 > A-residues[l].rad) r0 = A-residues[l].rad;

                           defs.Asq_minus_rnautsq = defs.Asq - r0*r0;

                           *gptr += calculate_potential_contribution 
                               (
                                  d, dprime, r, rprime,
                                  r0, A, sal,
                                  residues[l].qc[m],
                                  diel_int, diel_ext, &defs
                               );
                        }   /* end charged */
                     }      /* end m CHARGE_APPROX loop */
                  }     /* end charge approx */
                  else  /* do not use charge approx */
                  {

                     for (m = 0; m < residues[l].natoms; m++)
                     {
                         d = dist
                               (
                                  grid_loc.x, grid_loc.y, grid_loc.z,
                                  residues[l].atoms[m].x,
                                  residues[l].atoms[m].y,
                                  residues[l].atoms[m].z
                                 ); 

                         if (d < xscale)      d = xscale;
          
                         /* distance from surface + ion exclusion rad to charge */
                         dprime = dist
                                  (
                                     surf_loc.x, surf_loc.y, surf_loc.z,
                                     residues[l].atoms[m].x,
                                     residues[l].atoms[m].y,
                                     residues[l].atoms[m].z
                                  );   

                         if (dprime < xscale) dprime = xscale;

                         defs.Asq_by_dsq = A*A * d*d;
                     
                         gx = (residues[l].atoms[m].x - world[0])/xscale;
                         gy = (residues[l].atoms[m].y - world[1])/yscale;
                         gz = (residues[l].atoms[m].z - world[2])/zscale;

                         r0 = distances[gz*xdim*ydim + gy*xdim + gx] + A;

                         if (r0 < xscale)     r0 = xscale;

                         if (r0 > A-residues[l].atoms[m].radius) r0 = A-residues[l].atoms[m].radius;

                         defs.Asq_minus_rnautsq = defs.Asq - r0*r0;

/* CUTOFF replaced by CHARGE_APPROX exclude if outside cutoff distance *
 * if (!CUTOFF || (d < CUTOFF_DIST))                                   *
 * {                                                                   */
                            *gptr += calculate_potential_contribution 
                                   (
                                      d, dprime, r, rprime,
                                      r0, A, sal,
                                      residues[l].atoms[m].charge,
                                      diel_int, diel_ext, &defs
                                   );
/* } */
                     } /* end step through atoms */

                 } /* end else */

              } /* end step through residues */

              grid_loc.x += xscale;

              gptr++;
              sdist++;
              vptr++;
          }

          grid_loc.y += yscale;
      }

      grid_loc.z += zscale;
   }

   free (distances);
}
