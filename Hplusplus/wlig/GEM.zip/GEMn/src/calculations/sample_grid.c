/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include "calculations.h"

/****************************************************************************
 * FUNCTION: sample_grid  --"Official" grid sampling routine                *
 *                                                                          *
 * Inputs: x, y, z            - position to sample                          *
 *         grid               - the grid to sample                          *
 *         xdim, ydim, zdim   - dimensions of the grid                      *
 *         wrld_dim           - xmin, ymin, zmin, xmax, ymax, zmax          *
 *                              spacial coordinates for grid                *
 *                                                                          *
 * Returns: potential (grid value) at position x, y, z                      *
 *                                                                          *
 * Side Effects: None                                                       *
 *                                                                          *
 ****************************************************************************/
inline float sample_grid
(
   float x, 
   float y, 
   float z, 
   float *grid, 
   int xdim, 
   int ydim, 
   int zdim, 
   float wrld_dim[6]
)
{
/* local variables */
int i, j, k; /* grid indexes */
float to_return = 0.;
float x_extent, y_extent, z_extent, /* world defining values */
      x_scale,  y_scale,  z_scale;

   x_extent = wrld_dim[3] - wrld_dim[0];
   y_extent = wrld_dim[4] - wrld_dim[1];
   z_extent = wrld_dim[5] - wrld_dim[2];

   x_scale = ((float)(xdim-1))/x_extent;
   y_scale = ((float)(ydim-1))/y_extent;
   z_scale = ((float)(zdim-1))/z_extent;

   /* round instead of truncating */
   k = (x - wrld_dim[0]) * x_scale + .5;
   j = (y - wrld_dim[1]) * y_scale + .5;
   i = (z - wrld_dim[2]) * z_scale + .5;

   if ((i >= 0)&&(j >= 0)&&(k >= 0)&&(i < zdim)&&(j < ydim)&&(k < xdim))
      to_return = grid[i*xdim*ydim + j*xdim + k];

   return to_return;
}
