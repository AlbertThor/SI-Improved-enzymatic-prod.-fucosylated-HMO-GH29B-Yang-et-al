/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tellUser.h"
#include "structures.h"
#include "visualize.h"
#include "vis_defines.h"


/**************************************************************************
 * FUNCTION: TGA_header  --writes a header for an uncompressed TGA image  *
 *                                                                        *
 * INPUTS:  fp   --the file pointer (assumed to be at start)              *
 *          width -- the width of the image                               *
 *          height -- the height of the image                             *
 *                                                                        *
 * OUTPUTS: none                                                          *
 *                                                                        *
 * RETURNS: nothing                                                       *
 *                                                                        *
 **************************************************************************/
void TGA_header (FILE *fp, int width, int height)
{
   unsigned char TGAheader[12]={0,0,2,0,0,0,0,0,0,0,0,0};
   unsigned char header[6] = {width%256,width/256,height%256,height/256,32,0};

   fwrite(TGAheader, sizeof(unsigned char), 12, fp);
   fwrite(header, sizeof(unsigned char),     6, fp);
}

/**************************************************************************
 * FUNCTION: TGA_bytes  --writes some bytes to an uncompressed TGA image  *
 *                                                                        *
 * INPUTS:  fp   --the file pointer                                       *
 *          width -- the width of the image                               *
 *          height -- the height of the image                             *
 *          pixels -- the pixels to write to the file                     *
 *                                                                        *
 * OUTPUTS: none                                                          *
 *                                                                        *
 * RETURNS: nothing                                                       *
 *                                                                        *
 **************************************************************************/
void TGA_bytes (FILE *fp, int width, int height, unsigned char *pixels)
{
   /* local variables */
   int max_RGB_to_BGR = (width * height * 4)-5;
   unsigned char buf;
   int x;

   for (x = 0; x < max_RGB_to_BGR; x++) 
   {
      buf = pixels[x];
      pixels[x] = pixels[x+2];
      pixels[x+2] = buf;
      x++; 
   }

   fwrite(pixels, sizeof(unsigned char), width*height*4, fp);
}

/**************************************************************************
 * FUNCTION: SaveScreenShot  --writes a screen capture to a TGA image     *
 *                             screen capture being the key words here    *
 *                                                                        *
 * INPUTS:  vp     -- the vis_data_struct pointer                         *
 *          width  -- the width of the image                              *
 *          height -- the height of the image                             *
 *          fname  -- the name of the file to write                       *
 *                                                                        *
 * OUTPUTS: none                                                          *
 *                                                                        *
 * RETURNS: nothing                                                       *
 *                                                                        *
 **************************************************************************/
void SaveScreenShot(void *vp, char *fname, int width, int height)
{
   /* local variables */ 
   vis_data_struct *vis = (vis_data_struct *)vp;
   FILE *shot;
   int h2 = height + VIS_COLORBAR_HEIGHT;
   unsigned char *pixels;

   
   if((shot=fopen(fname, "wb"))==NULL) 
   {
      tellUser("Error", "Error opening tga file to write\n");
      return;
   }

   /* write the header */
   /********************/
   TGA_header(shot, width, h2);

   /* write the colorbar */
   /**********************/
   pixels = (unsigned char *)calloc(width*height*4, sizeof(char));

   glXMakeCurrent(XtDisplay(vis->params.colrW), XtWindow(vis->params.colrW), vis->params.context_S);
   
   glReadPixels(0, 0, width, VIS_COLORBAR_HEIGHT, GL_RGBA, GL_UNSIGNED_BYTE, pixels);

   TGA_bytes(shot, width, VIS_COLORBAR_HEIGHT, pixels);

   free(pixels);


   /* Write the main drawing area */
   /*******************************/
   pixels = (unsigned char *)calloc(width*height*4, sizeof(char));

   glXMakeCurrent(XtDisplay(vis->params.drawW), XtWindow(vis->params.drawW), vis->params.context_D);
   
   glReadPixels(0, 0, width, height, GL_RGBA, GL_UNSIGNED_BYTE, pixels);

   TGA_bytes(shot, width, height, pixels);

   free(pixels);

   fclose(shot);
   
   return;
}
