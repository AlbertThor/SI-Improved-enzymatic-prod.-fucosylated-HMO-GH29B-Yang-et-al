/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include "structures.h"
#include "defines.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

/* this function just swaps 4byte data values so that we can
 * convert from big-endian to little-endian and likewise from
 * little endian to big endian */
void swap4(void *data, int size)
{
   /* local variables */
   register int i;
   register char *bytes;
   register char tmp;

   bytes = (char *)data;

   /* we do (size *4) total bytes worth of swapping */
   for (i = 0; (i < size); i++)
   {
      /* swap first and last */
      tmp = bytes[0];
      bytes[0] = bytes[3];
      bytes[3] = tmp;

      /* swap middle two */
      tmp = bytes[1];
      bytes[1] = bytes[2];
      bytes[2] = tmp;

      /* next 4 bytes */
      bytes += 4;

   }/* end for loop */

}/* end swap4 function */

/* the format for a phimap is as follows                         *
 * UNFORMATTED FORTRAN                                           *
 *   character*20 uplbl                                          *
 *   character*10 nxtlbl, character*60 toplbl                    *
 *   real*4 phi(*, *, *)                                         *
 *   character*16 botlbl                                         *
 *   real*4 scale, mid(3)                                        *
 *                                                               *
 *  It is important to note that this is unformatted fortran     *
 *  because unformatted fortran adds headers and footers to all  *
 *  data that is written, the header and footer are both integers*
 *  representing the size of the data, so the c format looks like*
 *  int 20 char uplbl[20] int 20                                 *
 *  int 70 char nxtlbl[10] char toplbl[60] int 70                *
 *  int szgrid^3*4 grid[szgrid, szgrid, szgrid] int szgrid^3*4   *
 *  int 16 float scale float mid[3] int 16                       *
 *                                                        --jcg  */


/*   40  (header and footer info)
 * + 106 (string info)
 * + 16  (dimensional info)
 * ---------------------
 *  162 not grid info
 * this function just takes the size of the file, subtracts 162,
 * then divides by 4, then cube roots that number to get the size
 * of the grid  --jcg
 */
int phi_grid_size(FILE *fp, char swap)
{
  /* local variables */
  int   dim,      /* dimension of the grid */
        dimcubd;  /* dimension cubed */
  const int grid_header_loc = 106; /* non-grid information */
  int   grid_byte_size;

  if (fp == NULL) return -1;

  /* find the header for the grid and read it */
  fseek(fp,grid_header_loc,SEEK_SET);
  fread(&grid_byte_size, sizeof(int), 1, fp);

  if (swap) swap4(&grid_byte_size, 1);

  /* these are float values, so convert from bytes to number of floats */
  dimcubd = grid_byte_size/sizeof(float);

  dim = cbrt(dimcubd);

  /* if dim is not a cube root, we have a problem here... */
  if (dim * dim * dim != dimcubd)
  {
     /* maybe they miswrote the header, lets actually count the bytes
      * for backup */
     fseek(fp, 0, SEEK_END);
     grid_byte_size = ftell(fp) - 162;

     dimcubd = grid_byte_size/sizeof(float);

     dim = cbrt(dimcubd);

     /* give it a shot if its really close */
     if ((dim*dim*dim < dimcubd - 1)||(dim*dim*dim > dimcubd + 1))
        dim = 0;

     /* we always leave the file pointer in the same place */
     fseek(fp, grid_header_loc + 4, SEEK_SET);

  }

  return dim;

} /* end phi_grid_size */


/*********************************************************************************
 * this function reads in a phimap of arbitrary dimension and returns            *
 * the dimension of the phimap                                                   *
 * INPUTS: fname                                                                 *
 * OUTPUTS: size of grid                                                         *
 * CHANGES: grid, minx, miny, minz, maxx, maxy, maxz                             *
 * preconditions: fname is the filename to read                                  *
 * postconditions: grid points to a newly allocated nxnxn grid read from file    *
 *                 minx, miny, minz point to the bottom back left corner         *
 *                 maxx, maxy, maxz point to the top front right corner          *
 *                 returns the size of the grid                                  *
 *********************************************************************************/
int read_phi_grid (char *fname, float **grid, float *minx, float *miny, float *minz,
                                              float *maxx, float *maxy, float *maxz)
{
   /* local variables */
   /*******************/
   FILE *fp;   /* the file pointer we read from */
   int  dim,   /* the dimension of the grid */
        i,
        dimcubd,
        nread; /* the number of things we just read */
   float *grd; /* the grid data we are trying to fill */
   char  swap = '\0'; /* do we need to swap these things? */

   float scale,
         extent,
         midx,
         midy,
         midz;

   fp = fopen(fname, "r");  /* open the file to read */

   if (!fp)
      return 0;

   /* check to see if we have to swap this stuff */
   fread(&dim, sizeof(int), 1, fp); /* should always be 20 */
   if (dim != 20)
   {
      swap = 'T';
      swap4(&dim, 1);

      if (dim != 20)
      {
         fprintf(stderr, "Error, improperly formatted phimap file\n");
         return 0;
      }
   }

   dim = phi_grid_size(fp, swap); /* read the dimensions out of it */

   /* error checking */
   if (dim <= 0)
   {
      fprintf(stderr, "Error reading from grid file\n");
      return 0;
   }

   dimcubd = dim*dim*dim;

   /* allocate a new grid */
   *grid = grd = (float *)calloc(dimcubd, sizeof(float));
   if (grd == NULL)
   {
      fprintf(stderr, "Not enough memory to read grid");
      return 0;
   }

   /* read the file */
   /*****************/

   /* first skip past the headers */
   fseek(fp, 110, SEEK_SET); /* this should be right after the headers */

   /* read in the grid */
   nread = fread(grd, sizeof(float), dimcubd, fp);
   if (nread < dimcubd)
   {
      fprintf(stderr, "Grid is in a bad format\n");
      exit(1);
   }

   if (swap) swap4(grd, dimcubd);

   /* skip the grid footer, botlbl, and the next header */
   fseek(fp, 32, SEEK_CUR);

   /* read in scale, midx, midy, and midz */
   if (fread(&scale, sizeof(float), 1, fp) < 1)
   {
      fprintf(stderr, "Grid is in a bad format\n");
      return 0;
   }
   if (fread(&midx,  sizeof(float), 1, fp) < 1)
   {
      fprintf(stderr, "Grid is in a bad format\n");
      return 0;
   }
   if (fread(&midy,  sizeof(float), 1, fp) < 1)
   {
      fprintf(stderr, "Grid is in a bad format\n");
      return 0;
   }
   if (fread(&midz,  sizeof(float), 1, fp) < 1)
   {
      fprintf(stderr, "Grid is in a bad format\n");
      return 0;
   }


   if (swap)
   {
      swap4(&scale, 1);
      swap4(&midx,  1);
      swap4(&midy,  1);
      swap4(&midz,  1);
   }

   printf("This phimap has %i cells on one edge of the cube, lattice spacing is 1/%f, it is centered at (%f, %f, %f)\n", dim, scale, midx, midy, midz);

   if (scale == 0)
   {
      fprintf(stderr, "Grid is in a bad format\n");
      return 0;
   }

   /* close the file */
   fclose(fp);

   extent = (double)(dim-1) / scale;

   printf("Total physical size of the phimap (on one edge) is %f\n", extent);

   /* give back the bounds in a more general form */
   *minx = midx - extent/2.;
   *maxx = midx + extent/2.;
   *miny = midy - extent/2.;
   *maxy = midy + extent/2.;
   *minz = midz - extent/2.;
   *maxz = midz + extent/2.;

   for (i = 0; i < dimcubd; i++)
   {
       grd[i] *= kT_TO_kCAL_PER_MOL;
   }

   return dim;

} /* end function read_phi_grid */
