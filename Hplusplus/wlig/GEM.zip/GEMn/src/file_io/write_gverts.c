/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

#include <stdio.h>
#include <math.h>
#include "file_io.h"
#include "calculations.h"
#include <stdlib.h> /* for exit */
#include <string.h> /* for strcat */

#define MSMS_LINE_SIZE 1024

/**************************************************************************
 * FUNCTION: write_gverts  -- writes out vertices for reuse later         *
 *                                                                        *
 * INPUTS:   molname   -- the name of the molecule to run on              *
 *                                                                        *
 * OUTPUTS:  vertices  -- the vertices to write to the .gvert file        *
 *           triangles -- the triangles to write to the .gface file       *
 *           nvert     -- the number of vertices to write                 *
 *           nface     -- the number of triangles to write                *
 *                                                                        *
 *                                                                        *
 * RETURNS: nothing                                                       *
 **************************************************************************/
void write_gverts(char *molname, vertx *vertices, triangle *triangles, int nvert, int nface)
{
   /* local variables */
   FILE *fp; /* the file pointer to the vertex file */

   char line[MSMS_LINE_SIZE]; /* a line in the input file to read */

   int  i,         /* counter for iterations */
        ierr;

   /* Open the vert file */
   strcpy(line, molname);
   strcat(line, ".gvert");
   fp = fopen(line,"w");
   if (!fp) 
   {
      fprintf(stderr, "Error: could not open file %s for writing.\n", line);
      return;
   }

   /* dump a fake msms-like header, only indicating num vertices, though */
   fprintf (fp, "GEM calculated surface potentials\n");
   fprintf (fp, "#vertex\n");
   fprintf (fp, "%d\n", nvert);

   for (i=0; i< nvert; i++)
   {
      ierr = fprintf
         (
            fp,
            "%f %f %f %f %f %f %d %d %f %lf\n", /* this is the full format of the line */
            vertices[i].x,
            vertices[i].y,
            vertices[i].z,
            vertices[i].xNorm,
            vertices[i].yNorm,
            vertices[i].zNorm,
            0,
            vertices[i].nearest_atom+1,
            0.,
            vertices[i].potential
         );

      if (ierr < 0)
      {
         fprintf(stderr, "Error, file write failure -- disk full?");
         return;
      }

    }/* end for (nv) loop */

    /* close the vertex file */
    fclose(fp);

    strcpy(line, molname);
    strcat(line, ".gface");
    fp = fopen(line,"w");

    if (!fp)
    {
      fprintf(stderr, "Error: could not open file %s for writing.\n", line);
      return;
    }

    /* write header information */
    fprintf (fp, "GEM saved face file\n");
    fprintf (fp, "#faces\n");
    fprintf (fp, "%d\n", nface);

    /* now start reading triangles */
    for (i = 0; i < nface; i++)
    {
       fgets(line, MSMS_LINE_SIZE, fp);

       ierr = fprintf
                (
                   fp,
                   "%d %d %d %d %d\n",
                   triangles[i].v[0]+1,
                   triangles[i].v[1]+1,
                   triangles[i].v[2]+1,
                   0,
                   0
                );

       if (ierr < 0) /* check for errors while reading */
       {
          fprintf(stderr, "Error writing file -- disk full?\n");
          return;
       }

    } /* end for (i < nt) */

    /* close the face file */
    fclose(fp);

}/* end write_gverts function */
