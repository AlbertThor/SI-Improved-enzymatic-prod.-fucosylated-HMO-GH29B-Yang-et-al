/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

/*
 * This function simply reads out data from a native AVS grid file, as
 * MEAD produces this format of file on output of its Phimaps 
 * we are imposing some artificial constraints to the standard AVS format,
 * first:  the  file must be 3 dimensional
 * second: the  fule must be in native format
 * third:  the  data must be either float or double
 * fourth: the  field must be uniform, no other form makes sense
 * this is becauxe we are reading out 3 dimensional data and because
 * I am lazy and don't feel that we need non-native grid format --jcg
 */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "defines.h"
#include "file_io.h"

#define _READ_AVS_TOLERANCE_ .01

/***************************************************************************
 * FUNCTION: read_AVS_header   --reads an AVS format header file           *
 *                                                                         *
 * INPUTS: fp   --file pointer to read header from                         *
 *                                                                         *
 * OUTPUTS: xdim, ydim, zdim  -- dimension of the grid <int>               *
 *          xmin, ymin, zmin  -- lower back left corner of cube            *
 *          xmax, ymax, zmax  -- top front right corner of cube            *
 *          gridtype          -- type of grid (should be 'f')              *
 *                                                                         *
 * RETURNS: 1 on success, 0 on failure                                     *
 *                                                                         *
 ***************************************************************************/
int read_AVS_header 
(
   FILE *fp, 
   int *xdim, int *ydim, int *zdim, 
   float *xmin, float *ymin, float *zmin, 
   float *xmax, float *ymax, float *zmax, 
   char *gridtype
)
{
   /* local constants */
   /*******************/
   const char FORM_FEED = (char)12; /* header ends with 2 of these */

   const int NDIM_FL     = 0,
             DIM1_FL     = 1,
             DIM2_FL     = 2,
             DIM3_FL     = 3,
             NSPACE_FL   = 4,
             VECLEN_FL   = 5,
             DATA_FL     = 6,
             MIN_FL      = 7,
             MAX_FL      = 8,
             FIELD_FL    = 9,
             N_AVS_FLAGS = 10;

   /* local variables */
   /*******************/
   char   flags[N_AVS_FLAGS];

   char  buffer[1024]; /* 1k buffer */
   char  typestring[1024];

   char *pos; /* position in string of found items */

   int  nread,
        temp,
        i;

   memset(flags, 0, N_AVS_FLAGS);

   /* first 5 chars must be "# AVS", rest of line doesn't matter */
   fread(buffer, sizeof(char), 5, fp);
   fgets(typestring, 1023, fp);
   

   if (strncmp(buffer, "# AVS", 5) != 0)
   {
      fprintf(stderr, "This AVS file does not start with \"# AVS\".\n");
      return 0;
   }

    /* now we for sure have a line that doesn't start with # directly after
     * a comment line
     */

     /* read until FF FF */
     while ((fp != NULL)&&(!feof(fp)))
     {
        /* check for FF, harbinger of the end */
        buffer[0] = fgetc(fp);

        if (buffer[0] != FORM_FEED)
           ungetc(buffer[0], fp);
        else
        {
           buffer[1] = fgetc(fp);

           if ((buffer[0] == FORM_FEED) && (buffer[1] == FORM_FEED))
              break;
           else
              ungetc(buffer[1], fp);
        }

        /* get the next line */
        fgets(buffer, 1023, fp);

        if ((fp == NULL) || (feof(fp)))
           break;
        
        /* strip leading spaces */
        for (i = 0; ((i < strlen(buffer))&&(buffer[i] == ' ')); i++);

        if (i == strlen(buffer)) continue;

        /* comments are preceeded by # */
        if (buffer[i] == '#') continue;

        if (strncmp(&buffer[i], "ndim",4) == 0)
        {
           pos = strchr(&buffer[i], '=');

           if (pos == NULL)
           {
              fprintf(stderr, "Phimap is malformed.\n");
              break;
           }

           /* else */
           nread = sscanf(&pos[1], "%i", &temp);

           if ((nread < 1)||(temp != 3))
           {
              fprintf(stderr, "Phimap is malformed.\n");
              break;
           }
           
           flags[NDIM_FL] = '\1';
        }
        else if (strncmp(&buffer[i], "dim1", 4) == 0)
        {
           pos = strchr(&buffer[i], '=');

           if (pos == NULL)
           {
              fprintf(stderr, "Phimap is malformed.\n");
              break;
           }

           /* else */
           nread = sscanf(&pos[1], "%i", &temp);

           if ((nread < 1)||(temp < 2))
           {
              fprintf(stderr, "Phimap is malformed.\n");
              break;
           }
           
           flags[DIM1_FL] = '\1';
           *xdim = temp;

        }
        else if (strncmp(&buffer[i], "dim2", 4) == 0)
        {
           pos = strchr(&buffer[i], '=');

           if (pos == NULL)
           {
              fprintf(stderr, "Phimap is malformed.\n");
              break;
           }

           /* else */
           nread = sscanf(&pos[1], "%i", &temp);

           if ((nread < 1)||(temp < 2))
           {
              fprintf(stderr, "Phimap is malformed.\n");
              break;
           }
           
           flags[DIM2_FL] = '\1';
           *ydim = temp;

        }
        else if (strncmp(&buffer[i], "dim3", 4) == 0)
        {
           pos = strchr(&buffer[i], '=');

           if (pos == NULL)
           {
              fprintf(stderr, "Phimap is malformed.\n");
              break;
           }

           /* else */
           nread = sscanf(&pos[1], "%i", &temp);

           if ((nread < 1)||(temp < 2))
           {
              fprintf(stderr, "Phimap is malformed.\n");
              break;
           }
           
           flags[DIM3_FL] = '\1';
           *zdim = temp;

        }
        else if (strncmp(&buffer[i], "nspace", 6) == 0)
        {
           /* not sure what to do with this */
           flags[NSPACE_FL] = '\1';
        }
        else if (strncmp(&buffer[i], "veclen", 6) == 0)
        {
           pos = strchr(&buffer[i], '=');

           if (pos == NULL)
           {
              fprintf(stderr, "Phimap is malformed.\n");
              break;
           }

           /* else */
           nread = sscanf(&pos[1], "%i", &temp);

           if ((nread < 1)||(temp != 1))
           {
              fprintf(stderr, "Phimap is malformed.\n");
              break;
           }
           
           flags[VECLEN_FL] = '\1';
        }
        else if (strncmp(&buffer[i], "data", 4) == 0)
        {
           pos = strchr(&buffer[i], '=');

           if (pos == NULL)
           {
              fprintf(stderr, "Phimap is malformed.\n");
              break;
           }

           /* WE ALWAYS READ FLOATS OUT OF MSMS BUT ELSE THERE ARE BUGS HERE */
           /* else */
           if (strstr(&pos[1], "float") != NULL)
           {
              *gridtype  = 'f';
           }
           else if (strstr(&pos[1], "double") != NULL)
           {
              *gridtype  = 'd';
           }
           else
           {
              fprintf(stderr, "Phimap is malformed.\n");
              break;
           }

           flags[DATA_FL] = '\1';
        }
        else if (strncmp(&buffer[i], "min_ext", 7) == 0)
        {
           pos = strchr(&buffer[i], '=');

           if (pos == NULL)
           {
              fprintf(stderr, "Phimap is malformed.\n");
              break;
           }

           /* else */

           nread = sscanf(&pos[1], "%f %f %f", xmin, ymin, zmin);

           if (nread < 3)
           {
              fprintf(stderr, "Phimap is malformed.\n");
              break;
           }
           
           flags[MIN_FL] = '\1';
        }
        else if (strncmp(&buffer[i], "max_ext", 7) == 0)
        {
           pos = strchr(&buffer[i], '=');

           if (pos == NULL)
           {
              fprintf(stderr, "Phimap is malformed.\n");
              break;
           }

           /* else */

           nread = sscanf(&pos[1], "%f %f %f", xmax, ymax, zmax);

           if (nread < 3)
           {
              fprintf(stderr, "Phimap is malformed.\n");
              break;
           }
           
           flags[MAX_FL] = '\1';
        }
        else if (strncmp(&buffer[i], "field", 5) == 0)
        {
           pos = strchr(&buffer[i], '=');

           if (pos == NULL)
           {
              fprintf(stderr, "Phimap is malformed.\n");
              break;
           }

           /* else */

           if (strstr(&pos[1], "uniform") == NULL)
           {
              fprintf(stderr, "GEM uses only uniform AVS format files\n.");
              break;
           }
           
           flags[FIELD_FL] = '\1';
        }
     }

     /* check all flags before proceeding */
     for (i = 1; ((i < N_AVS_FLAGS)&&(flags[0])); i++)
     {
         flags[0] = (char)((flags[0]) && (flags[i]));
     }

     printf("center = (%f, %f, %f)\n", (*xmax+*xmin)/2., (*ymax+*ymin)/2., (*zmax+*zmin)/2.);
     printf("cells on an edge = (%i, %i, %i), lower back left corner = (%f, %f, %f), front top right corner = (%f, %f, %f) grid type is %c\n", 
                *xdim, *ydim, *zdim,
                *xmin, *ymin, *zmin,
                *xmax, *ymax, *zmax, *gridtype);

     return (int)flags[0];
}

/***************************************************************************
 * FUNCTION: read_AVS_binary   --reads binary portion of AVS file          *
 *                                                                         *
 * INPUTS: fp   --file pointer to read header from                         *
 *         type --type of element                                          *
 *         xdim, ydim, zdim --size of the grid <int>                       *
 *                                                                         *
 * OUTPUTS: grd               -- grid data                                 *
 *                                                                         *
 * RETURNS: 1 on success, 0 on failure                                     *
 *                                                                         *
 ***************************************************************************/
int read_AVS_binary (FILE *fp, float **grd, int xdim, int ydim, int zdim, char type)
{
   /* local variables */
   /*******************/
   double *dgrid; /* in case we have to read doubles */
   void  *binary_data;
   float  *grid;
   int    data_size,
          nread,
          ngrid,
          i;

   if (type == 'd')
      data_size = sizeof(double);
   else
      data_size = sizeof(float);

    /* allocate space to store the data */
    binary_data = calloc(xdim * ydim * zdim, data_size);

    if (!binary_data)
    {
       fprintf(stderr, "Could not allocate enough space to hold phimap\n");
       return 0;
    }

    nread = fread(binary_data, data_size, xdim * ydim * zdim, fp);

    if (nread < (xdim * ydim * zdim))
    {
       fprintf(stderr, "Grid does not contain enough data\n");
       return 0;
    }
    /*else*/
    /* convert from double to float if type is 'd' */
    if (type == 'd')
    {
       dgrid = binary_data;

       grid = calloc(xdim*ydim*zdim, sizeof(float));

       /* convert data from double to float */
       ngrid = xdim*ydim*zdim;
       for (i = 0; i < ngrid;i++)
           grid[i] = dgrid[i] * ELECTROSTATIC_CONVERSION_FACTOR; 

       free(binary_data);
       binary_data  = NULL;
       dgrid        = NULL;
    }
    else
    {
       grid = binary_data;

       ngrid = xdim*ydim*zdim;
       for (i = 0; i < ngrid; i++)
          grid[i] *= ELECTROSTATIC_CONVERSION_FACTOR;
    }

    *grd = grid;

    return 1;
}


/***************************************************************************
 * FUNCTION: read_avs   --reads in an avs file                             *
 *                                                                         *
 * INPUTS: fname --file name to open                                       *
 *                                                                         *
 * OUTPUTS: grd               -- grid data                                 *
 *          xdim, ydim, zdim  -- size of the grid <int>                    *
 *          xmin, ymin, zmin  -- bottom, back, left corner of the grid     *
 *          xmax, ymax, zmax  -- front, top, right corner of the grid      *
 *                                                                         *
 * RETURNS: 1 on success, 0 on failure                                     *
 *                                                                         *
 ***************************************************************************/
int 
read_avs 
(
   char *fname,
   float **grd,
   int *xdim, int *ydim, int *zdim, 
   float *xmin, float *ymin, float *zmin, 
   float *xmax, float *ymax, float *zmax
)
{
   /* local variables */
   /*******************/

   FILE *fp; /* input file stream for the grid file  */
   /* flags */
   char   gridtype='d'; /* d = double, f = float */
   float  boundsbottom[6];
   int gridSize;

   /* make sure we start with 0 data */
   *grd = NULL;
   *xdim = *ydim = *zdim = 0;
   *xmin = *ymin = *zmin = *xmax = *ymax = *zmax = 0;

   /* file has to exist */
   if ((fp = fopen(fname, "rb")) == NULL)
   {
      fprintf(stderr, "Could not open file to read.\n");
      return 0;
   }

   if (!read_AVS_header (fp, xdim, ydim, zdim, xmin, ymin, zmin, xmax, ymax, zmax, &gridtype))
   {
      fprintf (stderr, "Could not read AVS header information\n");
      fclose(fp);
      return 0;
   }

   if (!read_AVS_binary (fp, grd, *xdim, *ydim, *zdim, gridtype))
   {
      fprintf (stderr, "Could not read AVS binary information\n");
      fclose(fp);
      return 0;
   }

   gridSize = (*xdim) * (*ydim) * (*zdim);
   printf("Total number of cells in the grid: %i\n", gridSize);

   /* AVS files have a footer containing the xmin, xmax, ymin, ymax, and zmin, zmax */
   /* we use these to determine byte-swapping conditions                            */
   fread(boundsbottom, sizeof(float), 6, fp);
   fclose(fp);

   /* detect byte swapping conditions */
   if (
        (fabsf(boundsbottom[0] - *xmin) > _READ_AVS_TOLERANCE_) ||
        (fabsf(boundsbottom[2] - *ymin) > _READ_AVS_TOLERANCE_) ||
        (fabsf(boundsbottom[4] - *zmin) > _READ_AVS_TOLERANCE_) ||
        (fabsf(boundsbottom[1] - *xmax) > _READ_AVS_TOLERANCE_) ||
        (fabsf(boundsbottom[3] - *ymax) > _READ_AVS_TOLERANCE_) ||
        (fabsf(boundsbottom[5] - *zmax) > _READ_AVS_TOLERANCE_)
      )
   {
      printf("WARNING: DETECTED A FILE FROM ALTERNATE ARCHITECTURE, SWAPPING.\n");

      /* swap the bounds and the grid */
      swap4(boundsbottom, 6);
      swap4(*grd, gridSize);

      /* if byte swapping doesn't generate agreement, then something
       * serious is wrong with the file format, fail */
      if (
           (fabsf(boundsbottom[0] - *xmin) > _READ_AVS_TOLERANCE_) ||
           (fabsf(boundsbottom[2] - *ymin) > _READ_AVS_TOLERANCE_) ||
           (fabsf(boundsbottom[4] - *zmin) > _READ_AVS_TOLERANCE_) ||
           (fabsf(boundsbottom[1] - *xmax) > _READ_AVS_TOLERANCE_) ||
           (fabsf(boundsbottom[3] - *ymax) > _READ_AVS_TOLERANCE_) ||
           (fabsf(boundsbottom[5] - *zmax) > _READ_AVS_TOLERANCE_)
         )
      {
         fprintf(stderr, "Phimap malformed\n");
         return 0;
      }
   }

   /* seems like everything went ok */
   return 1;
}
