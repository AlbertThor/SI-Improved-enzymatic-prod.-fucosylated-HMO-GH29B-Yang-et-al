/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include <string>
#include <string.h>
#include <stdio.h>
#include <iostream>
#include "file_io.h"
#include "defines.h"
#include "visualize.h"
#include "calculations.h"
#include "partitioned_open.h"

using namespace std;

/***************************************************************************
 * FUNCTION: openFile  --wraps partitioned open for serial use             *
 *                                                                         *
 * INPUTS:   molname   --name of molecule (filename - extensions) to open  *
 *           calc      --flag determining whether we calc or sample        *                                             
 *           auxStr    --string containing auxiliary info for opening      *
 *           diel_int  --internal dielectric constant                      *
 *           diel_ext  --external dielectric constant                      *
 *           sal       --salinity constant                                 *
 *           proj_len  --length to project away from the surface           *
 *           triDens   --triangle density (tri/angstrom)                   *
 *           probeRadius --msms input value for probe radius               *
 *           fixedA      --if we user set A, then this is the value        *
 *           compare_phi --a flag telling us whether we are calculating    *
 *                         or differentiating                              *
 *           compare_phi_fname --filename to get phi comp values from      *
 *           v_ptr       --vis_data_struct pointer void cast               *
 *                                                                         *
 * OUTPUTS:  none                                                          *
 *                                                                         *
 * SIDE EFFECTS:  Sets a whole bunch of values in the vis_data struct      *
 *                and does the whole open file thing.                      *
 *                                                                         *
 ***************************************************************************/
extern "C" int openFile (char *molname, int calctype, char *auxStr, double diel_int, double diel_ext, double sal, double proj_len, double triDens, double probeRadius, double fixedA, int compare_phi, char *compare_phi_fname, void *v_ptr)
{
   /* local variables */
   /*******************/
   partitioned_open_struct open_dat;
   vis_data_struct         *vis = (vis_data_struct *)v_ptr;
   int prog = 0;

   /* initialize the structure */
   memset(&open_dat, 0, sizeof(partitioned_open_struct));

   open_dat.calctype           = calctype;
   open_dat.diel_int           = diel_int;
   open_dat.diel_ext           = diel_ext;
   open_dat.phiType            = TOTAL_POTENTIAL;
   open_dat.sal                = sal;
   open_dat.proj_len           = proj_len;
   open_dat.triDens            = triDens;
   open_dat.probeRadius        = probeRadius;
   open_dat.vis                = vis;
   open_dat.molname            = molname;
   open_dat.auxStr             = auxStr;
   open_dat.A                  = fixedA;
   open_dat.compare_phi        = compare_phi;
   open_dat.compare_phi_file   = compare_phi_fname;
   open_dat.ion_exc_rad        = vis->mol_data.ion_exc_rad;

   /* single step from terminal */
   prog = partitioned_open(&open_dat, prog, 1);

   if (prog > 0)
   {
      /* finalize the stuff */
      partitioned_open_finalize(&open_dat);
   }

   return ((prog > 0)?1:0);

}/* end function openFile */
