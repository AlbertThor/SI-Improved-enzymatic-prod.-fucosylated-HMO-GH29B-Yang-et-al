/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "structures.h"

#define CUST_BONDS_LINE_SIZE 1024

/* Finds residue and atom numbers by atom number in the pqr file*/
void find_residue_and_atom_numbers(int natom, int *na, int *nr, residue* residues, int nres)
{
   /* local variables */
   int i;
   for (i = 0; i < nres; ++i) 
   {
      if (natom > residues[i].natoms) 
      {
         natom -= residues[i].natoms;
      } 
      else 
      {
         *na = natom - 1;
         *nr = i;
         break;
      }
   }
}


/******************************************************************************
 * FUNCTION: read_cust_bonds -- reads in file where bonds parameters are      *
 *                              specified                                     *
 *                                                                            *
 * INPUTS: filename      -- the file name to be read                          *
 *         max_min_value -- max of minimum values to be included as bonds     *
 *         min_max_value -- min of maximum values to be included as bonds     *
 *         residues      -- residues of a molecule                            *
 *         nres          -- number of residues                                *
 *         bonds         -- array of custom bonds to be created               *
 *         nbonds        -- number of created custom bonds                    *
 *                                                                            *
 * RETURNS: nothing                                                           *
 ****************************************************************************/
void read_cust_bonds(char *filename, float max_min_value, float min_max_value, residue* residues, int nres, bond **bonds, int *nbonds)
{
   /* local variables */
   FILE *fp; /* the file pointer to the text file */

   float  strength;     
   int    atom1, atom2, /* atom numbers */
          i; 

   bond *bnds = NULL;

   char line[CUST_BONDS_LINE_SIZE]; /* a line in the input file to read */
   /* Open the text file */
   fp = fopen(filename,"r");
   if (!fp) 
   {
      fprintf(stderr, "Error: could not open file %s\n", filename);
      return;
   }

   /* Count the number of bonds */
   *nbonds = 0;
   while (fgets( line, CUST_BONDS_LINE_SIZE, fp ) != NULL)
   {
      sscanf
      (
          line,
          "%d %d %f", /* this is the full format of the line */
          &atom1,
          &atom2,
          &strength
      );      
      if (strength <= max_min_value || strength >= min_max_value)
      {
         (*nbonds)++;
      }
   }
   /* read the bonds and save them */
   if (*nbonds > 0) {
      /* rewind the file */
      fseek(fp, 0, SEEK_SET);

      *bonds = bnds = (bond *)calloc(*nbonds, sizeof(bond));
      i = 0;
      while (fgets( line, CUST_BONDS_LINE_SIZE, fp ) != NULL)
      {
         sscanf
         (
             line,
             "%d %d %f", /* this is the full format of the line */
             &atom1,
             &atom2,
             &strength
         );      

         if (strength <= max_min_value || strength >= min_max_value)
         {
            find_residue_and_atom_numbers(atom1, &bnds[i].a1, &bnds[i].r1, residues, nres);
            find_residue_and_atom_numbers(atom2, &bnds[i].a2, &bnds[i].r2, residues, nres);
            bnds[i].length = strength;
            i++; 
         }
      }
   }

   /* close the text file */
   fclose(fp);
}
