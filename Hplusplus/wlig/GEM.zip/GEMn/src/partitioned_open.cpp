/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/

#include "partitioned_open.h"
#include "residue_select_form.h"
#include "tellUser.h"
#include <string>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include "file_io.h"
#include "visualize.h"
#include "calculations.h"

using namespace std;

/* This code basically chops up the process of opening a file into
 * chunks and assigns each chunk a percentage of the amount of total
 * work necessary to finish the task of opening a file.  The process
 * is passed in one pointer and an integer indicating its last completed
 * hundredth of work, and decides what needs to be done based on the
 * combined data. --jcg
 **********************************************************************/

static int partitioned_openCB (void *p_ptr, int currProg)
{
   /* local variables */
   /*******************/
   partitioned_open_struct *open_dat = (partitioned_open_struct *)p_ptr;

   /* multi-step for ui */
   return partitioned_open(open_dat, currProg, 0);
}/* end function partitioned_openCB */

int partitioned_open(partitioned_open_struct *open_dat, int currProg, int single_step)
{
   /* local variables */
   /*******************/

   /* various filenames */
   string tempstr1,
          tempstr2;

   /* grid extraction variables */
   int    to_return = 0,
          status,
          step_size;

   if ((currProg == 0)||(single_step))
   {
      if (open_dat->calctype != POPEN_READ_GVERTS)
      {
         if (open_pqr_run_msms(open_dat))
            to_return = 2;
         else
            return -1;
      }
      else
      {
         if (open_pqr_load_gverts(open_dat))
            to_return = 100;
         else
            return -1;
      }
   }
   if (((currProg == 2)&&(!to_return))||(single_step))
   {
      /***********************************************/
      /* Estimating A should take up about 3 percent */
      /***********************************************/
         /* estimate A, the GB molecular radius */
         if (open_dat->calctype == POPEN_CALC_DIRECTLY)
         {
            if (open_dat->A < 1)
               open_dat->A=estimate_A (open_dat->residues, open_dat->nresidues);

               printf("The estimated electrostatic radius (A) of this molecule is: %2.1f\n", open_dat->A);
               fflush(stdout);
         }

         to_return = 10;

         open_dat->i = 0;

   }
   if ((((currProg >= 10) && (currProg < 97))&&(!to_return))||(single_step))
   {
      /* <><> maybe we want to change calc directly to calctype with NONE available */

      /****************************************************************/
      /* The hefty part is calculating the potential, we may need to  */
      /* break that function up as well...                            */
      /****************************************************************/
         if (open_dat->calctype == POPEN_CALC_DIRECTLY)
         {
            open_dat->vis->mol_data.calc_type = GEM_ONLY;

            if (!single_step)
               step_size = (int)((double)open_dat->nvert/86. + 1);
            else
               step_size = open_dat->nvert; /* step all in one single step */

            calc_charge_potential_single_step
                (
                   open_dat->residues,
                   open_dat->nresidues,
                   open_dat->vert,
                   open_dat->nvert,
                   open_dat->A,
                   open_dat->proj_len,
                   open_dat->diel_int,
                   open_dat->diel_ext,
                   open_dat->sal,
                   open_dat->ion_exc_rad,
                   open_dat->phiType,
                   &(open_dat->i),
                   step_size
                );

            to_return = currProg + 1;
         }
         else
            to_return = 97;

   }
   if (((currProg == 97)&&(!to_return))||(single_step))
   {
         if (open_dat->calctype == POPEN_READ_PHIMAP)
         {
            open_dat->vis->mol_data.calc_type = READ_ONLY;

            if (open_dat->auxStr == NULL)
            {
               tellUser("Error", "Phimap must have a name to be read\n");
               return -1;
            }
         
            /* find out what kind of phimap we are reading */
            if (strstr(open_dat->auxStr, ".phi") == &open_dat->auxStr[strlen(open_dat->auxStr)-4])
            {
               cout<<"This phimap has the delphi phimap extension (phi)."<<endl;
               /* read in a phimap from the selected file */
               open_dat->vis->mol_data.grid_y_dim = 
               open_dat->vis->mol_data.grid_z_dim = 
               open_dat->vis->mol_data.grid_x_dim = read_phi_grid
                               (
                                  open_dat->auxStr,
                                  &(open_dat->grid),
                                  &(open_dat->vis->mol_data.grid_world_dims[0]),
                                  &(open_dat->vis->mol_data.grid_world_dims[1]),
                                  &(open_dat->vis->mol_data.grid_world_dims[2]),
                                  &(open_dat->vis->mol_data.grid_world_dims[3]),
                                  &(open_dat->vis->mol_data.grid_world_dims[4]),
                                  &(open_dat->vis->mol_data.grid_world_dims[5])
                               );

      
               /* error checking */
               if ((open_dat->vis->mol_data.grid_x_dim <= 0) || (open_dat->grid == NULL))
               {
                  tellUser ("Error", "Could not open phimap.\n");
                  return -1;
               }
            }
            else if (strstr(open_dat->auxStr, ".fld") == &open_dat->auxStr[strlen(open_dat->auxStr)-4])
            {
               cout<<"This phimap has the AVS field extension (fld)."<<endl;

               /* read in a phimap from the selected file */
               status = read_avs
                               (
                                  open_dat->auxStr,
                                  &(open_dat->grid),
                                  &(open_dat->vis->mol_data.grid_x_dim),
                                  &(open_dat->vis->mol_data.grid_y_dim), 
                                  &(open_dat->vis->mol_data.grid_z_dim), 
                                  &(open_dat->vis->mol_data.grid_world_dims[0]),
                                  &(open_dat->vis->mol_data.grid_world_dims[1]),
                                  &(open_dat->vis->mol_data.grid_world_dims[2]),
                                  &(open_dat->vis->mol_data.grid_world_dims[3]),
                                  &(open_dat->vis->mol_data.grid_world_dims[4]),
                                  &(open_dat->vis->mol_data.grid_world_dims[5])
                               );

      
               /* error checking */
               if (!status)
               {
                  tellUser ("Error", "Could not open phimap.\n");
                  return -1;
               }
            }
      
            if (open_dat->grid) /* not needed, but i like it there */
            {
               project_grd
               (
                  open_dat->vert,
                  open_dat->grid,
                  open_dat->nvert,
                  open_dat->vis->mol_data.grid_x_dim,
                  open_dat->vis->mol_data.grid_y_dim,
                  open_dat->vis->mol_data.grid_z_dim,
                  open_dat->vis->mol_data.grid_world_dims,
                  open_dat->proj_len,
                  SET_VALUES
               );

               /* compute surface charges */
               calculate_surface_charge
                  (
                      open_dat->vert,
                      open_dat->nvert,
                      open_dat->grid,
                      open_dat->vis->mol_data.grid_x_dim,
                      (open_dat->vis->mol_data.grid_world_dims[3]
                       - open_dat->vis->mol_data.grid_world_dims[0])
                      / (float) open_dat->vis->mol_data.grid_x_dim,
                      open_dat->vis->mol_data.grid_world_dims,
                      open_dat->proj_len
                  );
            }
         }
         to_return = 98;
   }
   if (((currProg == 98)&&(!to_return))||(single_step))
   {
        if (open_dat->compare_phi)
        {
           open_dat->vis->mol_data.calc_type += DIFF_FLAG;

           /* if we have already read a phimap, free the grid because we
              are going to reuse it */
           if ((open_dat->calctype == POPEN_READ_PHIMAP) && (open_dat->grid != NULL))
           {
              free(open_dat->grid);
              open_dat->grid = NULL;
           }

            if (open_dat->compare_phi_file == NULL)
            {
               tellUser("Error", "Comparison phimap must have a name to be read\n");
               return -1;
            }

            /* read in a phimap from the selected file */
            /* find out what kind of phimap we are reading */
            if (strstr(open_dat->compare_phi_file, ".phi") == &open_dat->compare_phi_file[strlen(open_dat->compare_phi_file)-4])
            {
               cout<<"This phimap has the delphi phimap extension (phi)."<<endl;
               /* read in a phimap from the selected file */
               open_dat->vis->mol_data.grid_y_dim = 
               open_dat->vis->mol_data.grid_z_dim = 
               open_dat->vis->mol_data.grid_x_dim = read_phi_grid
                               (
                                  open_dat->compare_phi_file,
                                  &(open_dat->grid),
                                  &(open_dat->vis->mol_data.grid_world_dims[0]),
                                  &(open_dat->vis->mol_data.grid_world_dims[1]),
                                  &(open_dat->vis->mol_data.grid_world_dims[2]),
                                  &(open_dat->vis->mol_data.grid_world_dims[3]),
                                  &(open_dat->vis->mol_data.grid_world_dims[4]),
                                  &(open_dat->vis->mol_data.grid_world_dims[5])
                               );

      
               /* error checking */
               if ((open_dat->vis->mol_data.grid_x_dim <= 0) || (open_dat->grid == NULL))
               {
                  tellUser ("Error", "Could not open phimap.\n");
                  return -1;
               }
            }
            else if (strstr(open_dat->compare_phi_file, ".fld") == &open_dat->compare_phi_file[strlen(open_dat->compare_phi_file)-4])
            {
               cout<<"This phimap has the AVS field extension (fld)."<<endl;

               /* read in a phimap from the selected file */
               status = read_avs
                               (
                                  open_dat->compare_phi_file,
                                  &(open_dat->grid),
                                  &(open_dat->vis->mol_data.grid_x_dim),
                                  &(open_dat->vis->mol_data.grid_y_dim), 
                                  &(open_dat->vis->mol_data.grid_z_dim), 
                                  &(open_dat->vis->mol_data.grid_world_dims[0]),
                                  &(open_dat->vis->mol_data.grid_world_dims[1]),
                                  &(open_dat->vis->mol_data.grid_world_dims[2]),
                                  &(open_dat->vis->mol_data.grid_world_dims[3]),
                                  &(open_dat->vis->mol_data.grid_world_dims[4]),
                                  &(open_dat->vis->mol_data.grid_world_dims[5])
                               );

      
               /* error checking */
               if (!status)
               {
                  tellUser ("Error", "Could not open phimap.\n");
                  return -1;
               }
            }

            /* error checking */
            if ((open_dat->vis == NULL)||(open_dat->vis->mol_data.grid_x_dim <= 0) || (open_dat->grid == NULL))
            {
               tellUser ("Error", "Could not open reference phimap for comparison.\n");
               return -1;
            }
      
          
            project_grd
               (
                  open_dat->vert,
                  open_dat->grid,
                  open_dat->nvert,
                  open_dat->vis->mol_data.grid_x_dim,
                  open_dat->vis->mol_data.grid_y_dim,
                  open_dat->vis->mol_data.grid_z_dim,
                  open_dat->vis->mol_data.grid_world_dims,
                  open_dat->proj_len,
                  DIFFERENTIATE
               );
         }


         to_return = 100;
   }

    
   return to_return;
}/* end function partitioned_open */

static void partitioned_open_finalizeCB (void *p_ptr)
{
   /* local variables */
   partitioned_open_struct *open_dat = (partitioned_open_struct *)p_ptr;
          
   
   partitioned_open_finalize(open_dat);
}

void partitioned_open_finalize(partitioned_open_struct *open_dat)
{
   /* local variables */
   char str[1024];
   int i;
   vis_data_struct *vis = open_dat->vis;

   float pos[4];

   /* clear out the old data */
   clear_moldata(&vis->mol_data);

   /* set the data we just read in */
   vis->mol_data.grid      = open_dat->grid;
   vis->mol_data.residues  = open_dat->residues;
   vis->mol_data.nresidues   = open_dat->nresidues;
   vis->mol_data.ion_exc_rad = open_dat->ion_exc_rad;
   vis->mol_data.bonds     = NULL;
   vis->mol_data.nbonds    = 0;
   vis->mol_data.vert      = open_dat->vert;
   vis->mol_data.nvert     = open_dat->nvert;
   vis->mol_data.tri       = open_dat->tri;
   vis->mol_data.ntri      = open_dat->ntri;
   vis->mol_data.A         = open_dat->A;
   vis->mol_data.diel_int  = open_dat->diel_int;
   vis->mol_data.diel_ext  = open_dat->diel_ext;
   vis->mol_data.sal       = open_dat->sal;
   vis->mol_data.molname   = (char *)calloc(strlen(open_dat->molname)+1, sizeof(char));
   strcpy(vis->mol_data.molname, open_dat->molname);
      
   vis->params.scale       = 1.;
   vis->params.xshift      = 0;
   vis->params.yshift      = 0;
   vis->params.selected_res = -1;
   vis->params.rotation_dirty = 1;

   populate_statistics(vis);


   if (vis->params.up)
   {
      popdown_atom_info_dialog(vis->params.atom_info);

      /* we have to reset the orthographic bounds here ... */
      glXMakeCurrent
      (
         XtDisplay(vis->params.drawW),
         XtWindow(vis->params.drawW),
         vis->params.context_D
      );

      glMatrixMode(GL_PROJECTION);
      glLoadIdentity();

      pos[0] = vis->params.x[MAX];
      pos[1] = vis->params.y[MAX];
      pos[2] = vis->params.z[MAX];
      pos[3] = 1.;

      glOrtho
            (
              -vis->params.x[EXTENT]/2., vis->params.x[EXTENT]/2.,
              -vis->params.y[EXTENT]/2., vis->params.y[EXTENT]/2.,
              -vis->params.z[EXTENT]/2., vis->params.z[EXTENT]/2.
            );

      glMatrixMode(GL_MODELVIEW);

      glLoadIdentity();

      glGetDoublev(GL_MODELVIEW_MATRIX, vis->params.rot_mat);
      glGetDoublev(GL_MODELVIEW_MATRIX, vis->params.rot_store_mat);

      glLightfv(GL_LIGHT0, GL_POSITION, pos);

      for (i = strlen(open_dat->molname)-1; i >= 0; i--)
         if (open_dat->molname[i] == '/')
         {
            i = i + 1;
            break;
         }

      /* redraw all this stuff */
      sprintf(str, "Viewing molecule %s", &(open_dat->molname[i]));
      XtVaSetValues(vis->params.drawTop, XmNtitle, str, NULL);

      if ((vis->params.atomDrawMode != A_DRAW_SPACEFILL) &&
          (vis->params.atomDrawMode != DRAW_NONE))
      {
         vis->mol_data.nbonds = extrapolate_bonds(vis->mol_data.residues, vis->mol_data.nresidues, (bond **)&vis->mol_data.bonds);
      }


      gen_main_mol_lists(vis, 1, 1, -1.);

      /* this also draws */
      updateTranslations(vis, 1, 1);

      clear_residue_select_form(vis->params.res_sel);
      fill_residue_select_form(vis->params.res_sel);

      glXMakeCurrent
      (
         XtDisplay(vis->params.colrW),
         XtWindow(vis->params.colrW),
         vis->params.context_S
      );

      drawColrMap(vis);

   }

   printf("Color-scale range: min = %f, max = %f\n", vis->params.vp[MIN], vis->params.vp[MAX]);
}

extern "C" void popen_file (Widget w, char *molname, int calctype, char *aux, double diel_int, double diel_ext, double salt, double proj_len, double triDens, double probeRadius, double ion_exc_radius, int phiType, double A, vis_data_struct *vis)
{
   /* local variables */
   partitioned_open_struct *open_dat;
   status_dialog_struct    *stat;

   if (!molname) return;

   /* allocate memory for the structure */
   open_dat = (partitioned_open_struct *)calloc(1, sizeof(partitioned_open_struct));

   open_dat->molname       = (char *)calloc(strlen(molname)+1, sizeof(char));
   strcpy(open_dat->molname, molname);

   if (aux)
   {
      open_dat->auxStr = (char *)calloc(strlen(aux)+1, sizeof(char));
      strcpy(open_dat->auxStr, aux);
   }

   open_dat->calctype      = calctype;
   open_dat->diel_int      = diel_int;
   open_dat->diel_ext      = diel_ext;
   open_dat->sal           = salt;
   open_dat->phiType       = phiType;
   open_dat->proj_len      = proj_len;
   open_dat->triDens       = triDens;
   open_dat->probeRadius   = probeRadius;
   open_dat->ion_exc_rad   = ion_exc_radius;
   open_dat->vis           = vis;
   open_dat->A             = A;

   stat = create_status_dialog(w, open_dat, partitioned_openCB, "Computing...", open_dat->vis->params.vi);
   status_set_finalize(stat, partitioned_open_finalizeCB);
   status_start_run(open_dat->vis->params.app, stat);
}
