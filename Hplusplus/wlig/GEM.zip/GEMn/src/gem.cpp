/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <math.h>
#include "file_io.h"
#include "visualize.h"
#include "defines.h"
#include "calculations.h"
#include "partitioned_open.h"
#include "gem.h"

using namespace std;

/* Generally starts up the program, parses command line, and does what is
 * requested. --jcg
 * Inputs: argc -- number of arguments passed
 *         argv -- arguments (array of character strings)
 * Outputs: return status of the program
 *                      --jcg
 */
int main (int argc, char **argv)
{
   /* local variables */
   /*******************/
   double  proj_len     = 1.5,
           tri_dens     = 3.0,
           probe_radius = 2.0;

   int opentype;

   vis_data_struct *vis; /* for use with visualize and write_r3d */

   bool   flags[NUM_FLAGS];        /* flags sent in on command line */
   string options[NUM_FILE_TYPES]; /* file names and other options send in */

   int    outDim(65),  /* the dimensions of the grid we output */
          ret_stat;

   float outWid;

   double A(0);

   char *auxStr;
   char buff[256];

   if ((argc < 4) || (!check_cmd_line(argc, argv, options, flags)))
   {
      if (argc == 1)
      {
         vis = get_vis_struct(NULL, NULL, NULL, 0, 0, 0);
         visualize(vis, argc, argv);
         exit(0);
      }
      else
      {
         cerr<<"Format for command line options is \'gem [molname diel_ext diel_int salinity] <options>\'"<<endl
             <<"molname, diel_ext, diel_int, and salinity are all required together if present"<<endl
             <<"molname is the name of the molecule"<<endl
             <<"diel_ext is the exterior dielectric charge"<<endl
             <<"diel_int is the interior dielectric charge"<<endl
             <<"salinity is the salinity of the environment"<<endl
             <<"and <options> can be any combination of the following:"<<endl
             <<"\t-readVertices"<<endl
             <<"\t-readPhi       <filename>"<<endl
             <<"\t-writePhi      <filename> <spacial edge> <discrete edge>"<<endl
             <<"\t-comparePhi    <filename>"<<endl
             <<"\t-projLen       <length>"<<endl
             <<"\t-triDens       <triangles>"<<endl
             <<"\t-probeRad      <radius>"<<endl
             <<"\t-fixA          <electrostatic radius>"<<endl
             <<"\t-dumpImage     <fileName> <width> <height>"<<endl
             <<"\t-dumpVertices  <fileName>"<<endl
             <<"\t-fixColors     <maximum value>"<<endl
             <<"\t-bg            <float red> <float green> <float blue>"<<endl
             <<"\t-decorMol      <molecule name>"<<endl
             <<"\t-decorType     <decor mol look>"<<endl
             <<"\t\twhere <decor mol type> can be one of:"<<endl
             <<"\t\t\tdecorSurf, decorSurfSticks, decorSurfBallsSticks,"<<endl
             <<"\t\t\tdecorSurfBackbone, decorSticks, decorBallsSticks,"<<endl
             <<"\t\t\tdecorBackbone, and decorSpacefill"<<endl
             <<"\t-customInteractions <filename> <max of min value> <min of max value>"<<endl
             <<"\t-customInteractionsOnly"<<endl
             <<"\tor finally -visualize"<<endl
             <<"\tby default: if no arguments are given then gem starts in visual mode."<<endl;
         exit(1);
      }
   }/* end if (argc) */

   if (flags[TRI_SPEC])
      tri_dens = atof((char *)options[TRI_SPEC_VAL].c_str());

   if (flags[PROBE_SPEC])
      probe_radius = atof((char *)options[PROBE_RADIUS_VAL].c_str());

   if (flags[PROJ_SPEC])
      proj_len = atof((char *)options[PROJ_LENGTH_VAL].c_str());

   if (flags[A_SPEC])
      A = atof((char *)options[A_SPEC_VAL].c_str());

   auxStr = buff;
   sprintf(buff, "%s", (char *)options[PHI_IN_FILE].c_str());

   vis = get_vis_struct(NULL, NULL, NULL, 0, 0, 0);

   /* get all the dielectric info from command line */
   vis->mol_data.diel_ext = atof(argv[2]);
   vis->mol_data.diel_int = atof(argv[3]);
   vis->mol_data.sal = atof(argv[4]);


   opentype = POPEN_CALC_DIRECTLY;

   if (flags[READ_GVERTS])
   {
      opentype = POPEN_READ_GVERTS;
   }
   else if (flags[READ_PHI])
   {
      opentype = POPEN_READ_PHIMAP;
   }
   else
   {
      if (!flags[DUMP_VERTICES] && !flags[WRITE_PHI] && !flags[DUMP_IMAGE] && !flags[VISUALIZE])
         opentype = POPEN_CALC_NONE;
   }

   ret_stat = openFile
                 (
                    argv[1],
                    opentype,
                    auxStr,
                    vis->mol_data.diel_int,
                    vis->mol_data.diel_ext,
                    vis->mol_data.sal,
                    proj_len,
                    tri_dens,
                    probe_radius,
                    A,
                    flags[COMPARE_PHI],
                    (char *)options[PHI_COMPARE_FILE].c_str(),
                    vis
                 );

   if (!ret_stat){exit(1);}

   vis->mol_data.calc_type = !flags[READ_PHI];
   if (flags[COMPARE_PHI])
       vis->mol_data.calc_type += DIFF_FLAG;

   if (flags[READ_PHI])
   {
      vis->mol_data.calc_type = READ_ONLY;
   }
   else
   {
      vis->mol_data.calc_type = GEM_ONLY;
   }
   if (flags[COMPARE_PHI])
      vis->mol_data.calc_type += DIFF_FLAG;

   if (!ret_stat)
   {
      cerr<<"Error opening molecule named "<<argv[1]<<endl;
      exit(1);
   }

   if (flags[FIX_COLOR_SCALE])
   {
      double bound = atof((char *)options[COLOR_SCALE_VAL].c_str());
      bound = fabs(bound);
      vis->params.vp[MIN] = -bound;
      vis->params.vp[MAX] = bound;
      vis->params.vp[EXTENT] = vis->params.vp[MAX] - vis->params.vp[MIN];
      vis->params.vp[CENTER] = (vis->params.vp[MAX] + vis->params.vp[MIN])/2.;

      generate_colors(vis);
   }

   if (flags[DECOR_MOLECULE])
   {
      if (flags[DECOR_TYPE])
      {
         ret_stat = open_decoration_molecule
         (
            (char *)options[DECOR_MOL_NAME].c_str(),
            (char *)options[DECOR_MOL_LOOK].c_str(),
            vis
         );
      }
      else
      {
         ret_stat = open_decoration_molecule
         (
            (char *)options[DECOR_MOL_NAME].c_str(),
            (char *)"default",
            vis
         );
      }

      if (ret_stat == 0)
      {
         cerr<<"Error opening decoration molecule "<<options[DECOR_MOL_NAME]<<endl;
      }
   }

   if (flags[WRITE_PHI])
   {

      vis->mol_data.calc_type = !flags[READ_PHI];

      outDim = atoi( (char *)options[PHI_EDGE_VAL].c_str());

      if (outDim % 2)
      {
         outWid = atof( (char *)options[PHI_WID_VAL].c_str());

         write_grid_from_vis 
            (
               (char *)options[PHI_OUT_FILE].c_str(),
               outDim,
               outWid,
               vis
            );
      }
      else
      {
         printf("error writing phimap, dimension must be odd\n");
      }
    }

   if (flags[DUMP_VERTICES])
   {
      write_gverts
          (
             (char *)options[VERTEX_FILE_NAME].c_str(),
              vis->mol_data.vert,
              vis->mol_data.tri,
              vis->mol_data.nvert,
              vis->mol_data.ntri
          );
   }

   if (flags[BG_COLOR])
   {
      sscanf
        (
           options[BG_COLOR_RGB].c_str(),
           "%f\n%f\n%f",
           &vis->params.bg_color[0],
           &vis->params.bg_color[1],
           &vis->params.bg_color[2]
        );
   }

   if (flags[DUMP_IMAGE])
   {
      char image_name[options[IMAGE_VALS].length()];
      int image_wid,
          image_hit;

      sscanf
        (
           options[IMAGE_VALS].c_str(),
           "%s\n%i\n%i",
           image_name,
           &image_wid,
           &image_hit
        );

      screenshot_pbuff(vis, image_wid, image_hit, image_name);
   }

   if (flags[TRANSPARENCY]) 
   {
      vis->params.trans = atof((char *)options[TRANSPARENCY_VAL].c_str());
   }

   if (flags[CUST_BOND])
   {
      float max_min_bound_value,
            min_max_bound_value;

      sscanf
        (
           options[CUST_BOND_MAX_MIN].c_str(),
           "%f",
           &max_min_bound_value
        );
      sscanf
        (
           options[CUST_BOND_MIN_MAX].c_str(),
           "%f",
           &min_max_bound_value
        );

      read_cust_bonds(
                      (char *)options[CUST_BOND_FILE].c_str(),
                      max_min_bound_value,
                      min_max_bound_value,
                      vis->mol_data.residues,
                      vis->mol_data.nresidues,
                      &(vis->mol_data.cust_bonds),
                      &(vis->mol_data.ncust_bonds)
                     );

      populate_statistics(vis);

      vis->params.custBondsOnly = 0;
      if (flags[CUST_BOND_ONLY])
      {
         vis->params.custBondsOnly = 1;
      }

      vis->params.custBonds = 1;
      vis->params.atomDrawMode = A_DRAW_CUSTOM_BONDS;
   }

   /* visualize the molecule directly */
   /***********************************/
   if (flags[VISUALIZE])
      visualize(vis, argc, argv);

   /* memory cleanup */
   /******************/
   free_vis_struct(vis);
   
   return 0;
}/* end function main */
