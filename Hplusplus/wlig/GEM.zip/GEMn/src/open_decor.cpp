/****************************************************************************
 * GEM -- electrostatics calculations and visualization                     *
 * Copyright (C) 2006  John C. Gordon                                       *
 *                                                                          *
 * This program is free software; you can redistribute it and/or modify     *
 * it under the terms of the GNU General Public License as published by     *
 * the Free Software Foundation; either version 2 of the License, or        *
 * (at your option) any later version.                                      *
 *                                                                          *
 * This program is distributed in the hope that it will be useful,          *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 * GNU General Public License for more details.                             *
 *                                                                          *
 * You should have received a copy of the GNU General Public License along  *
 * with this program; if not, write to the Free Software Foundation, Inc.,  *
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *
 ****************************************************************************/
#include <string>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include "file_io.h"
#include "visualize.h"
#include "calculations.h"
#include "partitioned_open.h"
#include "tellUser.h"

using namespace std;


/* most of this is bastardized from partitioned open, all
 * we seek to do is open the pqr and run msms on it, then set the
 * proper values in the vis data structure for a decor mol.  We could
 * generalize this process so that we have a general molecule type which
 * could either be for decoration or calculated and generalize the open
 * file to handle either and stop early on a decor mol but "BABY STEPS" right?
 * --jcg */
extern "C" int open_decoration_molecule(char *mol_name, char *draw_type, vis_data_struct *vis)
{
   /* local variables */
   /*******************/
   partitioned_open_struct open_dat;
   int to_return, i, j, drawing;

   const int ntypes = 8;
   string types[ntypes]={"decorSurf","decorSurfSticks","decorSurfBallsSticks","decorSurfBackbone",
                         "decorSticks","decorBallsSticks","decorBackbone","decorSpacefill"};

   memset(&open_dat, 0, sizeof(partitioned_open_struct));

   /* all partitioned open needs for this purpose is the molecule name */
   open_dat.molname = mol_name;
   open_dat.triDens = 3.;
   open_dat.probeRadius = 1.5;

   /* free existing molecule info and reset it to null/0 */
   clear_decor_mol( &(vis->decor_mol) );

   to_return = open_pqr_run_msms(&open_dat);

   if (!to_return) return to_return;

   /* residues making up the molecule */
   vis->decor_mol.residues = open_dat.residues;
   vis->decor_mol.nresidues = open_dat.nresidues;

   /* triangles on the surface */
   vis->decor_mol.tri = open_dat.tri;
   vis->decor_mol.ntri = open_dat.ntri;

   /* vertices on the surface */
   vis->decor_mol.vert = open_dat.vert;
   vis->decor_mol.nvert = open_dat.nvert;

   /* now to color the surface green */
   for (i = 0; i < vis->decor_mol.nvert; i++)
   {
       vis->decor_mol.vert[i].r = .2;
       vis->decor_mol.vert[i].g = 1;
       vis->decor_mol.vert[i].b = .2;
   }

   /* we still color atoms by type */
   for (i = 0; i < vis->decor_mol.nresidues; i++)
   {
       for (j = 0; j < vis->decor_mol.residues[i].natoms; j++)
       {
           getAtomTypeColor
              (
                 &vis->decor_mol.residues[i].atoms[j].r,
                 &vis->decor_mol.residues[i].atoms[j].g,
                 &vis->decor_mol.residues[i].atoms[j].b,
                 vis->decor_mol.residues[i].atoms[j].name
              );
       }
   }


   /* now to determine the draw type for the decoration molecule */
   /**************************************************************/

   /* default drawing to 1 when not specified (sticks + surf) */
   drawing = 1;

   for (i = 0; i < ntypes; i++)
   {
      if (types[i] == draw_type)
      {
        drawing = i; break;
      }
   }

   /* extrapolate bonds if needed */
   if ((drawing > 0)&&(drawing < 7))
   {
      vis->decor_mol.nbonds = extrapolate_bonds
                                (
                                   vis->decor_mol.residues, vis->decor_mol.nresidues, 
                                   (bond **)&vis->decor_mol.bonds
                                );
   }

   if (drawing < 4) /* all below 4 show surface */
   {
      vis->decor_mol.surfaceDrawType = S_DRAW;

      switch (drawing)
      {
         case 0:
            vis->decor_mol.atomDrawType = DRAW_NONE;
         break;
         case 1:
            vis->decor_mol.atomDrawType = A_DRAW_STICKS;
         break;
         case 2:
            vis->decor_mol.atomDrawType = A_DRAW_BALL_STICK;
         break;
         default:
            vis->decor_mol.atomDrawType = A_DRAW_BACKBONE;
      }
   }
   else
   {
      vis->decor_mol.surfaceDrawType = DRAW_NONE;
   
      switch (drawing)
      {
        case 4:
           vis->decor_mol.atomDrawType = A_DRAW_STICKS;
        break;
        case 5:
           vis->decor_mol.atomDrawType = A_DRAW_BALL_STICK;
        break;
        case 6:
           vis->decor_mol.atomDrawType = A_DRAW_BACKBONE;
        break;
        default:
           vis->decor_mol.atomDrawType = A_DRAW_SPACEFILL;
      }
   }

   return to_return;
}
