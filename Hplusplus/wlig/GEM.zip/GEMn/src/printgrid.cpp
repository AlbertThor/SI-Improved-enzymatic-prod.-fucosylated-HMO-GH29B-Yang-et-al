#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "file_io.h"

int main (int argc, char **argv)
{
   int length,
       xdim, ydim, zdim,
       i, j, k;

   float *grid,
         *gptr,
         xscale, yscale, zscale,
         xpos, ypos, zpos,
         minx, miny, minz,
         maxx, maxy, maxz;


   if (argc != 2)
   {
      printf("command syntax is printgrid <file>\n");
      return 1;
   }

   length = strlen(argv[1]);
   if (length < 5)
   {
      printf("command syntax is printgrid <file>\n");
      return 1;
   }

   /* first thing to do is figure out what kind of grid it is */
   /* assume extensions are the last 4 chars (.fld, .phi) */
   if (strcmp( &argv[1][length-4], ".fld") == 0)
   {
      printf("reading a mead phimap...\n");

      read_avs
        (
           argv[1],
           &grid,
           &xdim, &ydim, &zdim,
           &minx, &miny, &minz,
           &maxx, &maxy, &maxz
        );

      xscale = (maxx - minx)/(float)(xdim-1);
      yscale = (maxy - miny)/(float)(ydim-1);
      zscale = (maxz - minz)/(float)(zdim-1);

   }
   else if (strcmp( &argv[1][length-4], ".phi") == 0)
   {
      printf("reading a delphi phimap...\n");

      xdim = read_phi_grid
              (
                 argv[1],
                 &grid,
                 &minx, &miny, &minz,
                 &maxx, &maxy, &maxz
              );

      ydim = zdim = xdim;

      xscale = (maxx - minx)/(float)(xdim-1);
      yscale = (maxy - miny)/(float)(ydim-1);
      zscale = (maxz - minz)/(float)(zdim-1);
   }
   else
   {
      printf("unrecognized file format, needs .phi or .fld\n");
      return 1;
   }

   /* now we have read it in, time to print out the data to screen */
   if (xdim && ydim && zdim && grid)
   {

      gptr = grid;
      zpos = minz;
      for (i = 0; i < zdim; i++)
      {
          ypos = miny;
          for (j = 0; j < ydim; j++)
          {
              xpos = minx;
              for (k = 0; k < xdim; k++)
              {
                 printf("(%f, %f, %f) %f\n", xpos, ypos, zpos, *gptr);
   
                 xpos += xscale;
                 gptr++;
              }

              ypos += yscale;
          }

          zpos += zscale;
      }

      free(grid);
   }

   return 0;
}
