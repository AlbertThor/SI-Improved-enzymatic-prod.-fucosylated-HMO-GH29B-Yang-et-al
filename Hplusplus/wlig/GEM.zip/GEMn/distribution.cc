#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <iostream.h>
#include <unistd.h>

#define LINE_SIZE 255

extern char *optarg;
extern int optind;
extern int optopt;
extern int opterr;
extern int optreset;
/***************************************************************************************************
 * The syntax of this program has been modified to suit the variation of data size necessary to    *
 * handle large input structures.  The concept of defining the dimension is absolutely necessary   *
 * when handling input from standard input, but files can be rewound and reopened.  For this reason*
 * the syntax is now ./distribution -min <min> -max <max> -bw <box width> -i <input file> -o <output file>.  The       *
 * addition of min, max, and box width allows us to make plots that are comparable.  Min and Max   *
 * are optional, but box width is a required field.  So the syntax again is:
 *       ./distribution -m <min> -x <max> -w <box width> -i <input file>  -o <output file>         *
 *               -m   is optional
 *               -x   is optional
 *               -w   is required
 *               -i   is required
 *               -o   is required
 ***************************************************************************************************/
int main(int argc, char **argv)
{

int	 nbins;
int    c;
float *err;

int    *bin;
double gauss, x, check_sum=0;
int		i,j;
char    *fgetsret = (char *)1;
char    flags[5] = {'\0','\0','\0','\0','\0'};
char    line[LINE_SIZE];
double  box_width,
        min,
		  max;

FILE *in_fp,
      *out_fp;

      /* read in the arguments */
      while (EOF != (c=getopt(argc, argv, "m:x:w:i:o:")))
      {
         switch(c) {
		     case 'm':
                 min = atof(optarg);
                 flags[0] = '\1';
			     break;
	         case 'x':
			        max = atof(optarg);
                 flags[1] = '\1';
			     break;
		     case 'w':
			        box_width = atof(optarg);
                 flags[2] = '\1';
			     break;
		     case 'i':
			        in_fp = fopen(optarg, "r");
                 flags[3] = '\1';
			     break;
		     case 'o':
			        out_fp = fopen(optarg, "w");
                 flags[4] = '\1';
			     break;
		     default:
			     break;
	      }
     }

   if (!flags[2] || !flags[3] || !flags[4] || !in_fp || !out_fp)
   {
      cerr<<"Error, arguments are -i -o -w -m -x, need -i -o -w"<<endl
          <<"-i input file"<<endl
          <<"-o output file"<<endl
          <<"-m min"<<endl
          <<"-x max"<<endl
          <<"-w width"<<endl;
      exit(1);
   }

   /* now we need to find out how big our input set is */
   for (i =0; fgetsret && in_fp; i++) fgetsret = fgets(line, LINE_SIZE, in_fp);
   fseek(in_fp, 0, SEEK_SET);
   fgetsret=(char *)1;

	int natoms = i-1;	

   /* allocate the space for errs */
   err = (float *)calloc(natoms, sizeof(float));

   if (!flags[0]) min = 100000;
   if (!flags[1]) max = -100000;

   float temp_err;
   for (i=natoms-1;(i >= 0)&&in_fp&&fgetsret; i--)
   {
      fgetsret = fgets(line, LINE_SIZE, in_fp); 
      sscanf(line, "%f", &temp_err);
      err[i] = temp_err;

      if ((!flags[0]) && (err[i] < min))
         min = err[i];
      if ((!flags[1]) && (err[i] > max))
         max = err[i];
   }
   fclose(in_fp);

   nbins = (int)((max - min) / box_width);

   bin = (int *)calloc(nbins, sizeof(int));
   
	double average = err[0]; 
	double sigma = 0.0;

	for (i = 1; i < natoms; i++)
   {
		average+= err[i];
	}

   average /= (double) natoms;

	for (j = 0; j < natoms; j++) sigma+= (err[j] - average)*(err[j] - average);
	sigma = sqrt(sigma/natoms);

	for (j = 0; j < natoms; j++)
   {
		for (i = 0; i < nbins; i++)
      {
			if ( err[j] <= min + (double (i+1))*box_width && 
			     err[j] > min + (double (i))*box_width )
              {
                 bin[i]++; 
                 break;
              }
		}
	}

	for (i = 0; i < nbins; i++) {
		check_sum+= bin[i];
		x = min + ((double (i) )+0.5)*box_width;

      fprintf(out_fp, "%lf %i\n", x, bin[i]);
	}
   fclose(out_fp);

	cerr << "NATOMS=  " << natoms << " average_error=  " << average << " stand. deviation=   " << sigma << " " << check_sum << endl;

   return 0;
}
